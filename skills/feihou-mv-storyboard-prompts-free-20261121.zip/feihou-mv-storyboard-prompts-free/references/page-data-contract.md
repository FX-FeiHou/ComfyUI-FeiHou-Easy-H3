# Free 版生产页数据契约

Easy H3 制作包分镜加载器能直接读 H3 页里的 `mv-project-data`，导入规则见 [easy-h3-production-pack.md](easy-h3-production-pack.md)。

三页由同一份 `project-manifest.json` 生成。复制 `assets/project-manifest.template.json` 后填写项目数据，先运行校验器，再运行页面构建器。

```json
{
  "title": "歌曲或项目名称",
  "package_mode": "mv",
  "subtitle": "可选页眉副标题",
  "page_titles": {
    "asset": "参考图片清单",
    "h3": "MiniMax H3 全片分镜提示词｜项目类型",
    "list": "分镜列表｜项目类型"
  },
  "master_audio": "歌曲路径；要导入 Easy H3 时写相对制作包根目录的路径，没有歌曲写空字符串",
  "audio_references": [
    {
      "id": "A1",
      "file": "绝对或相对音频路径",
      "role": "voice_timbre_reference | audio_reuse",
      "h3_label": "<Audio 1>",
      "speaker": "<Subject 1> (S1)"
    }
  ],
  "master_duration_seconds": 0,
  "performance_ratio_note": "已确认的表演/剧情比例或临时说明",
  "assets": [
    {
      "id": "P1",
      "asset_id": "用户提供图片的资产名",
      "name": "参考图名称",
      "kind": "locked",
      "use": "在 H3 中的用途"
    }
  ],
  "shots": [
    {
      "id": "H3-001",
      "range": "00:00:000–00:06:400",
      "seconds": 6.4,
      "section": "段落",
      "title": "分镜名称",
      "mode": "sing | group | dance | duet | narrative | hold",
      "performer": "演唱、口播、舞蹈成员或剧情镜头",
      "audio_slice": "音频切片或临时口播区间",
      "lyrics": "精确歌词/台词，或 本段无歌词",
      "references": ["P1"],
      "camera": "全中文机位、构图、运镜与主动态",
      "scene": "全中文场景与用光",
      "action": "全中文完整动作叙事",
      "continuity": "硬切说明，或上一终帧到本首帧的连续关系和本镜终帧",
      "transition": "接续 | 硬切（首镜可省略）",
      "continuation_frames": "22+22（只在接续时用）",
      "prompt_en": "完整 English Ref2VA prompt",
      "prompt_zh": "完整中文 H3 工作提示词"
    }
  ]
}
```

## 约束

- `assets` 只包含用户提供的可用参考图，`kind` 为 `locked` 或 `provided`；不包含 `generated` 条目，也不填写图片生成提示词。
- `range` 使用 `MM:SS:ddd–MM:SS:ddd`。每个镜头最多九个 `references`；本地 `<Picture N>` 按数组顺序推导。
- `audio_references` 的 `A#` 是项目级音频 ID，`h3_label` 是本镜 H3 的 `<Audio N>` 标签。音色参考必须在 `subject_definitions` 单独定义 `<Audio N>` 并绑定 `<Subject N> (Sx)`，`summary` 使用 `audio reference`，`retention_analysis` 使用 `reference`；只有复制音频信号时才使用 `audio reuse` 与 `fully_copy` 或 `partially_copy`。
- 每个 `lyrics` 必填；无歌词填写精确文本 `本段无歌词`。
- `seconds` 是 `range` 算出的秒数，构建器会补上；显式填写时必须和 range 一致，合法范围 0.2–30 秒。
- `master_audio` 填歌曲相对制作包根目录的路径，加载器按它和每镜 `range` 裁切 `<Audio 1>`。
- `transition` 是本镜开头怎么接上一镜：`接续` 或 `硬切`，首镜以外每镜都写，和 `continuity` 的文字一致。`continuation_frames` 是接续时的一采+二采引导帧数，只能是 `0+5`、`5+0`、`5+5`、`22+0`、`22+5`、`22+22`、`39+0`、`39+5`、`39+22`、`39+39`。一条接续链最多接 4 次，超过要先得到用户同意并记在 `continuation_approvals`。详见 [easy-h3-production-pack.md](easy-h3-production-pack.md)。
- 每镜可选 `audio_references`：本镜要加载的音频列表，顺序就是本镜的 `<Audio N>`。只用歌曲时不写，加载器按 `master_audio` 和本镜 `range` 自动裁切成 `<Audio 1>`。一旦写了，歌曲也要写进列表并带上本镜区间，例如 `[{"id": "A1", "range": "00:16:000–00:20:900"}, {"id": "A2"}]`；写 `[]` 表示本镜不加载任何音频。
- 三个 `page_titles` 必填，分别用于参考图片清单、H3 页和中文分镜列表的浏览器标题与可见标题。
- 用户可见项目输出只生成三份 HTML；不输出 Markdown 文件。

## 命令

```powershell
py -3.12 <技能包目录>\scripts\validate_mv_manifest.py <项目文件夹>\project-manifest.json
py -3.12 <技能包目录>\scripts\build_mv_pages.py <项目文件夹>\project-manifest.json <项目文件夹>\视频制作包
```

`<技能包目录>` 指本技能的实际安装位置（各客户端不同，例如 `%USERPROFILE%\.codex\skills\feihou-mv-storyboard-prompts-free`）；`<项目文件夹>` 换成实际的项目路径。
