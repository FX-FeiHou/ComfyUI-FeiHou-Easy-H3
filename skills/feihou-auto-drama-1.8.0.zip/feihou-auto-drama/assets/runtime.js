(() => {
  'use strict';
  const p = JSON.parse(document.getElementById('dh-project-data').textContent);
  const projectChoices = /*PROJECT_CHOICES*/[];
  const continuationPlan = /*CONTINUATION_PLAN*/[];
  const page = document.body.dataset.page;
  const pageFiles = /*PAGE_FILES*/{};
  const files = {asset: pageFiles.asset, video: pageFiles.video, list: pageFiles.list};
  const titles = pageFiles.titles || {asset:'资产清单',list:'分镜列表',video:'分镜提示词'};
  const $ = s => document.querySelector(s);
  const esc = v => String(v ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const assets = p.assets || [], shots = p.shots || [];
  const byId = new Map(assets.map(a=>[a.id,a]));
  const continuationById = new Map(continuationPlan.map(row=>[row.id,row]));
  const toast = text => { $('#toast').textContent=text; $('#toast').classList.add('show'); setTimeout(()=>$('#toast').classList.remove('show'),1400); };
  async function copy(text) {
    try { await navigator.clipboard.writeText(text); toast('已复制'); }
    catch { const t=document.createElement('textarea'); t.value=text; document.body.append(t); t.select(); const ok=document.execCommand('copy'); t.remove(); toast(ok?'已复制':'复制失败，请手动选择正文'); }
  }
  const panel=(label,text)=>text?`<section class="panel"><h2>${esc(label)}</h2><div class="prose">${esc(text)}</div></section>`:'';
  const path=v=>esc(v.split('/').map(encodeURIComponent).join('/'));
  const media=(file,type,label)=>file?`<figure><${type} ${type==='img'?'loading="lazy"':'controls preload="metadata"'} src="${path(file)}" ${type==='img'?`alt="${esc(label)}"`:''}></${type}><figcaption><a href="${path(file)}" target="_blank" rel="noopener">${esc(label)} · ${esc(file)}</a></figcaption></figure>`:'';
  const refs=(ids=[])=>ids.length?ids.map((id,i)=>`<a class="ref picture-chip" href="${files.asset}#asset-${esc(id)}">${i+1}. ${esc(id)} · ${esc(byId.get(id)?.name||'未知')}${byId.get(id)?.file?'':' · 待生成'}</a>`).join(' '):'<span class="meta">无参考图</span>';
  // 分镜提示词的引用记法随目标生成端切换：Seedance 用 @图片n/@视频n/@音频n，H3 用官方槽位 <Picture n>/<Video n>/<Audio n>。
  const fmt=(p.prompt_format==='seedance')?'seedance':'h3';
  const slot=(kind,n)=>kind==='图片'?(fmt==='seedance'?`@图片${n}`:`<Picture ${n}>`):(fmt==='seedance'?`@${kind}${n}`:`<${kind==='音频'?'Audio':'Video'} ${n}>`);
  const slotLine=(kind,items)=>{ if(!items.length) return '';
    const chips=items.map((v,i)=>{ const n=i+1;
      if(kind==='图片'){const a=byId.get(v);return `<a class="ref picture-chip" href="${files.asset}#asset-${esc(v)}">${esc(slot(kind,n))} = ${esc(v)} · ${esc(a?.name||'未知')}${a?.file?'':' · 待生成'}</a>`;}
      return `<span class="ref picture-chip">${esc(slot(kind,n))} = ${esc(v)}</span>`; }).join(' ');
    return `<div class="slot-line"><span class="slot-label">引用${kind}</span>${chips}</div>`; };
  const slotBlock=s=>slotLine('图片',s.references||[])+slotLine('视频',s.video_refs||[])+slotLine('音频',s.audio_refs||[]);
  const prompt=(label,text,extra)=>`<div><div class="prompt-label">${esc(label)}${text?'<button class="copy">复制提示词</button>':''}</div>${extra||''}<pre class="prompt">${esc(text||'待编写')}</pre></div>`;
  // 资产生图提示词：默认中文单语；旧项目若仍带英文，则并排双语展示。
  const assetPrompts=a=>a.prompt_en
    ? `<div class="prompts">${prompt('中文生图提示词',a.prompt_zh)}${prompt('英文生图提示词',a.prompt_en)}</div>`
    : `<div class="prompts single">${prompt('中文生图提示词',a.prompt_zh)}</div>`;
  const fields=(pairs)=>`<dl>${pairs.map(([a,b])=>`<dt>${esc(a)}</dt><dd>${esc(b||'—')}</dd>`).join('')}</dl>`;
// 短剧分镜没有参考音频需要截取时长，因此不生成累积时间轴：
  // range 统一为 00:00:000–00:00:000 占位，实际镜头时长只看 seconds 字段。
  // totalSeconds 仍按 seconds 累加，仅用于顶部总时长展示。
  const PLACEHOLDER_RANGE='00:00:000–00:00:000';
  let totalSeconds=0;
  const ranges=new Map(shots.map(s=>{totalSeconds+=s.seconds;return [s.id,PLACEHOLDER_RANGE];}));
  const at=totalSeconds;
  document.title=`${p.title}｜${titles[page]}`; $('h1').textContent=titles[page];
  $('#eyebrow').textContent=`《${p.title}》 · 肥猴全自动化影视技能`;
  $('#sub').textContent=[p.style_note,p.aspect_ratio,p.resolution].filter(Boolean).join(' · ');
  $('#nav').innerHTML=Object.entries(titles).map(([key,title])=>`<a class="chip ${key===page?'current':''}" href="${files[key]}">${title}</a>`).join('');
  // 连续剧：总文件夹的资产清单全剧共用，各「第xx-xx集」子文件夹放本组的分镜列表 / 分镜提示词；导航里列出各组。
  if(Array.isArray(files.groups)&&files.groups.length) $('#nav').insertAdjacentHTML('afterend',`<nav class="chips group-nav" aria-label="分集">${files.groups.map(g=>`<a class="chip ${g.current?'current':''}" href="${g.list}">${esc(g.label)}</a>`).join('')}</nav>`);
  const groupCount=Array.isArray(p.series?.groups)?p.series.groups.length:0;
  $('#metrics').textContent=groupCount&&!shots.length?`${assets.length} 项资产（全剧共用） · ${groupCount} 组分集，分镜在各分集文件夹里`:`${assets.length} 项资产 · ${shots.length} 个镜头 · 计划 ${at.toFixed(1)} 秒`;
  if(page==='list') $('#intro').innerHTML=panel('剧本分析',p.analysis)+`<details class="panel"><summary>故事原文与制作剧本</summary>${panel('原故事',p.story)}${panel('制作剧本',p.script)}</details>`+panel('时间说明',p.timing_note);
  else if(page==='video') $('#intro').innerHTML=panel('手动后期',p.handoff||'按镜头顺序交付视频和声音，由用户手动剪辑。')+(p.final_file?panel('成片','用户已提供成片文件')+media(p.final_file,'video','成片'):panel('成片状态','尚未登记最终成片。'));
  else $('#intro').innerHTML=`<section class="panel"><h2>图片编号速查</h2><div class="quick">${assets.map(a=>`<a href="#asset-${esc(a.id)}">${esc(a.id)} · ${esc(a.name)}</a>`).join('')}</div></section>`;
  const choiceRows=projectChoices.length?projectChoices:[{title:'画面形式',label:'待选择'},{title:'叙事方式',label:'待选择'},{title:'故事题材',label:'待选择'},{title:'单片 / 连载',label:'待选择'}];
  $('#intro').insertAdjacentHTML('afterbegin',`<section class="panel"><h2>${p.is_template_preview?'启动选择预览（未确认项目）':'已确认的创作选择'}</h2>${fields(choiceRows.map(c=>[c.title,c.label+(c.detail?' · '+c.detail:'')]))}<p class="meta">新作品通过对话中的原生弹窗选择；此处只展示结果。</p></section>`+panel('创作执行方向',p.creative_approach));
  if(page!=='asset'&&shots.length) $('#intro').insertAdjacentHTML('beforeend',panel('接续说明','字段控制当前分镜开头与上一分镜的衔接，首镜不应用。默认每条连续链最多接续4次；超过4次接续，画质将无法保证，须先告知风险并取得用户同意。以下按加载器“自动”配置展示，强制覆盖后须重新检查实际接续链。'+(continuationPlan.some(r=>r.requires_approval&&!r.approved)?' 本页含待用户同意的超限接续，尚不可执行对应片段。':'')));
  let filter='全部';const items=page==='asset'?assets:shots;
  const groups=['全部',...new Set(items.map(x=>page==='asset'?x.category:x.section).filter(Boolean))];
  $('#filters').innerHTML=groups.map(x=>`<button class="filter ${x===filter?'active':''}" data-filter="${esc(x)}">${esc(x)}</button>`).join('');
  function assetCard(a) { return `<article class="card" id="asset-${esc(a.id)}"><div class="card-head"><h3><span class="asset-id">${esc(a.id)}</span>｜${esc(a.name)}</h3><div class="meta">${esc(a.category)} · ${esc(a.file?'已有图片':a.status||'待生成')}</div><div class="prose">${esc(a.use)}</div></div><div class="body">${media(a.file,'img',a.name)}<div class="refs-line">参考图上传顺序：${refs(a.reference_ids)}</div>${a.kind==='locked'&&!a.prompt_zh&&!a.prompt_en?'<p>已有参考资产。</p>':assetPrompts(a)}</div></article>`; }
  function shotCard(s) {
    const c=continuationById.get(s.id);
    const transitionFields=c?fields([['接续方式',c.first?'首镜（不应用衔接字段）':c.transition],['接续帧数',c.first||c.transition==='硬切'?'不使用':c.continuation_frames],['连续接续次数',c.first||c.transition==='硬切'?'0（新链起点）':`第 ${c.continuation_count} 次 · 起点 ${c.chain_start}`],...(c.requires_approval?[['超限接续',c.approved?'用户已同意；超过4次接续，画质将无法保证。':'待用户同意；超过4次接续，画质将无法保证。']]:[])]):'';
    // 宫格故事板：按镜头复杂度分档，只允许 4/6/8/9 等法定档位。标签显示在提示词框外。
    const gridTag=s.board_grid_count?`<span class="grid-tag" title="本镜缩略故事板需要 ${s.board_grid_count} 宫格">宫格故事板 · ${s.board_grid_count} 宫格</span>`:'';
    const header=`<div class="head"><h3>${esc(s.id)}｜${esc(s.title)}</h3><div class="line"><button class="time-pill">${esc(ranges.get(s.id))}</button><span class="duration">${s.seconds.toFixed(1)} 秒</span><span class="meta">${esc(s.section)}</span>${gridTag}</div><div class="speech">对白：${esc(s.speech||'无对白')}</div>${transitionFields}</div>`;
    let body;
    if(page==='list') body=fields([['角色',s.performer],['机位',s.camera],['场景',s.scene],['动作',s.action],['衔接 / 终帧',s.continuity]])+prompt('中文自然语言提示词（Seedance 兼容）',s.nl_prompt_zh,slotBlock(s));
    else body=`<div class="meta">${esc(s.model||'生成端待选')} · ${esc(s.generation_mode||'模式待定')} · ${esc(s.status||'待生成')}</div>`+prompt(fmt==='seedance'?'中文 Seedance 提示词':'中文 H3 提示词',s.prompt_zh,slotBlock(s))+prompt('对白与声音生成',s.sound_prompt)+media(s.video_file,'video',s.id+' 视频')+(s.audio_files||[]).map(a=>media(a.file,'audio',a.label||'声音')).join('')+fields([['手动剪辑说明',s.edit_note]]);
    return `<article class="shot" id="${esc(s.id)}"${c?` data-transition="${esc(c.transition)}" data-continuation-frames="${esc(c.continuation_frames)}"`:''}>${header}<div class="body">${body}</div></article>`;
  }
  function draw(){const q=$('#search').value.toLowerCase();const selected=items.filter(x=>(filter==='全部'||(page==='asset'?x.category:x.section)===filter)&&(!q||JSON.stringify(x).toLowerCase().includes(q)));$('#cards').innerHTML=selected.map(page==='asset'?assetCard:shotCard).join('')||'<div class="panel">没有匹配内容。</div>';}
  $('#search').addEventListener('input',draw);
  document.addEventListener('click',e=>{const b=e.target.closest('button');if(b?.classList.contains('copy'))copy(b.closest('div').querySelector('pre.prompt').textContent);if(b?.classList.contains('time-pill'))copy(b.textContent);if(b?.dataset.filter){filter=b.dataset.filter;document.querySelectorAll('[data-filter]').forEach(x=>x.classList.toggle('active',x===b));draw();}if(b?.classList.contains('back'))scrollTo({top:0,behavior:'smooth'});const a=e.target.closest('a[href^="#asset-"]');if(a){filter='全部';$('#search').value='';draw();document.querySelectorAll('[data-filter]').forEach(x=>x.classList.toggle('active',x.dataset.filter==='全部'));}});
  document.addEventListener('error',e=>{if(['IMG','VIDEO','AUDIO'].includes(e.target.tagName)){const caption=e.target.closest('figure')?.querySelector('figcaption');if(caption&&!caption.querySelector('.media-error'))caption.insertAdjacentHTML('beforeend','<span class="media-error"> · 文件无法预览，请检查路径或格式。</span>');}},true);
  draw();if(location.hash)requestAnimationFrame(()=>document.getElementById(decodeURIComponent(location.hash.slice(1)))?.scrollIntoView());
})();
