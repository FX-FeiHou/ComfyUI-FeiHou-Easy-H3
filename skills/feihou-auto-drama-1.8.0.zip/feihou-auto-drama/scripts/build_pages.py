"""Render three AI film production HTML pages from stdin or recover their data."""
from __future__ import annotations

import argparse
import json
import math
import re
import sys
from pathlib import Path
from project_choices import resolve_choices
from continuation import resolve_plan

ROOT = Path(__file__).resolve().parents[1]
# 页名固定为「编号.####_页名」：编号 01–03 与页名都不可更改，只有 #### 换成任务/剧本名称。
# 生成端标签不再进入文件名。
PAGE_SLUGS = {
    'asset-inventory': ('01', '资产清单'),
    'chinese-shotlist': ('02', '分镜列表'),
    'minimax-h3-shotlist': ('03', '分镜提示词'),
}
# 模板文件名与成品页同源，也用「编号.页名」：01.资产清单.template.html 等。
PAGE_TEMPLATES = {key: f'{index}.{suffix}.template.html' for key, (index, suffix) in PAGE_SLUGS.items()}
# 键名与模板里的 body[data-page] 一致：asset / video / list；此处顺序即 01→02→03 的导航顺序
PAGE_TITLES = {
    'asset': '资产清单',
    'list': '分镜列表',
    'video': '分镜提示词',
}
DATA = re.compile(r'(<script id="dh-project-data" type="application/json">)\s*.*?\s*(</script>)', re.S)
INVALID = re.compile(r'[\\/:*?"<>|]+')
# FeiHou Easy H3 制作包分镜加载器（v1.4.33 production_pack.py / production_pack_parser.js）的字段规则，构建时同样检查。
LOADER_ASPECTS = {'16:9', '9:16', '1:1', '2:3', '3:2', '4:3', '3:4', '21:9'}
LOADER_SECONDS = (0.2, 30.0)
LOADER_MAX_IMAGES, LOADER_MAX_VIDEOS = 9, 3
AUDIO_WHOLE = '00:00:000–00:00:000'  # 加载器：end=0 表示用到结尾
PACK_ROLE = re.compile(r"""<meta\b[^>]*\bname\s*=\s*["']feihou-pack-page["'][^>]*\bcontent\s*=\s*["']shotlist["']""", re.I)
GROUP_DIR = re.compile(r'第\d+(?:-\d+)?集')


def slug(value: str) -> str:
    """把作品名与生成端标签压成安全的文件名片段。"""
    cleaned = INVALID.sub('', str(value)).strip().replace(' ', '_')
    cleaned = re.sub(r'_{2,}', '_', cleaned).strip('._')
    if not cleaned:
        raise ValueError(f'Filename segment is empty after sanitizing: {value!r}')
    return cleaned


def page_filenames(p: dict) -> dict:
    """返回 {page_key: 正式文件名}，命名格式 编号.####_页名.html（如 01.作品名_资产清单.html）。"""
    title = slug(p['title'])
    names = {key: f'{index}.{title}_{suffix}.html' for key, (index, suffix) in PAGE_SLUGS.items()}
    if len(set(names.values())) != len(names):
        raise ValueError('Page filenames collide; check the title')
    return names


def read_page(path: Path) -> dict:
    match = DATA.search(path.read_text(encoding='utf-8'))
    if not match:
        raise ValueError('Missing dh-project-data')
    return json.loads(match.group(0).split('>', 1)[1].rsplit('</script>', 1)[0])


def validate(p: dict, output: Path) -> None:
    if not isinstance(p, dict) or not isinstance(p.get('title'), str) or not p['title'].strip():
        raise ValueError('A nonempty title is required')
    preview = p.get('is_template_preview', False)
    if not isinstance(preview, bool):
        raise ValueError('is_template_preview must be boolean')
    if p.get('prompt_format') not in (None, 'h3', 'seedance'):
        raise ValueError('prompt_format must be h3 or seedance')
    if p.get('aspect_ratio') not in (None, '') and p['aspect_ratio'] not in LOADER_ASPECTS:
        raise ValueError(f'aspect_ratio 必须是 Easy H3 支持的画幅之一（{"/".join(sorted(LOADER_ASPECTS))}），'
                         f'不能写 {p["aspect_ratio"]!r}；2.39:1 这类宽银幕写 21:9')
    if p.get('fps') is not None and (isinstance(p['fps'], bool) or not isinstance(p['fps'], (int, float))
                                     or not 1 <= p['fps'] <= 120):
        raise ValueError('fps must be a number between 1 and 120')
    if not preview or p.get('project_choices') is not None:
        resolve_choices(p.get('project_choices'), require_confirmed=not preview)
    if not preview and (not isinstance(p.get('creative_approach'), str) or not p['creative_approach'].strip()):
        raise ValueError('Production requires a concrete creative_approach')
    if not isinstance(p.get('assets'), list) or not isinstance(p.get('shots'), list):
        raise ValueError('assets and shots must be arrays')
    assets, shots = p['assets'], p['shots']
    ids = [a.get('id', '') for a in assets]
    if len(set(ids)) != len(ids) or any(not re.fullmatch(r'P[1-9]\d*', v) for v in ids):
        raise ValueError('Asset IDs must be unique P# values')
    known = set(ids)

    def refs(values, owner):
        if not isinstance(values, list) or any(not isinstance(x, str) for x in values):
            raise ValueError(f'{owner}: references must be a string array')
        if len(set(values)) != len(values) or set(values) - known:
            raise ValueError(f'{owner}: duplicate or unknown image reference')

    def file(value):
        if not value:
            return
        if not isinstance(value, str) or '\\' in value or ':' in value or value.startswith('/'):
            raise ValueError(f'Media paths must be relative and use /: {value}')
        if not (output / value).is_file():
            raise ValueError(f'Media does not exist: {value}')

    graph = {}
    for a in assets:
        refs(a.get('reference_ids', []), a['id'])
        graph[a['id']] = a.get('reference_ids', [])
        if a.get('kind') not in ('locked', 'generated'):
            raise ValueError(f'{a["id"]}: kind must be locked or generated')
        if a['kind'] == 'locked' and not a.get('file'):
            raise ValueError(f'{a["id"]}: locked asset requires a real file')
        file(a.get('file'))
        # 资产生图提示词：中文必填；英文可选（旧项目仍可带上，页面按需展示）。
        for lang in ('en', 'zh'):
            body = a.get('prompt_' + lang, '')
            if a['kind'] == 'generated' and lang == 'zh' and not body.strip():
                raise ValueError(f'{a["id"]}: Chinese prompt is required')
            if body and set(re.findall(r'@(P[1-9]\d*)\b', body)) != set(graph[a['id']]):
                raise ValueError(f'{a["id"]}: @{lang} references differ from reference_ids')
    visiting, visited = set(), set()

    def visit(key):
        if key in visiting:
            raise ValueError(f'Cyclic asset dependency: {key}')
        if key in visited:
            return
        visiting.add(key)
        for child in graph[key]:
            visit(child)
        visiting.remove(key)
        visited.add(key)

    for key in graph:
        visit(key)
    shot_ids = set()
    for s in shots:
        sid = s.get('id', '')
        if not re.fullmatch(r'[A-Za-z0-9_-]+', sid) or sid in shot_ids:
            raise ValueError('Shot IDs must be unique URL-safe identifiers')
        shot_ids.add(sid)
        seconds = s.get('seconds')
        if isinstance(seconds, bool) or not isinstance(seconds, (float, int)) or not math.isfinite(seconds) or seconds <= 0:
            raise ValueError(f'{sid}: seconds must be a finite positive number')
        if not LOADER_SECONDS[0] <= seconds <= LOADER_SECONDS[1]:
            raise ValueError(f'{sid}: seconds={seconds} 超出 Easy H3 制作包加载器的 0.2–30 秒范围，请拆镜')
        if s.get('aspect_ratio') not in (None, '') and s['aspect_ratio'] not in LOADER_ASPECTS:
            raise ValueError(f'{sid}: aspect_ratio {s["aspect_ratio"]!r} 不是 Easy H3 支持的画幅')
        if len(s.get('references', [])) > LOADER_MAX_IMAGES:
            raise ValueError(f'{sid}: references 最多 {LOADER_MAX_IMAGES} 张图（加载器上限）')
        if len(s.get('video_refs', [])) > LOADER_MAX_VIDEOS:
            raise ValueError(f'{sid}: video_refs 最多 {LOADER_MAX_VIDEOS} 段视频（加载器上限）')
        if not isinstance(s.get('audio_refs', []), list) or any(not isinstance(v, str) for v in s.get('audio_refs', [])):
            raise ValueError(f'{sid}: audio_refs must be a string array of relative paths')
        if s.get('audio_refs') and not s.get('references') and not s.get('video_refs'):
            raise ValueError(f'{sid}: 有参考音频的镜头至少要有一张参考图或一段参考视频（H3 参考模式），'
                             '否则加载器拒绝；请加参考图，或去掉本镜音频')
        for field in ('references', 'board_reference_ids', 'board_ids'):
            refs(s.get(field, []), sid)
        for lang in ('en', 'zh'):
            body = s.get('board_prompt_' + lang, '')
            if body and set(re.findall(r'@(P[1-9]\d*)\b', body)) != set(s.get('board_reference_ids', [])):
                raise ValueError(f'{sid}: storyboard prompt references differ')
        for pid in s.get('board_ids', []):
            if not next(a for a in assets if a['id'] == pid).get('file'):
                raise ValueError(f'{sid}: board_ids must refer to actual images')
        # 宫格故事板（缩略故事板预览）字段：这里只保留「本镜需要几宫格」。
        # 宫格图的生图提示词（黑白线稿 / 彩色两套）由画布导入节点侧按宫格数与分镜内容自行产出，
        # 不写进页面数据，因此构建器不再要求、也不再校验 board_grid_prompt_* 字段。
        grid = s.get('board_grid_count')
        if grid is not None:
            if isinstance(grid, bool) or grid not in (1, 2, 4, 6, 8, 9, 12, 16):
                raise ValueError(f'{sid}: board_grid_count must be one of 1/2/4/6/8/9/12/16')
        # 提示词槽位门禁：@图片n/@视频n/@音频n 与 H3 的 <Picture n> 都必须落在该镜实际引用范围内。
        # 越界就是「引用了不存在的槽位」，H3 端会整包退回，必须在这里挡住。
        slot_lists = {
            '图片': s.get('references', []),
            '视频': s.get('video_refs', []),
            '音频': s.get('audio_refs', []),
        }

        def check_slots(text, field):
            for kind, values in slot_lists.items():
                for n in re.findall(rf'@{kind}(\d+)', text):
                    if not 1 <= int(n) <= len(values):
                        raise ValueError(
                            f'{sid}: {field} 的 @{kind}{int(n)} 越界，本镜只有 {len(values)} 项{kind}引用')
            # 与加载器同一写法：<Picture n>/<Image n>、<Video n>、<Audio n>，不区分大小写。
            for tag, kind in (('Picture|Image', '图片'), ('Video', '视频'), ('Audio', '音频')):
                for n in re.findall(rf'<(?:{tag})\s+(\d+)>', text, re.I):
                    if not 1 <= int(n) <= len(slot_lists[kind]):
                        raise ValueError(f'{sid}: {field} 的 <{tag.split("|")[0]} {int(n)}> 越界，'
                                         f'本镜只有 {len(slot_lists[kind])} 项{kind}引用')

        for field in ('nl_prompt_zh', 'prompt_zh'):
            body = s.get(field, '')
            if not isinstance(body, str):
                raise ValueError(f'{sid}: {field} must be a string')
            if body.strip():
                check_slots(body, field)
        file(s.get('video_file'))
        for a in s.get('audio_files', []):
            file(a.get('file'))
        for field in ('audio_refs', 'video_refs'):
            for value in s.get(field, []):
                file(value)
    file(p.get('final_file'))
    resolve_plan(p)


def loader_payload(p: dict) -> dict:
    """页面内联数据按 Easy H3 加载器的读法补齐（不改调用方传入的对象）：
    - 每镜写出 audio_references（由 audio_refs 生成，没有就写 []）。加载器只认 audio_references；
      不写时，包里恰好一个音频会被自动当成配乐，多个音频则整包报错。
    - 去掉 range：短剧镜头时长只看 seconds，占位的 00:00:000–00:00:000 会被加载器读成 0 秒。
    """
    data = json.loads(json.dumps(p, ensure_ascii=False))
    for s in data['shots']:
        s.pop('range', None)
        s['audio_references'] = [{'file': f, 'range': AUDIO_WHOLE} for f in s.get('audio_refs', [])]
    return data


def loader_warnings(p: dict) -> list[str]:
    empty = [s['id'] for s in p['shots'] if not str(s.get('prompt_zh', '')).strip()]
    return [f'这些镜头还没有 prompt_zh，Easy H3 加载器会拒绝整包：{"、".join(empty)}'] if empty else []


def other_shotlists(output: Path, keep: set, skip_groups: bool = False) -> list[str]:
    """输出目录（制作包根目录）里其他声明为 shotlist 的页面；加载器要求一个制作包有且只有一个。

    keep：本次要写出的页面（相对 output 的路径）。skip_groups：连续剧总文件夹里不在本次分组里的旧「第xx集」
    文件夹另行提示（见 build_pages），不在这里拦。
    """
    found = []
    for path in (output.rglob('*.htm*') if output.is_dir() else []):
        parts = path.relative_to(output).parts
        rel = '/'.join(parts)
        if rel in keep or (skip_groups and len(parts) > 1 and GROUP_DIR.fullmatch(parts[0]) and parts[0] not in keep):
            continue
        try:
            head = path.read_text(encoding='utf-8', errors='ignore')[:4096]
        except OSError:
            continue
        if PACK_ROLE.search(head):
            found.append(rel)
    return found


def stale_error(stale: list[str]) -> ValueError:
    return ValueError('输出目录里已有别的分镜列表页，Easy H3 加载器要求一个制作包只有一个：'
                      + '、'.join(stale) + '。请换一个空文件夹输出，或请用户自己处理旧页面（本技能不删除用户文件）')


def series_size(p: dict):
    """连续剧每组几集；单集（或没写 series）返回 None。"""
    s = p.get('series')
    if s is None:
        return None
    if not isinstance(s, dict) or s.get('mode') not in ('single', 'series'):
        raise ValueError('series.mode must be single or series')
    if s['mode'] == 'single':
        return None
    n = s.get('episodes_per_group')
    if type(n) is not int or not 1 <= n <= 100:
        raise ValueError('series.episodes_per_group must be an integer from 1 to 100')
    return n


def group_label(start: int, end: int, width: int) -> str:
    return f'第{start:0{width}d}集' if start == end else f'第{start:0{width}d}-{end:0{width}d}集'


def _up(value):
    """分集页面在子文件夹里：引用总文件夹里的媒体要加 ../。"""
    return '../' + value if isinstance(value, str) and value and not value.startswith(('data:', 'http://', 'https://', '../')) else value


def _down(value):
    return value[3:] if isinstance(value, str) and value.startswith('../') else value


def split_series(p: dict, n: int) -> tuple[dict, list[tuple[str, dict]]]:
    """把整部剧拆成：总文件夹的资产清单数据 + 各分集组（文件夹名, 数据）。"""
    shots = p['shots']
    for s in shots:
        ep = s.get('episode')
        if type(ep) is not int or ep < 1:
            raise ValueError(f'{s.get("id", "?")}: 连续剧每个镜头都要写 episode（第几集，正整数）')
    if not shots:
        raise ValueError('连续剧至少要有一个镜头')
    width = max(2, len(str(max(s['episode'] for s in shots))))
    by_group: dict[int, list] = {}
    for s in shots:
        by_group.setdefault((s['episode'] - 1) // n, []).append(s)
    names = page_filenames(p)
    asset_name = names['asset-inventory']
    graph = {a['id']: a.get('reference_ids', []) for a in p['assets']}
    groups, index = [], []
    for k in sorted(by_group):
        members = by_group[k]
        eps = [s['episode'] for s in members]
        start, end = k * n + 1, min((k + 1) * n, max(eps))
        label = group_label(start, end, width)
        used, stack = set(), [x for s in members for f in ('references', 'board_reference_ids', 'board_ids') for x in s.get(f, [])]
        while stack:
            key = stack.pop()
            if key in used or key not in graph:
                continue
            used.add(key)
            stack.extend(graph[key])
        gp = json.loads(json.dumps(p, ensure_ascii=False))
        gp['title'] = f'{p["title"]}_{label}'
        gp['assets'] = [a for a in gp['assets'] if a['id'] in used]
        for a in gp['assets']:
            if a.get('file'):
                a['file'] = _up(a['file'])
        ids = {s['id'] for s in members}
        gp['shots'] = [s for s in gp['shots'] if s['id'] in ids]
        for s in gp['shots']:
            if s.get('video_file'):
                s['video_file'] = _up(s['video_file'])
            for a in s.get('audio_files', []):
                if a.get('file'):
                    a['file'] = _up(a['file'])
            for field in ('audio_refs', 'video_refs'):
                if isinstance(s.get(field), list):
                    s[field] = [_up(v) for v in s[field]]
        # 跨组的接续同意记录不带进分集页（分组从整集边界切开，组内链各自成立）。
        gp['continuation_approvals'] = [a for a in gp.get('continuation_approvals', []) if set(a.get('shot_ids', [])) <= ids]
        gp.pop('final_file', None)
        gp['episode_range'] = {'start': start, 'end': end}
        gp['series'] = {'mode': 'series', 'title': p['title'], 'episodes_per_group': n, 'group': label,
                        'episode_range': {'start': start, 'end': end}, 'assets_page': '../' + asset_name}
        gnames = page_filenames(gp)
        groups.append((label, gp))
        index.append({'folder': label, 'label': label, 'episode_range': {'start': start, 'end': end}, 'shots': len(members),
                      'list': f'{label}/{gnames["chinese-shotlist"]}', 'video': f'{label}/{gnames["minimax-h3-shotlist"]}'})
    ap = json.loads(json.dumps(p, ensure_ascii=False))
    ap['shots'] = []
    ap['continuation_approvals'] = []
    ap['series'] = {'mode': 'series', 'title': p['title'], 'episodes_per_group': n, 'groups': index}
    return ap, groups


def read_series(path: Path) -> dict:
    """从连续剧任一页面恢复整部剧的数据：资产取总文件夹的资产清单，镜头按组拼回（媒体路径还原为相对总文件夹）。"""
    path = Path(path)
    data = read_page(path)
    s = data.get('series') or {}
    if s.get('mode') != 'series':
        return data
    root = path.parent / Path(s['assets_page']).parent if s.get('assets_page') else path.parent
    asset_page = root / page_filenames({'title': s['title']})['asset-inventory']
    whole = read_page(asset_page)
    shots, approvals = [], []
    for g in whole.get('series', {}).get('groups', []):
        gp = read_page(root / g['list'])
        for sh in gp['shots']:
            if sh.get('video_file'):
                sh['video_file'] = _down(sh['video_file'])
            for a in sh.get('audio_files', []):
                if a.get('file'):
                    a['file'] = _down(a['file'])
            for field in ('audio_refs', 'video_refs'):
                if isinstance(sh.get(field), list):
                    sh[field] = [_down(v) for v in sh[field]]
            shots.append(sh)
        approvals.extend(gp.get('continuation_approvals', []))
    whole['shots'] = shots
    whole['continuation_approvals'] = approvals
    whole['series'] = {'mode': 'series', 'episodes_per_group': whole['series'].get('episodes_per_group')}
    return whole


def build_pages(p: dict, output: Path) -> list[Path]:
    output = Path(output)
    n = series_size(p)
    if n is None:
        validate(p, output)
        stale = other_shotlists(output, set(page_filenames(p).values()))
        if stale:
            raise stale_error(stale)
        return render_pages(p, output)
    validate(p, output)
    ap, groups = split_series(p, n)
    validate(ap, output)
    # 连续剧：每个「第xx集」文件夹是一个加载器制作包，只能有本组这一张分镜列表页；总文件夹不放分镜列表页。
    keep = {page_filenames(ap)['asset-inventory']}
    for label, gp in groups:
        validate(gp, output / label)
        keep |= {label} | {f'{label}/{name}' for name in page_filenames(gp).values()}
    stale = other_shotlists(output, keep, skip_groups=True)
    if stale:
        raise stale_error(stale)
    asset_name = page_filenames(p)['asset-inventory']
    group_links = [(label, page_filenames(gp)) for label, gp in groups]
    first_label, first_names = group_links[0]
    asset_nav = {'list': f'{first_label}/{first_names["chinese-shotlist"]}', 'video': f'{first_label}/{first_names["minimax-h3-shotlist"]}',
                 'groups': [{'label': label, 'list': f'{label}/{names["chinese-shotlist"]}'} for label, names in group_links]}
    written = render_pages(ap, output, only=('asset-inventory',), nav=asset_nav)
    for label, gp in groups:
        nav = {'asset': '../' + asset_name,
               'groups': [{'label': other, 'list': f'../{other}/{names["chinese-shotlist"]}', 'current': other == label} for other, names in group_links]}
        written += render_pages(gp, output / label, only=('chinese-shotlist', 'minimax-h3-shotlist'), nav=nav)
    existing = sorted(d.name for d in output.iterdir() if d.is_dir() and re.fullmatch(r'第\d+(?:-\d+)?集', d.name) and d.name not in {l for l, _ in groups})
    if existing:
        print('注意：这些旧的分集文件夹不在本次分组里，画布导入时会被当成分集组，请让用户确认后自行处理：' + '、'.join(existing), file=sys.stderr)
    return written


def render_pages(p: dict, output: Path, only=None, nav=None) -> list[Path]:
    """已校验的数据写成页面（build_pages 先校验）。"""
    output = Path(output)
    if p.get('shots'):
        for warning in loader_warnings(p):
            print('警告：' + warning, file=sys.stderr)
    p = loader_payload(p)
    payload = json.dumps(p, ensure_ascii=False, allow_nan=False).replace('<', '\\u003c').replace('>', '\\u003e').replace('&', '\\u0026')
    runtime = (ROOT / 'assets/runtime.js').read_text(encoding='utf-8')
    choices = resolve_choices(p['project_choices'], require_confirmed=not p.get('is_template_preview', False)) if p.get('project_choices') else []
    choice_payload = json.dumps(choices, ensure_ascii=False).replace('<', '\\u003c').replace('>', '\\u003e').replace('&', '\\u0026')
    runtime = runtime.replace('/*PROJECT_CHOICES*/[]', choice_payload)
    plan_payload = json.dumps(resolve_plan(p), ensure_ascii=False).replace('<', '\\u003c').replace('>', '\\u003e').replace('&', '\\u0026')
    runtime = runtime.replace('/*CONTINUATION_PLAN*/[]', plan_payload)
    css = (ROOT / 'assets/extra.css').read_text(encoding='utf-8')
    names = page_filenames(p)
    nav = json.dumps(
        {'asset': names['asset-inventory'], 'video': names['minimax-h3-shotlist'],
         'list': names['chinese-shotlist'], 'titles': PAGE_TITLES, **(nav or {})},
        ensure_ascii=False).replace('<', '\\u003c')
    runtime = runtime.replace('/*PAGE_FILES*/{}', nav)
    rendered = []
    for name, filename in names.items():
        if only and name not in only:
            continue
        template = (ROOT / f'assets/templates/{PAGE_TEMPLATES[name]}').read_text(encoding='utf-8')
        if not DATA.search(template) or '/*COMIC_RUNTIME*/' not in template or '/*COMIC_STYLE*/' not in template:
            raise ValueError(f'Broken template: {name}')
        html = DATA.sub(lambda m: m[1] + payload + m[2], template, count=1)
        html = html.replace('/*COMIC_RUNTIME*/', runtime).replace('/*COMIC_STYLE*/', css)
        rendered.append((output / filename, html))
    output.mkdir(parents=True, exist_ok=True)
    for target, html in rendered:
        target.write_text(html, encoding='utf-8')
    return [target for target, _ in rendered]


def main():
    if hasattr(sys.stdin, 'reconfigure'):
        sys.stdin.reconfigure(encoding='utf-8-sig')
        sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', nargs='?', help="Use '-' for JSON on stdin")
    parser.add_argument('output', nargs='?', type=Path)
    parser.add_argument('--extract', type=Path)
    args = parser.parse_args()
    if args.extract:
        # 连续剧从任一页面都能拼回整部剧的数据（资产 + 全部分集的镜头）。
        print(json.dumps(read_series(args.extract), ensure_ascii=False))
    elif args.source == '-' and args.output:
        for path in build_pages(json.load(sys.stdin), args.output):
            print(path)
    else:
        parser.error('Use --extract PAGE or - OUTPUT_DIR')


if __name__ == '__main__':
    main()
