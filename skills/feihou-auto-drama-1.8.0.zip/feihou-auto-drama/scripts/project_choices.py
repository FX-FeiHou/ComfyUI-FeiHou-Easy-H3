"""Print native-question payloads and route confirmed project choices to writing rules."""
from __future__ import annotations

import argparse
import json
import sys

CATALOG = {
    'visual_form': {
        'title': '画面形式', 'reference': 'references/visual-forms.md',
        'question': '这部作品采用哪种画面形式？可直接输入细分风格；风格化或混合影像请补充具体媒介。',
        'options': [
            ('live_action', '真人写实', '真实演员与实景摄影观感'),
            ('anime_2d', '二维动漫', '线条、色块与绘制背景'),
            ('animation_3d', '三维动画', '体积、材质与空间光照'),
            ('motion_comic', '动态漫画 / 2.5D', '关键画面、局部动作与视差'),
            ('stylized', '风格化美术', '水墨、剪纸、黏土、定格、像素、绘本等'),
            ('hybrid', '混合影像', '真人、实拍、动画或 AI 场景组合'),
        ],
    },
    'narrative_mode': {
        'title': '叙事方式', 'reference': 'references/narrative-modes.md',
        'question': '这部作品主要用什么方式讲故事？混合叙事可说明哪一种为主。',
        'options': [
            ('dialogue', '对白表演型', '人物对话、表情和反应推动剧情'),
            ('voiceover', '旁白解说型', '旁白讲故事，画面呈现事件'),
            ('action', '动作驱动型', '行为、追逐、战斗或探索推动剧情'),
            ('visual', '氛围 / 视觉叙事型', '少台词，以画面和声音表达变化'),
            ('mixed', '混合叙事型', '对白、旁白、动作及视觉叙事分工'),
        ],
    },
    'genre': {
        'title': '故事题材', 'reference': 'references/genres.md',
        'question': '故事属于哪类题材？可输入细分或组合题材，例如“宫廷悬疑，以悬疑为主”。',
        'options': [
            ('urban', '都市情感 / 家庭 / 职场', '关系、利益和情绪冲突'),
            ('historical', '古装 / 历史 / 宫廷', '时代环境、身份和权力关系'),
            ('fantasy', '武侠 / 仙侠 / 玄幻', '侠义、动作与超自然规则'),
            ('suspense', '悬疑 / 犯罪 / 惊悚', '线索、信息差和威胁'),
            ('scifi', '科幻 / 末日 / 灾难', '技术设定、环境压力与生存选择'),
            ('comedy', '喜剧 / 荒诞 / 萌宠', '反差、误会与喜剧节奏'),
            ('children', '儿童 / 童话 / 治愈', '清楚的情绪与行动，具体受众按作品确定'),
        ],
    },
    'release_form': {
        'title': '单片 / 连载', 'reference': 'references/release-forms.md',
        'question': '做一部独立作品还是分集连载？连载可补充连续剧情或每集独立故事。',
        'options': [
            ('single', '单片', '本片完成主要故事与情绪收束'),
            ('series', '连载', '每集有进展，保留跨集承接'),
        ],
    },
}


def question_payload() -> dict:
    return {'questions': [
        {'title': entry['question'], 'options': [f'{label}｜{hint}' for _, label, hint in entry['options']]}
        for entry in CATALOG.values()
    ]}


def resolve_choices(choices: dict, require_confirmed: bool = True) -> list[dict]:
    if not isinstance(choices, dict):
        raise ValueError('project_choices must be an object')
    if require_confirmed and (choices.get('confirmed') is not True or choices.get('selection_source') not in ('user', 'delegated')):
        raise ValueError('Four project choices need a real user response or explicit delegation first')
    result = []
    for key, entry in CATALOG.items():
        choice = choices.get(key)
        if not isinstance(choice, dict):
            raise ValueError(f'Missing choice: {key}')
        options = {identifier: label for identifier, label, _ in entry['options']}
        identifier = choice.get('id')
        if not isinstance(identifier, str):
            raise ValueError(f'{key}: id must be text')
        detail = choice.get('detail', '')
        if not isinstance(detail, str):
            raise ValueError(f'{key}: detail must be text')
        if identifier == 'custom':
            label = choice.get('label')
            if not isinstance(label, str) or not label.strip() or not detail.strip():
                raise ValueError(f'{key}: custom choices need a label and meaningful detail')
            base = choice.get('base_id')
            if base is not None and (not isinstance(base, str) or base not in options):
                raise ValueError(f'{key}: unknown base_id')
            route = base or 'custom'
        elif identifier in options:
            label, route = options[identifier], identifier
        else:
            raise ValueError(f'{key}: unknown option {identifier}')
        result.append({'key': key, 'title': entry['title'], 'id': identifier, 'label': label,
                       'detail': detail, 'rule': entry['reference'] + '#' + route})
    return result


def main():
    if hasattr(sys.stdin, 'reconfigure'):
        sys.stdin.reconfigure(encoding='utf-8-sig')
        sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser(description=__doc__)
    actions = parser.add_mutually_exclusive_group(required=True)
    actions.add_argument('--questions', action='store_true')
    actions.add_argument('--resolve', action='store_true')
    args = parser.parse_args()
    payload = question_payload() if args.questions else {'selected_rules': resolve_choices(json.load(sys.stdin))}
    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
