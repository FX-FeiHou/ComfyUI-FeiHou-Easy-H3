"""Resolve production-pack transitions and check consent before continuation runs."""
from __future__ import annotations

import argparse
import json
import re
import sys

MAX_CONTINUATIONS = 4  # 单条链默认可连续接续的最大次数（原始片段之后最多再接续 4 段）
WARNING = f'超过{MAX_CONTINUATIONS}次接续，画质将无法保证。'
# 与 FeiHou Easy H3 制作包分镜加载器（production_pack.py 的 _FRAME_CHOICES）一致。
# 0+0 不带任何引导帧，加载器按硬切处理，因此也不计入接续次数。
FRAME_PAIRS = {(0, 0), (0, 5), (5, 0), (5, 5), (22, 0), (22, 5), (22, 22),
               (39, 0), (39, 5), (39, 22), (39, 39)}
TRANSITIONS = {
    **dict.fromkeys(('接续', '续接', '连续', '无缝', 'continue', 'continuation', 'continuous', 'seamless'), '接续'),
    **dict.fromkeys(('硬切', '切', '切镜', '剪切', 'cut', 'hard_cut', 'hardcut', 'hard cut'), '硬切'),
}


def normalize_transition(value) -> str:
    if isinstance(value, str) and value.strip().casefold() in TRANSITIONS:
        return TRANSITIONS[value.strip().casefold()]
    raise ValueError(f'无法识别的 transition: {value!r}')


def normalize_frames(value) -> str:
    if isinstance(value, str):
        parts = re.fullmatch(r'\s*(\d+)\s*(?:[+＋]\s*(\d+)\s*)?', value)
        if not parts:
            raise ValueError(f'无法识别的 continuation_frames: {value!r}')
        pair = (int(parts[1]), int(parts[2] or parts[1]))
    elif type(value) is int:
        pair = (value, value)  # 单值 0/5/22/39 = 0+0/5+5/22+22/39+39，与加载器一致
    elif isinstance(value, list) and len(value) == 2:
        pair = tuple(value)
    elif isinstance(value, dict) and 'first' in value and 'second' in value:
        pair = (value['first'], value['second'])
    else:
        raise ValueError(f'无法识别的 continuation_frames: {value!r}')
    if any(type(n) is not int for n in pair) or pair not in FRAME_PAIRS:
        raise ValueError(f'不支持的 continuation_frames: {value!r}')
    return f'{pair[0]}+{pair[1]}'


def resolve_plan(project: dict, transition_override='自动', frames_override='自动') -> list[dict]:
    """Resolve metadata for display; pending consent does not prevent drafting pages."""
    if not isinstance(project, dict) or not isinstance(project.get('shots'), list):
        raise ValueError('项目必须包含 shots 数组')
    default_transition = normalize_transition(project.get('transition', '接续'))
    default_frames = normalize_frames(project.get('continuation_frames', '22+22'))
    force_transition = None if transition_override in ('自动', 'auto') else normalize_transition(transition_override)
    force_frames = None if frames_override in ('自动', 'auto') else normalize_frames(frames_override)
    shots = project['shots']
    shot_ids = [s.get('id') if isinstance(s, dict) else None for s in shots]
    if any(not isinstance(sid, str) or not sid for sid in shot_ids) or len(set(shot_ids)) != len(shot_ids):
        raise ValueError('接续计划需要唯一且非空的镜号')
    approvals = project.get('continuation_approvals', [])
    if not isinstance(approvals, list):
        raise ValueError('continuation_approvals 必须是数组')
    approved_chains = []
    for approval in approvals:
        if not isinstance(approval, dict):
            raise ValueError('接续同意记录必须是对象')
        ids = approval.get('shot_ids')
        if not isinstance(ids, list) or len(ids) < MAX_CONTINUATIONS + 1 or any(not isinstance(sid, str) or sid not in shot_ids for sid in ids) or len(set(ids)) != len(ids):
            raise ValueError(f'接续同意记录必须明确至少{MAX_CONTINUATIONS + 1}个有序镜号，包含原始片段')
        for flag in ('confirmed', 'quality_warning_acknowledged'):
            if type(approval.get(flag)) is not bool:
                raise ValueError(f'接续同意记录 {flag} 必须是布尔值')
        response = approval.get('user_response')
        if not isinstance(response, str) or not response.strip():
            raise ValueError('接续同意记录必须保留真实用户答复')
        if approval['confirmed'] and approval['quality_warning_acknowledged']:
            approved_chains.append(ids)
    plan, chain = [], []
    for index, shot in enumerate(shots):
        sid = shot['id']
        try:
            transition = normalize_transition(shot.get('transition', default_transition))
            frames = normalize_frames(shot.get('continuation_frames', default_frames))
        except ValueError as error:
            raise ValueError(f'{sid}: {error}') from error
        transition = force_transition or transition
        frames = force_frames or frames
        if index == 0 or transition == '硬切' or frames == '0+0':
            chain = [sid]
        else:
            chain.append(sid)
        count = len(chain) - 1
        approved = any(chain == ids[:len(chain)] for ids in approved_chains) if count > MAX_CONTINUATIONS else False
        plan.append({
            'id': sid, 'transition': transition, 'continuation_frames': frames,
            'first': index == 0, 'chain_start': chain[0], 'continuation_count': count,
            'requires_approval': count > MAX_CONTINUATIONS, 'approved': approved,
        })
    return plan


def require_execution_approval(project: dict, transition_override='自动', frames_override='自动', through_shot_id=None) -> list[dict]:
    """Block the first unapproved over-limit continuation up to the requested run boundary."""
    plan = resolve_plan(project, transition_override, frames_override)
    if through_shot_id is not None:
        index = next((i for i, row in enumerate(plan) if row['id'] == through_shot_id), None)
        if index is None:
            raise ValueError(f'未知镜号: {through_shot_id}')
        selected = plan[:index + 1]
    else:
        selected = plan
    for row in selected:
        if row['requires_approval'] and not row['approved']:
            raise ValueError(f'{row["id"]}: 第{row["continuation_count"]}次接续尚未取得用户同意。{WARNING}')
    return plan


def main():
    if hasattr(sys.stdin, 'reconfigure'):
        sys.stdin.reconfigure(encoding='utf-8-sig')
        sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-execution', action='store_true')
    parser.add_argument('--through-shot', help='Only check the run through this shot ID')
    parser.add_argument('--transition', default='自动', help='Actual loader override, or 自动')
    parser.add_argument('--continuation-frames', default='自动', help='Actual loader override, or 自动')
    args = parser.parse_args()
    if args.through_shot and not args.check_execution:
        parser.error('--through-shot requires --check-execution')
    try:
        project = json.load(sys.stdin)
        if args.check_execution:
            plan = require_execution_approval(project, args.transition, args.continuation_frames, args.through_shot)
        else:
            plan = resolve_plan(project, args.transition, args.continuation_frames)
    except ValueError as error:
        parser.exit(2, f'{error}\n')
    print(json.dumps({'shots': plan}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
