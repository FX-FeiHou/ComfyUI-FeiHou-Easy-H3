"""Offline structural tests; these do not evaluate generated film quality."""
import copy
import itertools
import tempfile
import unittest
from pathlib import Path

from project_choices import CATALOG, question_payload, resolve_choices
from continuation import normalize_frames, require_execution_approval, resolve_plan
from build_pages import ROOT, build_pages, read_page, validate


def choices():
    return dict(confirmed=True, selection_source='user', **{
        key: {'id': entry['options'][0][0]} for key, entry in CATALOG.items()
    })


class ChoiceTests(unittest.TestCase):
    def test_questions(self):
        self.assertEqual([len(q['options']) for q in question_payload()['questions']], [6, 5, 7, 2])

    def test_all_routes(self):
        count = 0
        for ids in itertools.product(*(e['options'] for e in CATALOG.values())):
            c = choices()
            c.update({key: {'id': option[0]} for key, option in zip(CATALOG, ids)})
            for row in resolve_choices(c):
                file, anchor = row['rule'].split('#')
                self.assertIn(f'id="{anchor}"', (ROOT / file).read_text(encoding='utf-8'))
            count += 1
        self.assertEqual(count, 420)

    def test_invalid_confirmation(self):
        for field, value in [('confirmed', False), ('confirmed', 'true'), ('selection_source', 'assumed'), ('visual_form', None), ('genre', {'id': 'unknown'})]:
            c = choices()
            c[field] = value
            with self.assertRaises(ValueError):
                resolve_choices(c)

    def test_custom(self):
        c = choices()
        c['visual_form'] = {'id': 'custom', 'label': '纸雕', 'detail': '立体纸层', 'base_id': 'stylized'}
        self.assertTrue(resolve_choices(c)[0]['rule'].endswith('#stylized'))
        c['visual_form']['base_id'] = '../../bad'
        with self.assertRaises(ValueError):
            resolve_choices(c)

    def test_pages_and_gate(self):
        p = {'title': '结构测试', 'assets': [], 'shots': []}
        with tempfile.TemporaryDirectory(prefix='feihou-choice-test-') as folder:
            output = Path(folder)
            with self.assertRaises(ValueError):
                build_pages(p, output)
            self.assertEqual(list(output.iterdir()), [])
            p['project_choices'] = choices()
            with self.assertRaises(ValueError):
                validate(p, output)
            p['creative_approach'] = '保持真人材质，以对话和反应推进关系，本片完成选择。'
            p['project_choices']['genre']['detail'] = '</script><img src=x onerror=alert(1)>'
            paths = build_pages(p, output)
            self.assertEqual(len(list(output.iterdir())), 3)
            for path in paths:
                self.assertEqual(read_page(path), p)
                text = path.read_text(encoding='utf-8')
                self.assertNotIn('</script><img', text)
                self.assertNotIn('/*PROJECT_CHOICES*/', text)
                self.assertIn('真人写实', text)
            preview = {'title': '模板', 'assets': [], 'shots': [], 'is_template_preview': True}
            # 加载器要求一个制作包根目录只有一个分镜列表页：同一目录再建另一部作品要拒绝。
            with self.assertRaises(ValueError):
                build_pages(preview, output)
            self.assertEqual(len(build_pages(preview, output.parent / (output.name + '-other'))), 3)
            # 同一作品重建（覆盖自己的三页）照常。
            self.assertEqual(len(build_pages(p, output)), 3)

    def test_loader_contract(self):
        def project(**shot):
            return {'title': '契约', 'is_template_preview': True, 'assets': [],
                    'shots': [{'id': 'S001', 'seconds': 4, **shot}]}
        with tempfile.TemporaryDirectory(prefix='feihou-loader-test-') as folder:
            output = Path(folder)
            (output / 'a.wav').write_bytes(b'')
            page = build_pages(project(range='00:00:000–00:00:000', prompt_zh='x'), output)[1]
            shot = read_page(page)['shots'][0]
            self.assertNotIn('range', shot)
            self.assertEqual(shot['audio_references'], [])
            for bad in ({'seconds': 31}, {'aspect_ratio': '2.39:1'}, {'prompt_zh': '<Video 1>'},
                        {'prompt_zh': '<audio 1>'}, {'audio_refs': ['a.wav']}):
                with self.assertRaises(ValueError, msg=bad):
                    validate(project(**bad), output)

    def test_continuation_defaults_and_chain_limit(self):
        p = {'shots': [{'id': f'S{i:03d}'} for i in range(1, 7)]}
        plan = resolve_plan(p)
        self.assertEqual([row['continuation_count'] for row in plan], [0, 1, 2, 3, 4, 5])
        self.assertEqual(plan[0]['continuation_frames'], '22+22')
        self.assertFalse(plan[3]['requires_approval'])
        self.assertTrue(plan[5]['requires_approval'])
        with self.assertRaisesRegex(ValueError, '超过4次接续'):
            require_execution_approval(p)
        approval = {
            'shot_ids': ['S001', 'S002', 'S003', 'S004', 'S005'],
            'confirmed': True,
            'quality_warning_acknowledged': True,
            'user_response': '我知悉超过4次接续，画质无法保证，批准本链。',
        }
        p['continuation_approvals'] = [approval]
        self.assertEqual(len(require_execution_approval(p, through_shot_id='S005')), 6)

    def test_continuation_hard_cut_and_overrides(self):
        p = {'transition': '接续', 'continuation_frames': [39, 5], 'shots': [
            {'id': 'A'}, {'id': 'B'}, {'id': 'C', 'transition': '硬切'}, {'id': 'D'},
        ]}
        plan = resolve_plan(p)
        self.assertEqual([r['continuation_count'] for r in plan], [0, 1, 0, 1])
        self.assertEqual([r['continuation_frames'] for r in plan], ['39+5'] * 4)
        forced = resolve_plan(p, transition_override='硬切', frames_override='22+0')
        self.assertEqual([r['continuation_count'] for r in forced], [0, 0, 0, 0])
        self.assertEqual(normalize_frames({'first': 22, 'second': 5}), '22+5')
        with self.assertRaises(ValueError):
            normalize_frames('40+5')

    def test_frame_choices_match_loader(self):
        for value in ('0+5', '5+0', '5+5', '0+0', '39+39'):
            self.assertEqual(normalize_frames(value), value)
        self.assertEqual(normalize_frames('5'), '5+5')
        self.assertEqual(normalize_frames(0), '0+0')
        p = {'shots': [{'id': 'A'}, {'id': 'B'}, {'id': 'C', 'continuation_frames': '0+0'}, {'id': 'D'}]}
        self.assertEqual([r['continuation_count'] for r in resolve_plan(p)], [0, 1, 0, 1])

    def test_series_groups_and_extract(self):
        from build_pages import read_series
        shots = [{'id': f'EP{e:02d}-S001', 'seconds': 4, 'episode': e, 'prompt_zh': 'x'} for e in (1, 2, 3)]
        p = {'title': '连续', 'is_template_preview': True, 'assets': [], 'shots': shots,
             'series': {'mode': 'series', 'episodes_per_group': 2}}
        with tempfile.TemporaryDirectory(prefix='feihou-series-test-') as folder:
            output = Path(folder)
            paths = build_pages(p, output)
            self.assertEqual(len(paths), 5)  # 1 资产清单 + 2 组 × 2 页
            groups = sorted(d.name for d in output.iterdir() if d.is_dir())
            self.assertEqual(groups, ['第01-02集', '第03集'])
            # 重建同一部剧照常（各组的分镜列表页是自己的）。
            self.assertEqual(len(build_pages(p, output)), 5)
            back = read_series(paths[1])
            self.assertEqual([s['id'] for s in back['shots']], [s['id'] for s in shots])
            self.assertTrue(all(s['audio_references'] == [] and 'range' not in s for s in back['shots']))


if __name__ == '__main__':
    unittest.main()
