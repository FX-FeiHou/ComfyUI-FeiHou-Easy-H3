# 规则依据与边界

动作戏专项的四份用户资料分析、公开模板反响与专业来源见 [动作资料取舍](action-research.md)。

核阅日期：2026-09-12。以下为公开教学文章和制作机构资料，不代表已读付费课程、完整教材或专有内部文档。四维分类、字段映射、子题材清单和组合处理是为本技能作的生产性归纳，不是来源声称的行业统一标准。文学教学应用到影视分镜属于迁移推导。

| 公开资料 | 提取原则及使用边界 |
|---|---|
| [Disney Animation — Story](https://disneyanimation.com/process/story/) | 故事板同时处理情绪、表情、节奏、调度与画框；用于各风格的叙事清晰度，不把迪士尼风格作为默认 |
| [Disney Animation — Layout](https://www.disneyanimation.com/process/layout/) | 角色、布景、相机共同组织空间；用于站位、机位与镜头连接，AI 生成不等于获得三维布局工程 |
| [Disney Animation — Animation](https://www.disneyanimation.com/process/animation/) | 时间、预备动作、重量感与跟随动作服务可信表演；夸张程度按项目调整 |
| [Disney — Creative Development](https://www.disneyanimation.com/process/creative-development/) | 历史文化与其他研究支持可信世界；具体时代和科学事实仍需逐项目查证 |
| [BBC Maestro — Good dialogue](https://www.bbcmaestro.com/blog/how-to-write-good-dialogue) | 角色声音、潜台词及对白功能；用于对白表演模式，不能借此改动锁定台词 |
| [BBC Maestro — TV pilot](https://www.bbcmaestro.com/blog/how-to-write-a-tv-pilot) | 首集建立人物和持续发展空间；不照搬电视台时长、幕数到 AI 短剧 |
| [BBC Maestro — Thriller](https://www.bbcmaestro.com/blog/how-to-write-a-thriller) | 人物利害与强弱节奏支撑紧张；从写作指导迁移到镜头和声音，不是必须快速剪辑 |
| [BBC Maestro — Cliffhanger endings](https://www.bbcmaestro.com/blog/writing-cliffhanger-endings) | 悬念需要铺垫，并可在解决部分问题后产生新问题；不强制每集悬崖式结尾 |
| [BBC Maestro — Comedic timing](https://www.bbcmaestro.com/blog/comedic-timing) | 观众理解、准备和停顿影响笑点；无法由固定镜头秒数保证效果 |
| [BBC Maestro — Children’s picture books](https://www.bbcmaestro.com/blog/5-tips-for-writing-childrens-picture-books) | 语言节奏及图文协作；迁移到儿童视听表达，不把成人治愈归为低龄 |
| [Aardman — Steve Harding-Hill interview](https://www.aardman.com/latest-news/2022/june/christmas-campaigns-with-steve-harding-hill/) | 手工材料有多种表现方式，分镜/动态预演需为表演留空间；AI 定格外观不冒充实际定格工艺 |
| [Runway — Image to Video Prompting Guide](https://help.runwayml.com/hc/en-us/articles/48324313115155-Image-to-Video-Prompting-Guide) | 图像提供外观与构图基础，文本描述运动和时间变化；仅在适用的图生视频接口迁移，具体格式仍服从当前生成端 |

## 不应由这些资料推出的结论

- 不存在已验证适用于所有模型的统一提示词配方；不能保证一键无返工。
- 六种画面、五种叙事、七组题材、两种发布形态可形成 420 种基础组合，但组合可路由不等于 420 种成片质量已经测试。
- 奇幻、都市、历史等细分规则主要是上述故事、表演、空间和信息原则的具体化，不声称每条都有独立的实证研究。
- 模型版本、价格、接口时长及音画能力变化时须核验当前工具，不把教学文章中的版本参数写成永久限制。
