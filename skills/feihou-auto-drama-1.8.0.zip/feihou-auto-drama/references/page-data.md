# 三页数据

根字段：`title`（必需）、`revision`（修改递增整数）、`prompt_format`（`h3` 或 `seedance`，决定第三页提示词写法与引用记法）、`aspect_ratio`、`resolution`、`style_note`、`timing_note`、`story`（原文）、`analysis`（紧凑分析）、`script`（制作剧本）、`handoff`（手动后期说明）、`final_file`（真实成片相对路径，可省略）、`assets`、`shots`。

可选根字段 `transition` 与 `continuation_frames` 是分镜的项目默认值；分镜里的同名字段优先。全部省略时分别按接续和22+22。可选 `continuation_approvals` 记录超限接续的实际用户同意，详见 [分镜接续规则](shot-continuation.md)，不是加载器配置字段。

根字段 `series`：交付结构，**新作品必须写**（用户在「1c. 单集还是连续剧」里的真实选择）：

- 单集：`{"mode": "single"}`，输出三张页面到同一个文件夹（与旧版相同；省略 `series` 也按单集处理，兼容旧包）。
- 连续剧：`{"mode": "series", "episodes_per_group": 5}`，`episodes_per_group` 是用户选的「几集一个文件夹」（1–100 的整数）。此时**每个镜头必须有 `episode`**（第几集，正整数），构建器按它分组。
- 连续剧由构建器生成以下字段，**不要手写**：资产清单页的 `series.groups`（各组文件夹、集数范围、镜头数、页面路径）；分集页的 `series.group`、`series.episode_range`、`series.assets_page` 与根字段 `episode_range`。分集页里的 `assets` 是本组用到的资产副本（图片路径带 `../`），只用于页面展示；资产以总文件夹的资产清单为准。

`assets` 每项：

- `id`: 唯一 P#。
- `name`, `category`: 名称及角色/场景/道具/故事板。
- `kind`: locked 或 generated；generated 表示需要生成的类别，不等于生成成功。
- `use`: 用途和需要保留的特征。
- `reference_ids`: 有序 P# 数组，无参考用 []。
- `prompt_en`, `prompt_zh`: 完整双语提示词；locked 可为空。
- `file`: 真实图片相对三页的路径，用 /，可包含 ../；尚未生成时省略。
- `status`, `job_id`: 可选真实状态与任务号。

`shots` 每项：

- `id`: 稳定镜号，如 EP01-S001，`title`, `section`（实际场次）, `seconds`（正数）。连续剧里镜号全剧唯一。
- `episode`: 连续剧必填，本镜属于第几集（正整数）；单集可省略。
- `performer`, `speech`: 角色和对白（注明说话人）；无对白写“无对白”。
- `camera`, `scene`, `action`, `continuity`: 机位、场景、动作、衔接/终帧。
- `transition`: 本镜开头的接续方式，规范值 `接续` / `硬切`；首镜不应用。新制作主动写出，旧包省略仍可读取。
- `continuation_frames`: 本镜接续帧数，规范字符串 `0+5`、`5+0`、`5+5`、`22+0`、`22+5`、`22+22`、`39+0`、`39+5`、`39+22`、`39+39`（`0+0` 等同硬切），硬切时不使用；同义输入与顶层默认见 [分镜接续规则](shot-continuation.md)。
- `references`: 分镜列表页与分镜页共用的 **有序图片槽位**（`@图片1` / `<Picture 1>` 都按这个顺序换算）；具体职责写到提示词正文。
- `board_reference_ids`: 故事板生图的有序 P# 参考。
- `board_prompt_zh`: 故事板生图正文（中文），参考用 `@P#`。**仍要写，写了就参与 `@P#` 与 `board_reference_ids` 的一致性校验，但三页不再展示**——分镜列表页改为展示 `nl_prompt_zh`。需要关键帧时用画布/加载器的生图能力按这个字段生成。`board_prompt_en` 已废弃，留空即可（填了也会参与同样的校验）。
- `board_ids`: 实际故事板对应的资产 P#；图生成后再回填。
- `board_grid_count`: **本镜缩略故事板需要几宫格**，只允许 `1/2/4/6/8/9/12/16`；按镜头复杂度分档（普通叙事镜 4 宫格、中等 6 或 8 宫格、战斗/复杂镜 9 宫格）。页面在提示词框**外**以胶囊标签显示「宫格故事板 · N 宫格」。
  > **宫格图的生图提示词不在页面数据里**。黑白线稿与彩色两套拼图提示词由画布导入节点在后处理阶段按 `board_grid_count` 与分镜内容自行产出（导入节点侧要求见 [宫格故事板字段交接文档](board-grid-handoff.md)）。构建器只校验 `board_grid_count` 的档位，不要求也不校验任何 `board_grid_prompt_*` 字段。
  > **行业术语**：这种「多格缩略预览」在专业影视流程里叫 **Storyboard（故事板）**；把 N 个关键帧拼成一张的形态，动画业称**分镜表 / 板面**（日语「絵コンテ」，中文常称「分镜图」），英语常写作 **Storyboard Panel Sheet / Thumbnail Sheet / Contact Sheet**。本技能统一称「**宫格故事板**」，字段前缀 `board_grid_`。
- `nl_prompt_zh`: **分镜列表页的完整中文自然语言提示词**（Seedance 口径），按 `[Shot N]` 或自然段落写清主体、动作、机位、光线、声音；引用写作 `@图片n` / `@视频n` / `@音频n`（n 为该镜对应引用列表内的 1-based 位置）。未到该阶段允许留空，页面显示「待编写」。
- `model`, `generation_mode`: 实际目标模型及模式，未选写待选，不冒用官方格式。
- `prompt_zh`: **分镜提示词页的正式中文提示词**，写法随根字段 `prompt_format`：`h3` 用官方六段式（标签名与 `<Picture n>` 等结构标记保持英文），`seedance` 用自然语言结构（引用写 `@图片n` / `@视频n` / `@音频n`）。阶段未到允许为空，页面显示待编写。
- `prompt_en`: **已废弃，不再生成**（本技能只写中文提示词，H3 官方六段式的标签名仍保持英文）。旧包里的该字段会被忽略。
- `sound_prompt`: 说话角色/台词/情绪/画内画外/环境声/动作音效/配乐，或独立声音生成提示词。
- `audio_refs`, `video_refs`: 真实参考音频/视频相对文件路径；不与生成结果混用。`video_refs` 最多 3 段；`audio_refs` 由构建器转成加载器读的 `audio_references`（见下文「加载器字段契约」），不要手写 `audio_references`。
- 不写 `range`：镜头时长只看 `seconds`，页面上的时间胶囊是占位显示。
- `video_file`: 真实视频结果相对路径。
- `audio_files`: 实际声音结果数组，每项 `{label, file}`。
- `status`, `job_id`, `edit_note`: 实际生成状态、任务号与手动剪辑说明。

构建器从 seconds 累计生成页面时间区间，表示计划剪辑时间线；timing_note 必须区分预估与实测。生成结果时长不合适时调整使用段/镜头计划，不用显示时长冒充实测。文件路径不接受 URL、绝对路径或 data URI；媒体生成工具返回 URL 时，在授权生成流程内通过该工具支持的正常下载方式保存结果，再登记文件。

每页内联完整同版本数据，以便在没有 sidecar 文件时恢复。跨页导航固定引用另外两张 HTML。P# 与引用数组作为数据契约保留；无限画布导入兼容性未经实际验证不得声称已实现。

接续次数按有效衔接顺序计算：首镜0、接续累加、硬切清零，不因场次或帧数变化重置。每条链最多4次，超过必须明确告知画质无法保证并取得用户同意。`continuity` 是创作文字，不改变接续配置。构建器校验字段并展示有效值与待同意状态，执行前还须用 continuation.py --check-execution 校验加载器实际覆盖后的批准范围。仅凭网页可打开不等于允许执行超限接续。

## 加载器字段契约（FeiHou Easy H3 v1.4.33）

「FeiHou Easy H3 制作包分镜加载器」只读制作包里唯一一张 `<meta name="feihou-pack-page" content="shotlist">` 页（02）的 `dh-project-data`。它实际读取的字段和规则如下，构建器按同样的规则检查：

| 加载器读的字段 | 本技能的写法 | 规则 |
|---|---|---|
| 镜头 `id`、`title` | 同名 | `id` 唯一、非空 |
| `seconds` | 同名 | 0.2–30 秒；超过就拆镜 |
| `range` | **不写** | 加载器会优先读它；占位 `00:00:000–00:00:000` 会被读成 0 秒。构建器写页面时去掉 |
| `references`（= refs） | 同名，P# 有序列表 | 最多 9 张；每个 P# 必须有图：资产 `file` 指向包内图片，或包内有名为 `P#.png/.jpg/.webp` 的图 |
| `video_refs` | 同名 | 最多 3 段，包内相对路径或文件名 |
| `audio_references` | 写 `audio_refs`，构建器生成 | 每镜都会写出（没有就 `[]`）。不写的话，包里恰好一个音频会被自动当成配乐，多个音频直接报错。有参考音频的镜头必须同时有图或视频 |
| `prompt_zh` | 同名（03 页正式提示词） | 非空；`<Picture n>`/`<Image n>`、`<Video n>`、`<Audio n>` 不越界 |
| `aspect_ratio`（顶层或每镜） | 同名 | 16:9 / 9:16 / 21:9 / 4:3 / 3:4 / 1:1 / 2:3 / 3:2 |
| `fps`（顶层或每镜） | 可省略 | 1–120 |
| `transition`、`continuation_frames`（顶层或每镜） | 同名 | 见 [分镜接续规则](shot-continuation.md) |

连续剧的每个「第xx集」分集文件夹各是一个加载器制作包（总文件夹只放资产清单页）；分集页的参考图在上一级 `media/`，Easy H3 加载器还没有适配这种结构，连续剧优先导入花果山画布。

加载器不读 `nl_prompt_zh`、`board_*`、`speech`、`sound_prompt` 等字段，它们只给人看和给画布导入用。分辨率由用户在 Easy H3 主节点上设置，制作包不写。

## 动作内容沿用现有字段

不增加独立动作设计输出文件。`creative_approach` 写本场/本项目动作子类型、夸张尺度与摄影策略；`assets.use` 写兵器或科技装备归属、关键外形与状态；`action` 写发起、路径、接触/落空及后果；`camera` 写机位、跟随对象、运动与结束构图；`continuity` 写人物落点、朝向、持物、疲劳/损伤和环境残留；`sound_prompt` 写可定位的声音事件。`board_prompt_*` 只描述所选静态时刻，`nl_prompt_zh` / `prompt_zh` 才描述时间中的动作。未生成的视频不得填入 `video_file`，未经试读/实测的时长仍注明预估。

## 引用槽位与提示词记法

- **分镜列表页（02）**：正文里的引用一律写 `@图片n`、`@视频n`、`@音频n`，`n` 是该镜 `references` / `video_refs` / `audio_refs` 里的 1-based 位置。每个提示词标题下方由页面自动列出槽位清单（`@图片1 = P3 · 巨兽`），不需要在正文里重复资产编号。
- **分镜提示词页（03）**：记法随 `prompt_format` 切换。`h3` 用官方槽位 `<Picture n>`、`<Video n>`、`<Audio n>`；`seedance` 用 `@图片n`、`@视频n`、`@音频n`。两页的槽位顺序都来自同一份 `references`，所以槽位号在两页之间是同一含义。
- **构建器门禁**：`@图片n` / `@视频n` / `@音频n` 的 n 必须落在该镜对应引用列表的范围内，`<Picture n>` 必须满足 `1 <= n <= len(references)`。越界即报错——这类错误在 H3 端会被判成 `prompt references an unavailable Picture slot` 并整包退回，所以在这里先挡住。
- **`references` 必须列全正文实际用到的每一张图**：漏列的图不会被上传，对应槽位也就不存在。严禁为「待生成的首帧/关键帧」编造槽位。

# 启动选择与规则推导字段

正式制作必须包含 project_choices 与非空 creative_approach；旧项目补齐确认后再更新。仅空白结构演示可设 is_template_preview: true，不能借此跳过真实项目确认。

project_choices 示例（仅结构示例，不代表用户已经选择）：

```json
{"confirmed":true,"selection_source":"user","visual_form":{"id":"live_action"},"narrative_mode":{"id":"dialogue"},"genre":{"id":"urban","detail":"职场关系"},"release_form":{"id":"single"}}
```

selection_source 只允许 user 或用户明确授权代选时的 delegated。四项 ID 与自定义规则见 scripts/project_choices.py 和 startup-selection.md。creative_approach 用 2–4 句说明四项如何实际影响本作品，三页均显示。选择数据只嵌入现有三张 HTML，不另存项目 JSON。展示标签由渲染器从统一选项目录推导，不产生第二份可编辑分类数据。
