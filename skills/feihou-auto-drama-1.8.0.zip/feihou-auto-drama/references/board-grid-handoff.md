# 宫格故事板 · 交接文档

> **读者**：负责修改「制作包导入节点 / 无限画布加载器」代码的 AI 或工程师。
> **目的**：说明宫格故事板在制作包里的数据契约（页面只提供宫格数），以及**导入节点侧需要自己生成宫格图提示词**的完整要求。
> **上游**：`feihou-auto-drama` 技能（本技能根目录）
> **生成日期**：2026-10-09（v2：宫格提示词改为导入节点输出）

---

## 0. 本版最重要的变化（先读这段）

**页面数据里不再有宫格图的生图提示词。**

| | v1（旧） | v2（现在） |
|---|---|---|
| 页面字段 | `board_grid_count` + `board_grid_prompt_mono` + `board_grid_prompt_color` | **只有 `board_grid_count`** |
| 谁写宫格提示词 | 制作包写手（技能侧） | **导入节点自己生成** |
| 构建器校验 | 校验宫格数 + 两个提示词字段 | **只校验宫格数** |

理由：宫格图是「导入画布之后」的产物，提示词应该由画布节点按当前画布里的实际素材与模型能力现场生成，而不是被框死在页面数据里。

**⚠️ 所以导入节点必须自己实现「写宫格图提示词」这件事**，要求见第 4 节——这是本次交接的核心。制作包里只告诉你**每一镜要几宫格**（`board_grid_count`），剩下的全在导入侧。

---

## 1. 这是什么

「宫格故事板」= 把**一个分镜的 N 个关键瞬间**拼成**一张图**的缩略预览。

**在制作流程里的固定位置**：

```
01 资产清单 → 生成资产参考图 → 导入画布 → 【宫格故事板预览】 → 03 分镜提示词 → 生成分镜视频
                                              ↑ 导入节点在这里干活
```

用途：在花算力生成视频**之前**，先出一张便宜的拼图，肉眼核对分镜提示词写得合不合理（机位、动作、主体、光比是否说得通）。

**行业术语**（文档里要用的口径）：这种「多格缩略预览」在专业影视流程里叫 **Storyboard（故事板）**；把 N 个关键帧拼成一张的形态，动画业称**分镜表 / 板面**（日语「絵コンテ」，中文常称「分镜图」），英语常写作 **Storyboard Panel Sheet / Thumbnail Sheet / Contact Sheet**。本技能统一称「**宫格故事板**」，字段前缀 `board_grid_`。

---

## 2. 数据在哪里

三张 HTML 各自内联了一份**完全相同**的项目数据：

```html
<script id="dh-project-data" type="application/json">{ ...整个项目数据... }</script>
```

**导入节点应该读「02 分镜列表」那一页**（`<meta name="feihou-pack-page" content="shotlist">`，且 `feihou-pack-schema=1`）。理由：用户明确要求「**导入画布时以分镜列表为基准生成宫格图**」。

> ⚠️ 三页数据一致，但**只有 02 是权威入口**。别去 03 读——03 的用途是提交视频生成。

HTML 里的 JSON 做过转义：`<` → `\u003c`、`>` → `\u003e`、`&` → `\u0026`。**必须先 `json.loads` 再处理**，不要用正则直接扫字符串。

---

## 3. 页面提供的字段：只有一个

`board_grid_count` 挂在 **`shots` 数组的每一项（分镜）** 上，不是根字段、不是 assets 字段。

### `board_grid_count` — 本镜需要几宫格

| 项 | 说明 |
|---|---|
| 类型 | 整数（`int`） |
| 必填 | 是（新项目必须写；旧包可能整个字段缺失） |
| 允许值 | **只允许 `1 / 2 / 4 / 6 / 8 / 9 / 12 / 16`** |
| 含义 | 这一镜的缩略故事板要拼成几张格 |

**禁止值**：`3 / 5 / 7 / 10 / 11` 等一律非法（布尔值 `True`/`False` 也非法——Python 里 `True == 1`，构建器专门挡了）。

**分档规则**（写手侧约定，导入侧只做校验、不做推断）：

| 镜头复杂度 | 宫格数 |
|---|---|
| 普通叙事镜 | **4** |
| 中等（有动作转折、或两个主体同框） | **6 或 8** |
| 战斗 / 复杂镜 | **9** |
| 需要 12 / 16 时 | 必须在 `continuity` 字段里说明理由 |

**推荐的格位排布**（导入侧排版时用）：

| N | 排布 | | N | 排布 |
|---|---|---|---|---|
| 1 | 单格 | | 9 | 3×3 |
| 2 | 1×2 或 2×1 | | 12 | 3×4 或 4×3 |
| 4 | 2×2 | | 16 | 4×4 |
| 6 | 2×3 或 3×2 | | | |
| 8 | 2×4 或 4×2 | | | |

**页面显示**：提示词框**外**的胶囊标签「宫格故事板 · N 宫格」（`title` 提示「本镜缩略故事板需要 N 宫格」）。

---

## 4. 🔴 导入节点必须自己生成宫格图提示词（本次交接的核心）

页面只给宫格数。**两套完整的生图提示词由导入节点现场构造**，再用生图模型出图。三条硬要求：

### 要求 1 · 必须真的写出提示词

不能只把 `board_grid_count` 转发给生图模型就完事。要**为每一镜、每一种风格，拼出一份完整的、可直接送生图模型的提示词**。

一份合格的宫格提示词必须写明：

1. **风格声明**（见要求 2：黑白线稿 / 彩色两套）
2. **宫格数 + 排布**（如「3×3 九宫格」），排布取第 3 节的推荐表
3. **每格画什么**——按 `[Shot N]` 子镜顺序、**从左到右、从上到下**逐格描述该格的关键瞬间；建议显式写格位（「格 1（左上）」「格 5（正中）」）
4. **格内是否带镜号标注**（当前约定：**带**，每格左上角标「1」～「N」）
5. **画幅比例**（每格与整张拼图通常都声明 16:9；项目根字段 `aspect_ratio` 为准）
6. **参考图引用**（见下）

**提示词的内容从哪来**——页面里这些字段就是你写宫格提示词的素材：

| 源字段 | 用途 |
|---|---|
| `prompt_zh`（03 页正式提示词） | **主素材**。里面的 `[Shot 1]`～`[Shot N]` 子镜段落，就是该镜的关键瞬间序列，按顺序拆成各格 |
| `nl_prompt_zh`（02 页中文自然语言） | 辅助理解动作与机位 |
| `camera` / `scene` / `action` / `continuity` | 机位、场景、动作、起止状态 |
| `references` | 该镜实际用到的图，按 1-based 位置对应 `@图片n` |
| `assets[].use` / `.name` / `.file` | 资产形象与真实图片路径 |

> 若某镜的子镜数 > `board_grid_count`（例如 5 个子镜但 4 宫格），做**合并/取舍**：保留转折点与首末帧，把连续动作合并在同一格。若子镜数 < 宫格数，多出的格子画过渡瞬间或重复强调关键帧。

> **拆子镜时要清理 H3 标记**：`prompt_zh` 的子镜段落里混着 `[Shot k]`、`At mm:ss.mmm` 时间码、`<Subject n>`/`<Picture n>` 槽位标签和结尾的 `→ 硬切`。写进宫格提示词前必须去掉这些，只留能直接读的画面描述（参见第 8 节 `split_subshots`）。

### 要求 2 · 必须给「黑白线稿」和「彩色」两套方案

用户要能**自选**黑白或彩色，所以两套都要生成（或至少两套提示词都要备好）：

| 方案 | 风格写法 | 用途 |
|---|---|---|
| **黑白线稿**（mono） | 铅笔线稿 / 清晰轮廓线 / 灰阶明暗；海水与雨用斜排短线示意；不上任何彩色 | 快速看**构图与调度** |
| **彩色**（color） | 写实电影感厚涂；明确冷调暗部、高饱和对比色来源；与项目色彩规则一致 | 看**光影与色彩关系** |

**两套必须是同一个「时刻切片集合」的两种画法**：格位与内容一一对应，**不要混用**（不要拿 mono 的格 1 配 color 的格 5）。

彩色版应遵循项目自己的色彩规则，这些规则写在页面的 `creative_approach` 与资产 `use` 里。例如一部雨夜战斗题材的作品，可能规定以冷灰雨调为底、只让能量光和关键道具承担高饱和对比色；导入节点照这些规则写彩色版，不要自行另定色调。

### 要求 3 · 必须适配不同的宫格数

**不能只写死 9 宫格或 4 宫格**。`board_grid_count` 有 8 个合法档位（`1/2/4/6/8/9/12/16`），提示词要按实际档位自动调整：

- **格数**：`N` 格，按第 3 节的排布表算行列。
- **每格描述数量**：提示词里必须**恰好写出 N 个格子的描述**，不多不少。
- **格号标注范围**：带标注时写「「1」至「N」」。
- **拼图整体画幅**：N 格排布后的整张长宽比要跟着变（例如 9 格 3×3 拼 16:9 单格 → 整张接近 1:1；4 格 2×2 同理；6 格 2×3 整张约 3:2）。提示词里要写明「整张拼图」的画幅，别只说单格 16:9。
- **低档位（1/2 格）**：单格或双格，提示词退化为「一张关键帧」或「左右两张」，不要硬套宫格措辞。

---

## 5. 导入节点需要实现的逻辑

### 5.1 读取

```
读 02 HTML → 抽出 <script id="dh-project-data"> 的 JSON → json.loads
→ 遍历 project.shots[]
→ 对每个 shot，取 board_grid_count（决定要不要做、做几格）
→ 再用 prompt_zh / nl_prompt_zh / camera / scene / action / references 去构造提示词
```

### 5.2 过滤：哪些镜要生成宫格图

```python
VALID_GRID = {1, 2, 4, 6, 8, 9, 12, 16}

def should_generate_grid(shot) -> bool:
    n = shot.get("board_grid_count")
    if n is None:
        return False                      # 旧包没这字段 → 跳过，不报错
    if isinstance(n, bool) or n not in VALID_GRID:
        raise ValueError(f'{shot["id"]}: board_grid_count 非法: {n!r}')
    return True
```

**关键行为**：
- 字段**缺失** → 静默跳过这一镜（兼容旧包），**不要报错、不要崩**。
- 字段**非法** → 报错并指出镜号（合法值不该进到导入阶段；导入侧仍应防御）。

### 5.3 生成引导（generation hint）

导入节点把上面的字段组装成一个「生成任务」交给生图模型：

```python
def build_grid_task(shot: dict, style: str, aspect_ratio: str) -> dict:
    """为一个分镜构造宫格图生成任务。

    style: "mono"（黑白线稿）/ "color"（彩色）
    返回 dict，交给生图模型执行。
    """
    if style not in ("mono", "color"):
        raise ValueError("style must be 'mono' or 'color'")

    n = shot.get("board_grid_count")
    if n is None:
        return None                       # 旧包：不做
    if isinstance(n, bool) or n not in VALID_GRID:
        raise ValueError(f'{shot["id"]}: board_grid_count 非法: {n!r}')

    # 1) 拆子镜：prompt_zh 里的 [Shot k] 段落就是关键瞬间序列
    beats = split_subshots(shot.get("prompt_zh", ""))
    if not beats:
        beats = [shot.get("nl_prompt_zh", "") or shot.get("action", "")]

    # 2) 按宫格数取/合并关键瞬间
    cells = fit_beats_to_cells(beats, n)

    # 3) 逐格写描述 + 风格 + 排布 + 画幅
    rows, cols = GRID_LAYOUT[n]
    prompt = compose_grid_prompt(
        cells=cells,
        rows=rows, cols=cols,
        style=style,
        aspect_ratio=aspect_ratio,
        refs=shot.get("references", []),
    )
    return {
        "shot_id": shot["id"],
        "count": n,
        "rows": rows, "cols": cols,
        "style": style,
        "prompt": prompt,
        "ref_images": resolve_ref_files(shot.get("references", []), shot["_assets"]),
    }
```

`split_subshots` / `fit_beats_to_cells` / `compose_grid_prompt` 是导入节点**自己要实现的**，可参考第 7 节的骨架。

### 5.4 用户自选风格

导入时给用户一个二选一（或「两套都生成」）：

| 选项 | 提示词风格 |
|---|---|
| 黑白线稿 | mono（见第 4 节要求 2） |
| 彩色 | color（见第 4 节要求 2） |

### 5.5 参考图与 `kind=generated` 资产

- 该镜的参考图 = `references` 数组（有序），按位置对应 `@图片n` / `<Picture n>`。
- `assets` 里每项有 `id` / `name` / `kind` / `file`（相对 02 页的路径，用 `/` 分隔，可能有 `../`）。
- **`kind == "generated"` 的资产可能还没生成**（`file` 字段**不存在**，Python 里是 `None` 而不是空串）。此时把该参考图**降级为空**，或提示用户「请先补 P13–P16 的参考图」。**不要让 `None` 流进生图调用。**

### 5.6 与 `board_prompt_*` 的区别（别搞混）

| 字段 | 是什么 | 输出 | 页面显示 |
|---|---|---|---|
| `board_prompt_zh` / `board_prompt_en` | **单张**关键帧生图提示词（制作包已写好、仍参与校验） | 1 张首帧图 | ❌ 不显示 |
| `board_grid_count` | 宫格数 | — | ✅ 显示为胶囊标签 |
| （无字段） | **宫格拼图提示词由导入节点现场生成** | 1 张宫格拼图 | ❌ 不显示 |

`board_prompt_*` 是**制作包给的现成文本**，直接可用；宫格提示词是**导入节点自己写的**，两者来源不同，注意区分。

### 5.7 中文文案（如果 UI 要展示）

| 场景 | 文案 |
|---|---|
| 胶囊标签 | `宫格故事板 · N 宫格` |
| tooltip | `本镜缩略故事板需要 N 宫格` |
| 风格选项 | `黑白线稿` / `彩色` |

---

## 6. 上游门禁（生成侧已挡，导入侧只需防御）

构建器 `scripts/build_pages.py` 只校验**宫格数**，不再要求也不校验任何宫格提示词字段：

```python
# 宫格故事板（缩略故事板预览）字段：这里只保留「本镜需要几宫格」。
# 宫格图的生图提示词（黑白线稿 / 彩色两套）由画布导入节点侧按宫格数与分镜内容自行产出，
# 不写进页面数据，因此构建器不再要求、也不再校验 board_grid_prompt_* 字段。
grid = s.get('board_grid_count')
if grid is not None:
    if isinstance(grid, bool) or grid not in (1, 2, 4, 6, 8, 9, 12, 16):
        raise ValueError(f'{sid}: board_grid_count must be one of 1/2/4/6/8/9/12/16')
```

一条规则：`board_grid_count` ∈ `{1,2,4,6,8,9,12,16}`，布尔值非法。

---

## 7. 完整字段清单（分镜项相关）

| 字段 | 类型 | 必填 | 页面显示 | 用途 |
|---|---|---|---|---|
| `id` | str | ✅ | ✅ | 镜号，如 `S012` |
| `title` | str | ✅ | ✅ | 镜头标题 |
| `seconds` | number | ✅ | ✅ | 计划时长（秒，正数） |
| `camera` / `scene` / `action` / `continuity` | str | ✅ | ✅ | 机位、场景、动作、起止状态（写宫格提示词的素材） |
| `references` | str[] | ✅ | ✅ | 有序图片槽位（`@图片n` / `<Picture n>` 按此顺序换算） |
| `board_reference_ids` | str[] | ✅ | ❌ | 单张关键帧生图的参考资产 |
| `board_prompt_zh` | str | ✅ | ❌ | 单张关键帧生图提示词（制作包提供） |
| **`board_grid_count`** | int | ✅ | ✅ | **宫格数（页面提供的唯一宫格字段）** |
| `nl_prompt_zh` | str | ✅ | ✅ | 02 页中文自然语言提示词（Seedance 兼容） |
| `prompt_zh` | str | ✅ | ✅（03 页） | 正式提示词；其 `[Shot k]` 子镜段落是宫格提示词的主素材 |

> 旧包（v1.5.0 早期）里可能还残留 `board_grid_prompt_mono` / `board_grid_prompt_color` 字段——**一律忽略**，导入侧不读、不校验、不依赖。

---

## 8. 最小可运行参考实现

```python
import json
import re
from pathlib import Path

DATA_RE = re.compile(
    r'<script id="dh-project-data" type="application/json">(.*?)</script>',
    re.S,
)
VALID_GRID = {1, 2, 4, 6, 8, 9, 12, 16}
GRID_LAYOUT = {
    1: (1, 1), 2: (1, 2), 4: (2, 2), 6: (2, 3),
    8: (2, 4), 9: (3, 3), 12: (3, 4), 16: (4, 4),
}
# 整张拼图画幅：单格 16:9 时，rows×cols 排布后的整张比例
CELL_AR = 16 / 9


def load_project(shotlist_html: Path) -> dict:
    """从 02 分镜列表页读出内联项目数据。"""
    html = shotlist_html.read_text(encoding="utf-8")
    m = DATA_RE.search(html)
    if not m:
        raise ValueError("02 页缺少 dh-project-data")
    return json.loads(m.group(1))


def split_subshots(prompt_zh: str) -> list[str]:
    """把 prompt_zh 的 detailed_description 按 [Shot k] 拆成子镜文本。

    清理：去掉 [Shot k] 标记、At mm:ss.mmm 时间码、<Subject n>/<Picture n> 标签、
    结尾的 → 硬切/→ 接续，只留可读的画面描述。
    """
    if not prompt_zh:
        return []
    m = re.search(r'detailed_description:(.*?)(?=\noverall_soundscape:|\Z)', prompt_zh, re.S)
    body = m.group(1) if m else prompt_zh
    blocks = re.split(r'(?=\[Shot \d+\])', body)
    out = []
    for b in blocks:
        b = b.strip()
        if not b.startswith('[Shot'):
            continue
        b = re.sub(r'^\[Shot \d+\]\s*', '', b)
        b = re.sub(r'At \d{2}:\d{2}\.\d{3},?\s*', '', b)
        b = re.sub(r'</?(?:Subject|Picture|Video|Audio) \d+>', '', b)
        b = re.sub(r'→\s*(硬切|接续)\s*$', '', b.strip())
        out.append(b.strip())
    return out


def fit_beats_to_cells(beats: list[str], n: int) -> list[str]:
    """把子镜序列整理成恰好 n 格。"""
    if not beats:
        beats = ["（沿用本镜动作描述）"]
    if len(beats) == n:
        return beats
    if len(beats) < n:
        # 不足：末格重复强调，或补过渡（此处简单重复末格）
        return beats + [beats[-1]] * (n - len(beats))
    # 超出：均匀抽样，保留首末帧
    idx = [round(i * (len(beats) - 1) / (n - 1)) for i in range(n)] if n > 1 else [0]
    return [beats[i] for i in idx]


def compose_grid_prompt(cells, rows, cols, style, aspect_ratio, refs) -> str:
    """拼出一份完整的宫格图生图提示词。"""
    n = rows * cols
    # 整张拼图比例
    try:
        w, h = (float(x) for x in aspect_ratio.split(':'))
        cell_ar = w / h
    except Exception:
        cell_ar = CELL_AR
    sheet_ar = cell_ar * cols / rows
    sheet = f"{sheet_ar:.2f}:1"

    if style == "mono":
        head = (f"黑白线稿，{cols}×{rows} {n} 宫格故事板，统一 {aspect_ratio} 画幅，"
                f"每格左上角带镜号标注「1」至「{n}」，整张拼图约 {sheet}，"
                "铅笔线稿、清晰轮廓线、灰阶明暗关系。")
    else:
        head = (f"彩色故事板，{cols}×{rows} {n} 宫格，统一 {aspect_ratio} 画幅，"
                f"每格左上角带镜号标注「1」至「{n}」，整张拼图约 {sheet}，"
                "写实电影感厚涂。")

    pos = ["左上", "上中", "右上", "左中", "正中", "右中", "左下", "下中", "右下"]
    parts = [head]
    for i, cell in enumerate(cells[:n]):
        tag = pos[i] if n == 9 else f"第 {i + 1} 格"
        parts.append(f"格 {i + 1}（{tag}）：{cell}")
    if refs:
        parts.append("参考图：" + "、".join(f"@{p}" for p in refs) + "。")
    return "".join(parts)

def collect_grid_tasks(project: dict, style: str = "color") -> list[dict]:
    """收集所有需要生成宫格图的分镜，返回生成任务。

    style: "mono" → 黑白线稿；"color" → 彩色。
    """
    if style not in ("mono", "color"):
        raise ValueError("style must be 'mono' or 'color'")
    assets = {a["id"]: a for a in project.get("assets", [])}
    ar = project.get("aspect_ratio", "16:9")
    tasks = []
    for shot in project.get("shots", []):
        n = shot.get("board_grid_count")
        if n is None:
            continue                       # 旧包：无此字段，跳过
        if isinstance(n, bool) or n not in VALID_GRID:
            raise ValueError(f'{shot["id"]}: board_grid_count 非法: {n!r}')
        beats = split_subshots(shot.get("prompt_zh", ""))
        cells = fit_beats_to_cells(beats, n)
        rows, cols = GRID_LAYOUT[n]
        refs = shot.get("references", [])
        prompt = compose_grid_prompt(cells, rows, cols, style, ar, refs)
        ref_images = [assets[p].get("file") for p in refs if p in assets]
        tasks.append({
            "shot_id": shot["id"],
            "count": n,
            "rows": rows,
            "cols": cols,
            "style": style,
            "prompt": prompt,
            "ref_images": ref_images,      # 可能含 None（未生成资产）
            "ref_names": [assets[p].get("name") for p in refs if p in assets],
        })
    return tasks


# 用法
if __name__ == "__main__":
    proj = load_project(Path("<项目文件夹>/02.<项目名>_分镜列表.html"))
    for style in ("mono", "color"):
        print(f"--- {style} ---")
        for t in collect_grid_tasks(proj, style=style):
            print(t["shot_id"], f'{t["rows"]}×{t["cols"]}', f'{t["count"]}格')
```

---

## 9. 制作包数据的常见情况（导入侧要容错）

### 页面上只有宫格数

同一个制作包里，各镜的 `board_grid_count` 通常混合多个档位，例如一个 16 镜的动作短剧可能是：

```
S001=9  S002=4  S003=4  S004=4  S005=6  S006=8  S007=8  S008=8
S009=6  S010=9  S011=6  S012=9  S013=9  S014=9  S015=9  S016=9
```

测试「适配不同宫格数」（第 4 节要求 3）时，至少要覆盖 4 / 6 / 8 / 9 这几个常用档位。

### `kind=generated` 的资产可能没有 `file`

样例项目里 P13–P16 是 `generated`、尚未生成，`file` 字段**不存在**（是 `None`）。

```python
asset.get("file")   # → None
```

**导入侧行为**：把这些引用降级为空，或提示「请先补 P13–P16 的参考图」。**不要让 `None` 流进生图调用**。

### 体检脚本（可直接跑）

```python
def audit_grid(project: dict) -> list[str]:
    """返回问题清单；空列表 = 干净。"""
    issues = []
    for s in project.get("shots", []):
        n = s.get("board_grid_count")
        if n is None:
            continue
        if isinstance(n, bool) or n not in VALID_GRID:
            issues.append(f'{s["id"]}: board_grid_count 非法: {n!r}')
        # 子镜数与宫格数差得太多时提示（不是错，但会导致合并/重复）
        beats = len(re.findall(r'\[Shot \d+\]', s.get("prompt_zh", "")))
        if beats and beats * 2 < n:
            issues.append(f'{s["id"]}: 子镜 {beats} 个 << 宫格 {n} 格，需要补过渡格')
        # 旧字段残留提示
        for stale in ("board_grid_prompt_mono", "board_grid_prompt_color"):
            if stale in s:
                issues.append(f'{s["id"]}: 残留已废弃字段 {stale}（可忽略）')
    return issues
```

---

## 10. 边界情况清单

| 情况 | 期望行为 |
|---|---|
| 旧包没有 `board_grid_count` | 静默跳过该镜 |
| `board_grid_count` 是 `5`（非法） | 报错，指明镜号 |
| `board_grid_count` 是 `True` | 报错（布尔值非法的坑） |
| 旧包残留 `board_grid_prompt_*` | 忽略，不读不校验 |
| 子镜数 > 宫格数 | 合并/抽样，保留首末帧与转折点 |
| 子镜数 < 宫格数 | 补过渡格或重复强调关键帧 |
| `board_grid_count == 1` | 退化为单张关键帧，不要套宫格措辞 |
| `board_grid_count == 2` | 左右两张，不要写「九宫格」 |
| 引用到 `kind=generated` 且无图资产 | 该参考图降级为空 / 提示用户先补图，不崩 |
| 三页数据不一致 | 以 **02 页**为准 |
| JSON 里有 `\u003cPicture 1\u003e` | 先 `json.loads` 再处理，别用字符串替换 |

---

## 11. 相关文件索引

| 文件 | 作用 |
|---|---|
| `scripts/build_pages.py` | 构建器；只校验 `board_grid_count`（约第 141–147 行） |
| `assets/runtime.js` | 页面渲染；`gridTag` 胶囊标签（第 65 行） |
| `assets/extra.css` | `.grid-tag` 样式 |
| `references/page-data.md` | 数据契约文档 |
| `SKILL.md` | 技能主文档「生成故事板」一节 |
| `references/board-grid-handoff.md` | 本文档在技能内的副本 |

**技能根目录**：本文件所在 `references/` 的上一级目录（各客户端的技能文件夹位置不同，按实际安装位置）
