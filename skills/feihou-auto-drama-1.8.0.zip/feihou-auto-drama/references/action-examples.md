# 动作范例库：14 个模型中立双语段落

以下均为原创教学例，未实际生成视频，不保证一次成功。每例中文与英文表达同一事件，含动作、摄影、声效和终态；用于学习写法，不是 H3 官方格式，也不是现实动作教学。生产时改成用户角色、真实 P# 引用、时长和选定接口格式；静态故事板只取所述关键帧，不把整段动作塞进一张图。每例按现有镜头字段分配，无须输出本参考文档。

## W1｜武侠剑术：前景刃尖与距离

适用：地面双人剑斗，强调剑术可读性。资产：青衣女剑客、灰衣剑客、两把形态不同的直剑、雨后石桥。故事板：低机位中广景，青衣人在左前景、灰衣人在右后景，双方剑身完整可辨。

中文：雨后石桥，青衣女剑客在左侧，灰衣剑客在右侧，两人各持一把钢制直剑。低机位广角侧移跟随青衣人。灰衣人的剑向前探出，青衣人侧移，以自己的剑将来剑带向画面右侧；两剑短暂交接后分离。她顺势前进，灰衣人后退一步拉开距离。近处剑身掠过画面下缘形成强透视，脸与剑尖保持可辨。金属短鸣、鞋底擦过湿石和衣袖声同步。结尾双方仍立于桥上，位置比起始更靠右，剑仍在各自手中。

English: On a rain-wet stone bridge, a woman in teal stands on the left and a swordsman in gray on the right, each holding a steel straight sword. A low, wide-angle camera tracks sideways with the woman. His blade extends forward; she steps aside and guides it toward screen right with her own sword. The blades briefly meet and separate. She advances while he retreats one step to reopen the distance. The nearer blade sweeps along the lower frame with strong foreshortening; faces and sword tips remain legible. A short metallic ring, shoes scraping wet stone, and sleeve movement accompany the exchange. Both finish standing farther to screen right, still holding their own swords.

## W2｜武侠刀法：刀弧与回收

适用：力量型刀法，不追加剑气。故事板：低角度，单刃刀斜贯前景，对手和廊柱同框。

中文：木廊里，棕衣刀客握一把宽身单刃刀，黑衣对手持短棍。刀客随跨步挥出斜向刀弧，对手退到柱外，刀从两人之间掠过，没有击中身体。摄影机短促横移跟随刀弧，停在双方中广景；刀客的身体转动随刀势收住，再把刀拉回可控位置。对手趁这一回收间隙移向廊口。衣料绷紧声、脚步和刀的破风声清楚，落空不配金属碰撞。结尾廊柱处于两人之间。

English: In a wooden corridor, a fighter in brown holds a broad single-edged dao while an opponent in black carries a short staff. The fighter steps into a diagonal blade sweep. The opponent retreats beyond a column, and the blade passes between them without striking a body. The camera makes a brisk lateral move with the blade arc, settling into a medium-wide two-shot. The fighter's turning body settles with the sword's momentum before drawing it back under control. During that recovery, the opponent moves toward the corridor entrance. Taut fabric, footfalls, and the blade cutting air are distinct; the miss has no metallic impact sound. The column ends between the two figures.

## W3｜武侠拳法：短促爆发与呼吸拍

适用：拳掌身法展示，不冒充特定门派。故事板：两人全身侧面，脚底支撑可见。

中文：石院中，两名穿布衣的练武者空手相对。镜头以侧面中广景展示脚步。左侧人物以掌拨开迎来的拳，右侧人物的前冲让上身略偏；两人随即各调整半步，短暂观察，再发生一次清晰的拳掌接触。摄影机只在距离缩短时稍后退。掌臂接触声与短呼气贴合动作，尘土只在鞋底移动时扬起。结尾两人站稳，左侧人物一只手仍停在接触后的高度，未自动重置到起手式。

English: Two practitioners in cloth tunics face each other bare-handed in a stone courtyard. A side-on medium-wide shot shows their footwork. The person on the left redirects an approaching fist with an open palm; the other's forward movement leaves the upper body slightly off-center. Both adjust half a step, briefly assess each other, then make one clear fist-to-palm contact. The camera eases backward only as their distance closes. Contact sounds and short exhalations match the movement; dust rises only where shoes shift. Both finish balanced, with the left person's hand still at its post-contact height rather than reset to the opening pose.

## W4｜武侠长兵器：空间限制改变动作

适用：长棍对短兵器，避免兵器穿墙。故事板：门内外两个人、门框与长棍完整关系。

中文：院门前，白衣人持长木棍，蓝衣人持短木棍。白衣人从开阔院中移向门口，长棍的横向摆动接近门框时收窄，改为沿门洞方向移动；蓝衣人在门外后退，短棍与长棍短暂相接。摄影机从侧面退至门口斜角，保留棍身与门框间隙。木质敲击和布鞋脚步同步。结尾长棍斜指门外，双方没有穿过门框或交换兵器。

English: At a courtyard gate, a person in white carries a long wooden staff and a person in blue a short wooden stick. Moving from the open courtyard toward the gate, the white-clad figure narrows the staff's sideways sweep as it approaches the frame and redirects its movement along the opening. The blue-clad figure steps back outside, briefly meeting the staff with the shorter stick. The camera retreats from the side into an oblique view of the gate, keeping the gap between wood and doorway visible. Wooden contact and cloth-shoe footfalls synchronize with the action. The long staff finishes angled outward; neither figure passes through the frame or exchanges weapons.

## X1｜仙侠御剑：高速伴飞与弧线收束

适用：已设定御剑飞行；高动态不等于乱切地点。故事板：白衣修士站在银色飞剑上，前方石拱、后方追来的赤色光迹。

中文：云海石峰间，白衣修士站在银色飞剑上，赤色法术光迹从后方逼近。摄影机从侧后方伴飞，随飞剑加速接近一座石拱；修士与飞剑共同沿弧线升高，赤色光迹从下方穿过石拱。相机跟着抬升，在拱顶上方收束为侧面远景。袖口被气流拉向后方，银色剑身始终位于脚下。破风声随加速增强，法术掠过时短促鸣响。结尾修士悬停在石拱上方，赤色光迹在远处消散。

English: Among stone peaks above a sea of clouds, a white-robed cultivator stands on a silver flying sword while a red spell trail approaches from behind. The camera accompanies them from the rear quarter as the sword accelerates toward a stone arch. Rider and sword rise together along a curved path; the red trail passes beneath them through the arch. The camera climbs with the rider and settles into a distant side view above the arch. Airflow pulls the sleeves backward, and the silver blade stays beneath the feet. Rushing air grows with acceleration, followed by a brief tone as the spell passes. The rider finishes hovering above the arch while the red trail dissipates in the distance.

## X2｜玄幻结界：元素对抗而非光球互轰

适用：本场已有冰壁可阻挡火焰的设定。故事板：右侧冰壁、左侧火焰源、两者之间可见空隙。

中文：雪原废墟中，蓝衣术者站在半透明冰壁后，远处红衣术者举起发光法杖。一股火焰从杖端沿地面上方卷向冰壁，接触处先透出橙光，再升起蒸汽；冰壁表面出现局部裂纹，主体仍直立。摄影机沿冰壁斜侧横移，透过较清澈部分看见蓝衣术者后退半步。火光只染亮邻近冰面与衣袖。火焰轰鸣、冰裂和蒸汽声依次出现。结尾火焰减弱，裂纹和蒸汽留在原处。

English: In snowy ruins, a blue-robed caster stands behind a translucent ice wall while a distant red-robed caster raises a glowing staff. A stream of fire rolls from the staff above the ground toward the wall. Orange light appears at contact, followed by steam; local cracks spread across the ice while the wall stays upright. The camera tracks obliquely along the wall, revealing the blue-robed caster taking half a step back through a clearer section. Firelight colors only nearby ice and fabric. Fire, cracking ice, and steam are heard in sequence. The fire weakens at the end, leaving the cracks and steam where the contact occurred.

## C1｜犯罪现代格斗：狼狈与动作后果

适用：写实近身冲突，无超英力量。故事板：两人中广景、金属柜和门在同框。

中文：昏暗更衣室，穿灰夹克的人试图向门口移动，黑衣人挡在前方。黑衣人突然挥拳，灰夹克人物闪开后肩膀撞上金属柜，柜门发出短震；他扶柜稳住，没有立刻恢复笔直姿态，随后绕过柜角继续向门口移。受控手持镜头跟随半步，保持两人的手和重心可见。拳落空只有破风，撞柜声、鞋底摩擦和喘息清楚。结尾灰夹克人物仍扶着受撞的肩，黑衣人转身追近。

English: In a dim locker room, a person in a gray jacket tries to reach the door while a black-clad figure blocks the way. The figure suddenly swings a fist. The person in gray evades it but strikes a shoulder against a metal locker, briefly rattling its door. They brace against the locker without instantly straightening, then move around its corner toward the exit. A controlled handheld camera follows half a step, keeping hands and weight shifts visible. The missed punch cuts air; the locker impact, shoe friction, and breathing remain distinct. At the end, the gray-jacketed figure still favors the struck shoulder as the pursuer turns after them.

## C2｜一打多：主路线与压力交接

适用：主角目标是脱身，不要求击倒全部人。故事板：主角近桌边、两名对手分处柱外与门边，第三人在背景绕行。

中文：仓库内，红夹克主角从桌边绕向柱外，再朝右侧门口移动。最近的灰衣人伸手拦住去路，主角侧身错开时，门边蓝衣人已向前逼近；灰衣人被桌角阻住，继续绕行而非原地等待。主角与蓝衣人短暂碰撞，踉跄一步扶柱，再从柱外恢复移动；第三名黑衣人始终在背景绕过货箱接近。中广景镜头跟随主角弧形移动，门口位置持续可辨。不同方向的脚步、柱面碰撞和急促呼吸构成压力。结尾主角抵达门边，三名对手的位置及受阻状态仍清楚。

English: In a warehouse, a red-jacketed protagonist moves from a table around the outside of a column toward a door on screen right. The nearest gray-clad opponent reaches across the route. As the protagonist sidesteps, a blue-clad opponent by the door is already closing in. Delayed by the table corner, the gray figure circles it instead of waiting motionless. The protagonist briefly collides with the blue figure, stumbles against the column, then resumes moving around its outside. A third figure in black keeps approaching around crates in the background. A medium-wide camera follows the protagonist's curved route while the door stays identifiable. Footsteps from separate directions, contact with the column, and urgent breaths sustain pressure. The protagonist ends beside the door with all three opponents' locations and obstructions still clear.

## C3｜犯罪枪战：威胁方向与银幕反馈

适用：虚构枪战镜头，不描写现实战术。故事板：前景人物、远处持枪剪影、可辨柱面。

中文：地下停车场中，前景棕衣人站在水泥柱旁，远处黑色剪影手中的道具枪出现一次短促枪口闪光；棕衣人旁边的柱面同时崩出一小团灰尘，他猛地缩身并离开原来的站位。侧向中景保持远近位置关系，随后切到棕衣人急促喘息的近景。枪声带停车场混响，灰尘随后落下。结尾他已移到画面左侧，原柱面的破损依然可见；没有持续激光轨迹或超自然冲击波。

English: In an underground parking garage, a brown-clad figure stands beside a concrete column. A distant dark silhouette's prop gun produces one brief muzzle flash; a small puff of dust breaks from the column beside the foreground figure, who flinches and leaves the original position. A lateral medium shot maintains the near-far relationship, then cuts to a close view of the figure breathing rapidly. The report reverberates through the garage, and dust subsequently falls. The figure finishes on screen left while the damaged patch remains visible on the original column; there is no sustained laser trail or supernatural shockwave.

## C4｜犯罪爆炸追逃：先后层次与残留

适用：已发生的虚构爆炸，不涉及爆破制作。故事板：奔跑人物前景，远处无人车辆与出口。

中文：夜间空旷停车区，两人正向前景出口跑来。远处一辆无人车辆突然闪光，随后火焰和黑烟上升；冲击扬起近地尘土，两人缩肩踉跄，但继续向出口跑。摄影机在前方后退跟随，爆炸保持在背景而不遮没人物轮廓。暖光短暂照亮衣服背缘后减弱，现场路灯仍是稳定光源。爆响之后是碎物落地和脚步声。结尾两人到达出口，远处黑烟仍在升起。

English: In an open parking area at night, two people run toward a foreground exit. A distant unoccupied vehicle suddenly flashes, followed by rising flames and black smoke. The disturbance lifts low dust; both runners hunch and stumble but keep moving toward the exit. The camera retreats ahead of them while the explosion stays behind their readable silhouettes. Warm light briefly touches the backs of their clothes, then fades, with the parking lights remaining stable. The blast is followed by falling debris and footfalls. Both reach the exit as black smoke continues to rise in the distance.

## S1｜科技武器：装置、脉冲与护盾

适用：虚构科技机制，区别魔法法阵。故事板：腕部装置前景、无人机护盾后景。

中文：金属实验舱内，装甲人物举起带分段发光条的腕部装置，前方无人机展开一面薄蓝护盾。装置光条依次亮起，一枚短脉冲从腕部飞向护盾；接触处形成局部同心波纹，无人机被推后少许并自行稳住。镜头从腕部侧前方快速横移，停在双方同框的侧景。蓝光短暂反射在附近金属上，舱壁结构仍清楚。电子升调、脉冲声和护盾颤鸣依次出现。结尾装置光条变暗，护盾留下逐渐消退的波纹。

English: Inside a metal laboratory, an armored figure raises a wrist device with segmented light strips while a drone ahead unfolds a thin blue shield. The strips illuminate in sequence, and a short pulse travels from the device to the shield. Local concentric ripples appear at contact; the drone shifts backward slightly, then stabilizes itself. The camera moves briskly sideways from the device's front quarter and settles into a side view containing both subjects. Blue light briefly reflects from nearby metal while the cabin structure stays readable. An electronic rise, a pulse, and a vibrating shield tone occur in sequence. The strips finish dimmed as the shield's ripples fade.

## S2｜机甲：推进与质量感

适用：重型机甲，不照搬轻盈真人拳脚。故事板：低机位，机甲、地面网格及远处运输车提供尺度。

中文：维修坪上，一台高大灰色机甲面对从右侧撞来的无人作业机器人。机甲转动上身迎向来物，双臂与机器外壳接触后被推得后移，脚底沿地面擦出尘痕；背部推进器短暂点亮，它才稳住位置。低机位镜头沿左侧后退，保留双脚与地面接触，前景栏杆掠过增加尺度感。金属受力、伺服电机和推进器低鸣分层出现。结尾机甲仍略向后倾，推进器熄灭，擦痕留在地面。

English: On a maintenance apron, a tall gray mech faces an unmanned industrial robot arriving from screen right. The mech turns its torso toward it. After both arms meet the robot's shell, the mech is pushed backward, its feet leaving dusty scrape marks. A brief burst from its rear thrusters helps it stabilize. A low camera retreats along the left side, retaining the feet's contact with the ground as a foreground railing passes to reinforce scale. Strained metal, servo motors, and the thrusters' low sound are layered separately. The mech finishes slightly leaned back with its thrusters dark and scrape marks still on the apron.

## S3｜超英式动作：力量反差与高速收束

适用：已有飞行与能量盾能力的原创角色。故事板：银甲飞行者、巨型机械臂与街道纵深。

中文：空置街道上方，银甲飞行者向前加速，前方巨型机械臂横扫而来。摄影机从飞行者侧后方高速伴随，在两者接近时转成侧面视角；飞行者展开弧形能量盾，与机械臂相接，盾面向后弯曲，他被推回一段距离。蓝白光照亮盔甲边缘和下方街面，尘土沿道路向外滚动。相机随退势减速，最终收束为包含两者的远景。推进声、盾面低鸣和金属轰响依序变化。结尾飞行者停在空中，护盾仍有波纹，机械臂停在街道另一侧。

English: Above an empty street, a silver-armored flyer accelerates as a giant mechanical arm sweeps across the route. The camera accompanies the flyer at speed from the rear quarter, moving into a side view as they converge. The flyer opens a curved energy shield. On contact with the arm, the shield bows backward and the flyer is pushed some distance back. Blue-white light touches armor edges and the street below while dust rolls outward along the road. The camera decelerates with the retreat, settling into a wide view of both subjects. Propulsion, the shield's low resonance, and the metallic impact change in sequence. The flyer finishes hovering with ripples on the shield; the arm stops on the other side of the street.

## O1｜儿童纸偶冒险：同样有动作，但不是暴力升级

适用：剪纸/纸偶、追逐救援。故事板：纸偶小兔、缓坡、滚动纸球、折叠桥。

中文：层叠纸张构成的小山坡上，纸偶小兔追着一颗滚向折叠桥的纸球。它迈动铰接纸腿，伸手碰到球却没抓稳；纸球弹到桥面，小兔停一下看清位置，再蹦上桥把球抱住。侧面镜头轻快平移，纸层投影和纸偶关节始终清楚。纸张摩擦、轻敲和一次短促呼气配合动作。结尾桥轻轻摇晃后稳定，小兔抱着球坐下。

English: On a hillside made from layered paper, a rabbit paper puppet chases a ball rolling toward a folding bridge. Its hinged paper legs move as it reaches the ball but fails to hold it. The ball bounces onto the bridge. The rabbit pauses to locate it, then hops onto the bridge and gathers it in both arms. A lively side-tracking camera keeps layered shadows and puppet joints clear. Paper friction, light taps, and one short exhalation accompany the movement. The bridge sways gently and settles as the rabbit sits holding the ball.

## 范例迁移检查

先替换角色与事件，再选画面形式，最后适配生成端。迁移后至少核对：是否引入原故事没有的能力？武器是否仍属于同一人？关键帧能否启动所写动作？摄影路径和空间一致吗？声音来自哪里？本镜终态能否成为下一镜的明确首态？用户锁定的对白需安排实际表演时间，不能因套用这些无对白例而漏掉。
