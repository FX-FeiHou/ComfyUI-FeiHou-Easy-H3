#!/usr/bin/env python3
"""Validate the production manifest invariants that affect H3 pages."""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from asset_references import validate_asset_references
from easy_h3_fields import chain_errors, media_errors, plan

RANGE = re.compile(r"^\d{2}:\d{2}:\d{3}–\d{2}:\d{2}:\d{3}$")


def range_seconds(value: str) -> float:
    def parse(token: str) -> float:
        minute, second, millisecond = (int(part) for part in token.split(":"))
        return minute * 60 + second + millisecond / 1000
    start, end = value.split("–")
    return parse(end) - parse(start)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path)
    parser.add_argument("--asset-root", type=Path, help="Package folder for checking relative asset image paths")
    args = parser.parse_args()
    data = json.loads(args.manifest.read_text(encoding="utf-8"))
    errors: list[str] = validate_asset_references(data, args.asset_root)
    seen: set[str] = set()
    assets = {item.get("id") for item in data.get("assets", [])}
    audio_references = data.get("audio_references", [])
    for index, shot in enumerate(data.get("shots", []), 1):
        label = shot.get("id", f"shot {index}")
        if label in seen:
            errors.append(f"duplicate shot id: {label}")
        seen.add(label)
        if not RANGE.fullmatch(shot.get("range", "")):
            errors.append(f"{label}: range must use MM:SS:ddd–MM:SS:ddd")
        else:
            seconds = range_seconds(shot["range"])
            if not 0.2 <= seconds <= 30:
                errors.append(f"{label}: derived duration {seconds:.3f}s must be within Easy H3's 0.2–30s range")
            explicit_seconds = shot.get("seconds")
            if explicit_seconds is not None:
                try:
                    explicit_seconds = float(explicit_seconds)
                except (TypeError, ValueError):
                    errors.append(f"{label}: seconds must be numeric when provided")
                else:
                    if abs(explicit_seconds - seconds) > 0.05:
                        errors.append(f"{label}: seconds must match the duration derived from range")
        refs = shot.get("references", [])
        errors.extend(media_errors(shot, data))
        unknown = [ref for ref in refs if ref not in assets]
        if unknown:
            errors.append(f"{label}: unknown asset IDs: {', '.join(unknown)}")
        if not shot.get("lyrics"):
            errors.append(f"{label}: provide lyrics or the exact text 本段无歌词")
        for field in ("prompt_en", "prompt_zh", "camera", "scene", "action", "continuity"):
            if not shot.get(field):
                errors.append(f"{label}: missing {field}")
        # A per-shot audio_references list numbers that shot's <Audio N>; otherwise the project catalogue applies.
        listed = shot.get("audio_references")
        shot_audio = ([{"h3_label": f"<Audio {n}>"} for n in range(1, len(listed) + 1)] if listed is not None
                      else audio_references)
        for audio in shot_audio:
            audio_label = audio.get("h3_label", "<Audio 1>")
            prompt = shot.get("prompt_en", "")
            definitions = prompt.split("summary:", 1)[0]
            retention = prompt.split("retention_analysis:", 1)[-1].split("detailed_description:", 1)[0]
            if audio_label not in definitions:
                errors.append(f"{label}: {audio_label} must be defined in subject_definitions")
            if "audio reference" not in prompt.split("retention_analysis:", 1)[0].lower() and "audio reuse" not in prompt.split("retention_analysis:", 1)[0].lower():
                errors.append(f"{label}: summary must declare audio reference or audio reuse")
            if f"{audio_label}: reference" not in retention and f"{audio_label}: fully_copy" not in retention and f"{audio_label}: partially_copy" not in retention and f"{audio_label}: weak_reference" not in retention:
                errors.append(f"{label}: retention_analysis needs an official relationship for {audio_label}")
    errors.extend(chain_errors(data))
    if errors:
        print("Manifest validation failed:", *errors, sep="\n- ")
        sys.exit(1)
    print(f"Manifest valid: {len(data.get('assets', []))} assets, {len(data.get('shots', []))} shots")
    for label, how, used, count in plan(data):
        print(f"  {label}: {how}{' ' + used if used else ''}{f' (chain continuation {count})' if count else ''}")


if __name__ == "__main__":
    main()
