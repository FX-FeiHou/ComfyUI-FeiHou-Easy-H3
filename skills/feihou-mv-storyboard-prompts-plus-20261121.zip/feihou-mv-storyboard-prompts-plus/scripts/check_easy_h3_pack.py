"""Read-only check of a finished MV package against the installed Easy H3 production-pack loader.

Runs the node's own front-end extractor (web/production_pack_parser.js, via node) and back-end
validator (production_pack.validate_shots). Starts no ComfyUI, queues nothing, changes no media.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from html.parser import HTMLParser

sys.path.insert(0, str(Path(__file__).resolve().parent))
from easy_h3_fields import chain_errors, plan  # noqa: E402

PARSER_JS = """const fs=require('fs');
  (async()=>{const code=fs.readFileSync(process.argv[1],'utf8');
    const parser=await import('data:text/javascript;base64,'+Buffer.from(code).toString('base64'));
    const text=fs.readFileSync(0,'utf8');
    const doc={querySelector:()=>({textContent:text})};
    process.stdout.write(JSON.stringify(parser.extractShotlist(doc)));
  })().catch(e=>{console.error(e);process.exit(1)});"""


class ProjectBlock(HTMLParser):
    def __init__(self):
        super().__init__()
        self.active = False
        self.parts = []
        self.count = 0

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'script' and attrs.get('id') in ('mv-project-data', 'dh-project-data'):
            self.count += 1
            self.active = attrs.get('type') == 'application/json'

    def handle_endtag(self, tag):
        if tag == 'script':
            self.active = False

    def handle_data(self, data):
        if self.active:
            self.parts.append(data)


def load_loader(node_dir):
    """production_pack.py imports only the standard library at module level."""
    source = Path(node_dir) / 'production_pack.py'
    if not source.is_file():
        raise ValueError(f'No production_pack.py in {node_dir}: point --node-dir at the ComfyUI-FeiHou-Easy-H3 folder')
    spec = importlib.util.spec_from_file_location('easy_h3_production_pack_check', source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if not hasattr(module, 'validate_shots'):
        raise ValueError('Installed loader has no validate_shots; inspect the new implementation')
    return module


def check(node_dir, pack_root):
    root = Path(pack_root).resolve()
    files = [p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()]
    pages = [f for f in files if Path(f).suffix.lower() in ('.html', '.htm') and 'shotlist' in Path(f).stem.lower()]
    if len(pages) != 1:
        raise ValueError(f'Expected one Shotlist HTML, found {len(pages)}: {pages}')
    page = root / pages[0]
    if page.stat().st_size > 16 * 1024 * 1024:
        raise ValueError('Shotlist exceeds 16 MiB')
    block = ProjectBlock()
    block.feed(page.read_text(encoding='utf-8-sig'))
    if block.count != 1 or not block.parts:
        raise ValueError('Expected exactly one inline mv-project-data/dh-project-data JSON block')
    payload = ''.join(block.parts)
    project = json.loads(payload)
    completed = subprocess.run(['node', '-e', PARSER_JS, str(Path(node_dir) / 'web' / 'production_pack_parser.js')],
                               input=payload, encoding='utf-8', capture_output=True, check=True)
    shots = json.loads(completed.stdout)
    validated = load_loader(node_dir).validate_shots({'root': root, 'files': files}, shots)
    for shot in validated:
        audios = shot.get('audios') or ([{'file': shot['audio']}] if shot.get('audio') else [])
        print(f"PASS {shot['id']}: {shot['params']['seconds']}s, {len(shot['images'])} images, "
              f"{len(shot['videos'])} videos, {len(audios)} audio")
    for label, how, used, count in plan(project):
        print(f"  {label}: {how}{' ' + used if used else ''}{f' (chain continuation {count})' if count else ''}")
    problems = chain_errors(project)
    for problem in problems:
        print('WARN', problem)
    return validated


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--node-dir', type=Path, required=True)
    parser.add_argument('--pack-root', type=Path, required=True)
    args = parser.parse_args()
    check(args.node_dir, args.pack_root)
