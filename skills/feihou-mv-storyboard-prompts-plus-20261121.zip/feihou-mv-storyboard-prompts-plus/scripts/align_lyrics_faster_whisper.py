#!/usr/bin/env python3
"""Create sentence-level timing evidence from a master song and locked lyrics."""
from __future__ import annotations

import argparse
import json
import re
from difflib import SequenceMatcher
from pathlib import Path

from faster_whisper import WhisperModel


def locked_lines(path: Path) -> list[str]:
    lines = []
    for raw in path.read_text(encoding="utf-8-sig").splitlines():
        value = raw.strip()
        if not value or (value.startswith("[") and value.endswith("]")):
            continue
        lines.extend(part.strip() for part in value.split("|") if part.strip())
    return lines


def norm(value: str) -> str:
    return re.sub(r"[^0-9a-zA-Z\u3400-\u9fff]", "", value).lower()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("audio", type=Path)
    parser.add_argument("lyrics", type=Path, help="Locked lyric text; lyric wording remains authoritative")
    parser.add_argument("output", type=Path)
    parser.add_argument("--model", default="small")
    parser.add_argument("--language", default=None)
    parser.add_argument("--device", default="cpu")
    parser.add_argument("--compute-type", default="int8")
    args = parser.parse_args()
    model = WhisperModel(args.model, device=args.device, compute_type=args.compute_type)
    segments, info = model.transcribe(
        str(args.audio), language=args.language, beam_size=5, vad_filter=True,
        word_timestamps=False, condition_on_previous_text=False,
    )
    evidence = [{"start": round(s.start, 3), "end": round(s.end, 3), "asr_text": s.text.strip()} for s in segments]
    locked = locked_lines(args.lyrics)
    matches = []
    cursor = 0
    for line in locked:
        target = norm(line)
        candidates = evidence[cursor:] or evidence[-1:]
        ranked = sorted(
            ((SequenceMatcher(None, target, norm(item["asr_text"])).ratio(), offset, item) for offset, item in enumerate(candidates)),
            reverse=True,
        )
        score, offset, item = ranked[0] if ranked else (0.0, 0, {"start": None, "end": None, "asr_text": ""})
        cursor += offset
        matches.append({"locked_lyric": line, "start": item["start"], "end": item["end"], "confidence": round(score, 3), "asr_evidence": item["asr_text"]})
    result = {
        "tool": "faster-whisper",
        "model": args.model,
        "detected_language": getattr(info, "language", None),
        "audio": str(args.audio),
        "locked_lyrics": str(args.lyrics),
        "asr_segments": evidence,
        "sentence_matches": matches,
        "review_required": "Treat locked_lyric as authoritative. Review low-confidence matches and every vocal onset, phrase ending, silence, pickup, section change, and outro before creating the 0.1-second production cut map.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(args.output)


if __name__ == "__main__":
    main()
