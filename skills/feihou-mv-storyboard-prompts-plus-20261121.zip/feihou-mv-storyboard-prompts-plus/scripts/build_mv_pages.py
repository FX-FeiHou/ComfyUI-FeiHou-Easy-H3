#!/usr/bin/env python3
"""Build the three self-contained MV production pages from one manifest JSON."""
from __future__ import annotations

import argparse
import copy
import json
import math
import re
import shutil
from pathlib import Path
from asset_references import validate_asset_references

TEMPLATE_NAMES = {
    "asset": "asset-inventory.template.html",
    "h3": "minimax-h3-shotlist.template.html",
    "list": "chinese-shotlist.template.html",
}


def safe_slug(value: str) -> str:
    value = re.sub(r"[<>:\\|?*/\"]", "_", value).strip()
    return value or "MV"


def range_seconds(value: str) -> float:
    def parse(token: str) -> float:
        minute, second, millisecond = (int(part) for part in token.split(":"))
        return minute * 60 + second + millisecond / 1000
    start, end = value.split("–")
    return parse(end) - parse(start)


def prepare_project(project: dict, asset_root: Path) -> dict:
    prepared = copy.deepcopy(project)
    errors = validate_asset_references(prepared, asset_root)
    if errors:
        raise ValueError("Asset reference validation failed:\n" + "\n".join(errors))
    for shot in prepared.get("shots", []):
        value = shot.get("range", "")
        if re.fullmatch(r"\d{2}:\d{2}:\d{3}–\d{2}:\d{2}:\d{3}", value):
            seconds = range_seconds(value)
            if not 0.2 <= seconds <= 30:
                raise ValueError(f"{shot.get('id')}: duration outside Easy H3's 0.2–30s range")
            declared = shot.get("seconds")
            if declared is not None and (not math.isfinite(float(declared)) or abs(float(declared) - seconds) > 0.05):
                raise ValueError(f"{shot.get('id')}: seconds disagrees with range")
            shot["seconds"] = round(seconds, 1)
    return prepared


def build(template: Path, output: Path, project: dict) -> None:
    text = template.read_text(encoding="utf-8")
    payload = json.dumps(project, ensure_ascii=False).replace("</", "<\\/")
    marker = '<script id="mv-project-data" type="application/json">{}</script>'
    if marker not in text:
        raise ValueError(f"Template data marker missing: {template}")
    output.write_text(text.replace(marker, f'<script id="mv-project-data" type="application/json">{payload}</script>'), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest", type=Path, help="Project manifest JSON")
    parser.add_argument("output_dir", type=Path, help="Folder for the three HTML files")
    args = parser.parse_args()
    project = json.loads(args.manifest.read_text(encoding="utf-8"))
    title = safe_slug(project.get("title", "MV"))
    root = Path(__file__).resolve().parents[1]
    templates = root / "assets" / "templates"
    args.output_dir.mkdir(parents=True, exist_ok=True)
    project = prepare_project(project, args.output_dir)
    outputs = {
        "asset": args.output_dir / f"{title}_GPT_Image2_资产清单.html",
        "h3": args.output_dir / f"{title}_MiniMaxH3_Shotlist.html",
        "list": args.output_dir / f"{title}_全中文分镜列表.html",
    }
    for key, output in outputs.items():
        build(templates / TEMPLATE_NAMES[key], output, project)
        print(output)


if __name__ == "__main__":
    main()
