"""Easy H3 v1.5 production-pack loader fields: transition, continuation_frames, per-shot media slots.

Mirrors FeiHou Easy H3's production_pack.validate_shots rules so a manifest fails here
before the user clicks 制作包状态检测. Shared by validate_mv_manifest.py and check_easy_h3_pack.py.
"""
from __future__ import annotations

import re

CONTINUE_WORDS = {"continue", "continuation", "continuous", "seamless", "接续", "续接", "连续", "无缝"}
CUT_WORDS = {"cut", "hard_cut", "hardcut", "hard cut", "硬切", "切", "切镜", "剪切"}
FRAME_CHOICES = ("0+5", "5+0", "5+5", "22+0", "22+5", "22+22", "39+0", "39+5", "39+22", "39+39")
MAX_CONTINUATIONS = 4
QUALITY_WARNING = "超过4次接续，画质将无法保证。"


def transition(value):
    """'接续' / '硬切', None when empty; ValueError for anything else."""
    text = str(value or "").strip().casefold()
    if not text:
        return None
    if text in CONTINUE_WORDS:
        return "接续"
    if text in CUT_WORDS:
        return "硬切"
    raise ValueError(f"transition must be 接续 or 硬切, got {value!r}")


def frames(value):
    """Canonical 'A+B', None when empty; '0+0' counts as a hard cut. ValueError otherwise."""
    if value in (None, ""):
        return None
    if isinstance(value, bool):
        raise ValueError(f"continuation_frames must be A+B, got {value!r}")
    if isinstance(value, dict):
        value = [value.get("first"), value.get("second")]
    if isinstance(value, (list, tuple)) and len(value) == 2 and all(isinstance(v, int) for v in value):
        text = f"{value[0]}+{value[1]}"
    elif isinstance(value, int) and value in (0, 5, 22, 39):
        text = f"{value}+{value}"
    else:
        text = re.sub(r"\s+", "", str(value)).replace("＋", "+")
        if re.fullmatch(r"0|5|22|39", text):
            text = f"{text}+{text}"
    if text == "0+0" or text in FRAME_CHOICES:
        return text
    raise ValueError(f"continuation_frames must be one of {', '.join(FRAME_CHOICES)}, got {value!r}")


def plan(project):
    """Per shot: (id, '首镜' / '接续' / '硬切', frames, chain position). Raises ValueError on bad values."""
    rows = []
    default_transition = transition(project.get("transition"))
    default_frames = frames(project.get("continuation_frames"))
    count = 0
    for index, shot in enumerate(project.get("shots", [])):
        label = shot.get("id", f"shot {index + 1}")
        try:
            how = transition(shot.get("transition"))
            used = frames(shot.get("continuation_frames"))
        except ValueError as exc:
            raise ValueError(f"{label}: {exc}") from None
        how = how or default_transition or "接续"
        used = used or default_frames or "22+22"
        if index == 0:
            how, count = "首镜", 0
        elif how == "硬切" or used == "0+0":
            how, count = "硬切", 0
        else:
            count += 1
        rows.append((label, how, used if how == "接续" else "", count))
    return rows


def chain_errors(project):
    """Missing transition fields, bad values and unapproved chains longer than 4 continuations."""
    errors = []
    shots = project.get("shots", [])
    for index, shot in enumerate(shots[1:], 2):
        if shot.get("transition") in (None, "") and project.get("transition") in (None, ""):
            errors.append(f"{shot.get('id', f'shot {index}')}: write transition (接续 or 硬切); the loader would assume 接续")
    try:
        rows = plan(project)
    except ValueError as exc:
        return errors + [str(exc)]
    approved = [set(a.get("shot_ids", [])) for a in project.get("continuation_approvals", [])
                if a.get("confirmed") and a.get("quality_warning_acknowledged")]
    chain = []
    for label, how, _frames, count in rows:
        chain = [label] if how in ("首镜", "硬切") else chain + [label]
        if count > MAX_CONTINUATIONS:
            start = chain[0]
            if not any(set(chain) <= ids for ids in approved):
                errors.append(f"{label}: continuation {count} of the chain from {start}. {QUALITY_WARNING} "
                              "Cut earlier, or record the user's consent in continuation_approvals")
    return errors


def media_errors(shot, project):
    """Slot numbers in the prompts against what the loader will load for this shot."""
    label = shot.get("id", "shot")
    errors = []
    refs = shot.get("references") or shot.get("refs") or []
    videos = shot.get("video_refs") or shot.get("video_references") or []
    listed = shot.get("audio_references")
    if listed is not None:
        audios = len(listed)
    else:  # legacy single soundtrack: master_audio / audio_file / the package's only audio
        audios = 1 if (shot.get("audio_file") or project.get("master_audio")) else 0
    if len(refs) > 9:
        errors.append(f"{label}: {len(refs)} images exceed the 9-image cap")
    if len(videos) > 3:
        errors.append(f"{label}: {len(videos)} video_refs exceed the 3-video cap")
    if audios and not refs and not videos:
        errors.append(f"{label}: reference audio needs at least one image or video (text-to-video shots carry no audio)")
    for field in ("prompt_en", "prompt_zh"):
        prompt = shot.get(field) or ""
        for kind, limit in (("Picture", len(refs)), ("Image", len(refs)), ("Video", len(videos)), ("Audio", audios)):
            bad = sorted({int(n) for n in re.findall(rf"<{kind}\s+(\d+)>", prompt, re.I) if not 1 <= int(n) <= limit})
            if bad:
                errors.append(f"{label}: {field} cites <{kind} {bad[0]}> but the loader gives this shot {limit}")
    return errors
