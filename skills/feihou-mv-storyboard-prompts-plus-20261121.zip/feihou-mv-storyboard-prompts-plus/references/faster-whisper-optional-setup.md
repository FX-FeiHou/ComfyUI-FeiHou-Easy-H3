# 可选：faster-whisper 整句时间定位

`faster-whisper` 是本地语音转写与句级时间定位工具。它不是技能包内容：技能目录不携带安装程序、模型权重或缓存。用户自行决定是否安装。

- 官方仓库：https://github.com/SYSTRAN/faster-whisper
- Python 安装：`py -3.12 -m pip install -U faster-whisper`
- 首次使用 `small` 模型时，工具会下载模型权重；预留约 1 GB 可用磁盘空间，以容纳模型和缓存。
- 推荐默认：`small`、CPU `int8`。`tiny` 更省空间，但歌曲中的人声句界更容易漂移。

安装后，可用技能中的辅助脚本生成整曲的 ASR 时间证据：

```powershell
py -3.12 <技能包目录>\scripts\align_lyrics_faster_whisper.py `
  <项目文件夹>\master.mp3 <项目文件夹>\歌词.txt <项目文件夹>\small_逐句转写.json --model small
```

`<技能包目录>` 指本技能的实际安装位置（各客户端不同，例如 `%USERPROFILE%\.codex\skills\feihou-mv-storyboard-prompts-plus`）；`<项目文件夹>` 换成实际的项目路径。

该脚本将锁定歌词逐句与 ASR 片段进行顺序匹配，输出原始 ASR 片段、句级候选起止时间、匹配置信度和复核提示。它不改写歌词文件，锁定歌词始终是歌词正文的唯一来源。

在建立分镜前，人工复核低置信度句子、首句人声进入、句尾停顿、静音、pickup、段落转换与尾奏。原始证据保留毫秒；生产分镜边界再按音乐有效位置归一到 0.1 秒。
