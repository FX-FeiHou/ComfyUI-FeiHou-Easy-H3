# MV 生产页数据契约

Easy H3 节点导入须同时遵循 [easy-h3-production-pack.md](easy-h3-production-pack.md)。保留唯一 `mv-project-data` 数据块，设置 `package_mode: "mv"`；`references` 按包内真实图片主名匹配（支持 P0A/P1B），每镜 0–9 图（没有图也没有视频的镜头不能带参考音频）、至多 3 个 `video_refs`；歌曲是 `<Audio 1>`，要再加别的参考音频时写每镜 `audio_references`。每镜的 `transition` / `continuation_frames` 决定加载器是接上一镜还是独立生成。`assets[].file` 是画布/预览路径，不是此节点的图片匹配依据。`aspect_ratio`、`fps` 按用户已确认值填写，分镜字段覆盖项目值，省略则保留主节点设置；分辨率由主节点控制。

三页由同一份 `project-manifest.json` 生成。复制 `assets/project-manifest.template.json` 后填写项目数据，再先运行 `scripts/validate_mv_manifest.py`，最后运行 `scripts/build_mv_pages.py`。项目清单是构建输入，不是额外交付物；用户可见的生产内容仍只交付三张 HTML。

```json
{
  "title": "歌曲或项目名称",
  "subtitle": "可选页眉副标题",
  "page_titles": {
    "asset": "资产清单与生成提示词",
    "h3": "MiniMax H3 全片分镜提示词｜项目类型",
    "list": "分镜列表｜项目类型"
  },
  "master_audio": "绝对或相对主音频路径；Plus 页面默认载入此文件供分镜片段试听",
  "audio_references": [
    {
      "id": "A1",
      "file": "绝对或相对音频路径",
      "role": "voice_timbre_reference | audio_reuse",
      "h3_label": "<Audio 1>",
      "speaker": "<Subject 1> (S1)"
    }
  ],
  "master_duration_seconds": 231.3,
  "performance_ratio_note": "可见演唱、合唱与舞蹈约占 52%",
  "assets": [
    {
      "id": "P1",
      "asset_id": "CHAR-01",
      "name": "角色或资产名称",
      "kind": "locked 或 generated",
      "file": "相对资产 HTML 的图片路径，例如 ../assets/P1.png；待生成资产可省略",
      "original_file": "P1.png",
      "reference_ids": ["生成此资产时按顺序使用的上游 P#；无来源写 []"],
      "use": "它在 H3 中服务的镜头和用途",
      "prompt_en": "English GPT Image 2 prompt，使用 @P# 说明每张上游图职责",
      "prompt_zh": "中文 GPT Image 2 提示词，使用相同 @P# 说明每张上游图职责"
    }
  ],
  "shots": [
    {
      "id": "H3-001",
      "range": "00:00:000–00:06:400",
      "seconds": 6.4,
      "section": "前奏",
      "title": "分镜名称",
      "mode": "sing | group | dance | duet | narrative | hold",
      "performer": "演唱 / 舞蹈成员，或 剧情镜头",
      "audio_slice": "原曲 00:00:000–00:06:400",
      "lyrics": "精确歌词，或 本段无歌词",
      "references": ["P1", "P2"],
      "camera": "全中文机位、构图、运镜与主动态",
      "scene": "全中文场景与用光",
      "action": "全中文完整动作叙事",
      "continuity": "硬切说明，或上一终帧到本首帧的连续关系和本镜终帧",
      "transition": "接续 | 硬切（首镜可省略）",
      "continuation_frames": "22+22（只在接续时用）",
      "prompt_en": "完整 English Ref2VA prompt",
      "prompt_zh": "完整中文 H3 工作提示词"
    }
  ]
}
```

## 硬性约束

- `page_titles` 必填。`asset`、`h3`、`list` 分别是资产页、H3 提示词页和中文分镜页的浏览器标题与页面主标题；不得让模板的旧项目类型或旧标题覆盖它们。
- `master_audio` 在 Plus 的 H3 页与中文分镜页中作为默认试听音源；用户可在页面顶部替换为本地音频文件，替换操作不改写项目清单。
- `range` 使用 `MM:SS:ddd–MM:SS:ddd`，显示用 0.1 秒切点时最后一位毫秒为 `0`。
- `seconds` 是 `range` 计算出的数值秒数，构建器会补入缺失值；显式填写时必须与 range 一致。它使单镜头能被 Easy H3 节点直接读取，合法范围是 0.2–30 秒。MV 的音乐分镜仍优先使用 4–15 秒的完整、可拼接单元。
- `references` 是全局 `P#`。每个镜头最多九项；H3 中的 `<Picture N>` 严格按该数组顺序换算。
- `audio_references` 中的 `A#` 是项目级音频资产 ID，`h3_label` 是当前 H3 单元的 `<Audio N>` 标签；两者不可混用。音色参考必须在每个受影响单元的 `subject_definitions` 中单独定义 `<Audio N>` 并绑定 `<Subject N> (Sx)`，在 `summary` 标明 `audio reference`，在 `retention_analysis` 使用 `reference`。直接复用信号时改用 `audio reuse` 与 `fully_copy` 或 `partially_copy`。
- 每个 `lyrics` 必填；无歌词时填写精确文本 `本段无歌词`。
- `transition` 是本镜开头怎么接上一镜：`接续` 或 `硬切`，首镜以外每镜都写，和 `continuity` 的文字一致。`continuation_frames` 是接续时的一采+二采引导帧数，只能是 `0+5`、`5+0`、`5+5`、`22+0`、`22+5`、`22+22`、`39+0`、`39+5`、`39+22`、`39+39`。一条接续链最多接 4 次，超过要先得到用户同意并记在 `continuation_approvals`。详见 [easy-h3-production-pack.md](easy-h3-production-pack.md)。
- 每镜可选 `audio_references`：本镜要加载的音频列表，顺序就是本镜的 `<Audio N>`。只用歌曲时不写，加载器按 `master_audio` 和本镜 `range` 自动裁切成 `<Audio 1>`。一旦写了，歌曲也要写进列表并带上本镜区间，例如 `[{"id": "A1", "range": "00:16:000–00:20:900"}, {"id": "A2"}]`；写 `[]` 表示本镜不加载任何音频。
- `prompt_en` 必须是可复制的六字段 Ref2VA 提示词；`prompt_zh` 保持相同字段顺序。
- `camera`、`scene`、`action`、`continuity` 同时服务全中文分镜列表，避免页面之间出现第二套内容。
- 资产依赖遵循 [asset-reference-contract.md](asset-reference-contract.md)。`file` 是已有图相对资产 HTML 的正斜杠路径；`reference_ids` 是生成资产的有序上游图列表；两栏提示词出现的 `@P#` 集合必须与它完全一致。`reference_ids` 不能替代分镜的 `references`，也不决定 `<Picture N>`。

## 生成命令

```powershell
py -3.12 <技能包目录>\scripts\validate_mv_manifest.py <项目文件夹>\project-manifest.json --asset-root <项目文件夹>\MV制作包
py -3.12 <技能包目录>\scripts\build_mv_pages.py <项目文件夹>\project-manifest.json <项目文件夹>\MV制作包
```

`<技能包目录>` 指本技能的实际安装位置（各客户端不同，例如 `%USERPROFILE%\.codex\skills\feihou-mv-storyboard-prompts-plus`）；`<项目文件夹>` 换成实际的项目路径。

生成器输出：

1. `TITLE_GPT_Image2_资产清单.html`
2. `TITLE_MiniMaxH3_Shotlist.html`
3. `TITLE_全中文分镜列表.html`
