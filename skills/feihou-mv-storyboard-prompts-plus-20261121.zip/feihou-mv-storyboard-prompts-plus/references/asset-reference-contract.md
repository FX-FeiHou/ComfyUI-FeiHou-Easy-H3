# MV 资产页与无限画布引用协议

本协议让 MV Plus 的资产清单可作为无限画布或其他本地资产导入器的稳定输入。它描述数据和相对文件关系，**不包含也不宣称实现了画布导入器**。

## 资产数据

每个资产保留一个全局且不变的 `P#`。已有图片以相对资产 HTML 的文件路径直接引用；待生成资产可暂时没有 `file`。生成资产写出有序 `reference_ids`，并在中英文提示词正文中用对应 `@P#` 清楚说明每张来源图的职责。

```json
{
  "id": "P3",
  "asset_id": "PROP-03",
  "name": "雨中金属麦克风",
  "kind": "generated",
  "file": "../assets/P3.png",
  "original_file": "P3.png",
  "reference_ids": ["P1", "P2"],
  "prompt_zh": "以 @P1 作为人物身份来源、以 @P2 作为麦克风结构来源，生成……",
  "prompt_en": "Use @P1 as the performer identity source and @P2 as the microphone geometry source, creating …"
}
```

- `file` 使用相对 HTML 的正斜杠路径，例如 `../assets/P3.png`；不使用绝对路径、Base64、复制素材或另建素材目录。
- `reference_ids` 永远是有序列表；无上游图时显式写 `[]`。它是画布导入器连接图片节点的顺序依据。
- 两种语言中提到的 `@P#` 集合必须与 `reference_ids` 完全一致。它们表达资产生成依赖；H3 分镜的 `references` 与本镜 `<Picture N>` 表达视频参考上传顺序，二者不得混用。
- 锁定资产必须已有 `file`；生成资产在生成完成前可省略 `file`，页面应显示“待生成上游”。
- 禁止未知 ID、重复 ID、重复依赖、自引用和循环依赖。

## 导入边界

用户只需将资产 HTML 拖入支持此协议的本地画布导入器。导入器从 HTML 所在目录解析相对 `file`，读取现有图片后按 `reference_ids` 连线，再把正文的 `@P#` 对应到画布节点。普通浏览器的 File 拖放不保证能读取来源目录；页面预览可显示图片不等于导入器已经实现或导入成功。

