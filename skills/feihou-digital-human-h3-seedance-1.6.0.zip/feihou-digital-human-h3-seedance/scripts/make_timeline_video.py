"""Make the "时间轴视频" for a FeiHou shot md that has no reference video.

The FeiHou shot-prompts node measures every @range on reference video 1, so a
talking-head project needs a video of the right length in Media video card 1.
It is a still of the person image; with --audio the speech recording is muxed
in so Motion Collect can output the source sound.  Every block writes
``@video none``, so this video only gives the timeline: in the 直接使用口播音频
case the same recording also goes into audio card 1 and the md header writes
``@audio block``, which cuts that card to each block's @range as <Audio 1>.

    python make_timeline_video.py 人物.png 时间轴.mp4 --seconds 42.5
    python make_timeline_video.py 人物.png 时间轴.mp4 --audio 口播.wav

Needs ffmpeg/ffprobe on PATH. Only writes the output file.
"""
from __future__ import annotations

import argparse
import subprocess
import sys


def _duration(path: str) -> float:
    out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", path],
                         capture_output=True, text=True, check=True).stdout.strip()
    return float(out)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("image", help="person image (the still shown in the timeline video)")
    parser.add_argument("output", help="output .mp4")
    length = parser.add_mutually_exclusive_group(required=True)
    length.add_argument("--seconds", type=float, help="length of a silent timeline video")
    length.add_argument("--audio", help="speech recording to mux in; the video is as long as it")
    parser.add_argument("--fps", type=int, default=24, help="frame rate (default 24, matches the md @fps)")
    args = parser.parse_args()

    command = ["ffmpeg", "-y", "-loop", "1", "-framerate", str(args.fps), "-i", args.image]
    if args.audio:
        # -shortest overruns a looped still by seconds; cut to the recording's exact length.
        command += ["-i", args.audio, "-t", f"{_duration(args.audio):.3f}",
                    "-c:a", "aac", "-b:a", "192k", "-ar", "48000", "-ac", "2"]
    else:
        if args.seconds <= 0:
            parser.error("--seconds must be positive")
        command += ["-t", f"{args.seconds:.3f}"]
    # even dimensions for yuv420p
    command += ["-vf", "scale=trunc(iw/2)*2:trunc(ih/2)*2", "-r", str(args.fps),
                "-c:v", "libx264", "-pix_fmt", "yuv420p", "-tune", "stillimage", args.output]
    return subprocess.call(command)


if __name__ == "__main__":
    sys.exit(main())
