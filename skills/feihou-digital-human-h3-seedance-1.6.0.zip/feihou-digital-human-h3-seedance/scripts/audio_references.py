"""Resolve and validate per-shot independent audio references for Easy H3."""
from pathlib import Path, PurePosixPath
import re

ZERO_RANGE = "00:00:000–00:00:000"


def normalize_range(value):
    match = re.fullmatch(r"(\d+):(\d{2}):(\d{3})[–-](\d+):(\d{2}):(\d{3})", str(value))
    if not match:
        raise ValueError("audio range must use MM:SS:ddd–MM:SS:ddd")
    numbers = list(map(int, match.groups()))
    if numbers[1] >= 60 or numbers[4] >= 60:
        raise ValueError("audio range seconds must be below 60")
    ticks = [(numbers[i] * 60000 + numbers[i+1] * 1000 + numbers[i+2] + 50) // 100 for i in (0, 3)]
    if ticks[1] and ticks[1] <= ticks[0]:
        raise ValueError("audio range end must exceed start, or be zero for EOF")
    def fmt(tick):
        return f"{tick // 600:02d}:{tick // 10 % 60:02d}:{tick % 10 * 100:03d}"
    return "–".join(map(fmt, ticks))


def resolve_audio(shot, catalog):
    # An explicit empty list overrides all legacy defaults.
    values = shot.get("audio_references")
    if values is None:
        raise ValueError("new packages require per-shot audio_references (use [] for none)")
    if not isinstance(values, list):
        raise ValueError("per-shot audio_references must be a list")
    resolved = []
    for value in values:
        if isinstance(value, str):
            value = {"id": value} if any(a.get("id") == value for a in catalog) else {"file": value}
        if not isinstance(value, dict):
            raise ValueError("audio entry must be an object or string")
        base = next((a for a in catalog if a.get("id") == value.get("id")), {}) if value.get("id") else {}
        item = {**base, **value}
        if not item.get("file"):
            raise ValueError(f"unresolved audio ID/file: {value}")
        item["range"] = normalize_range(item.get("range", ZERO_RANGE))
        resolved.append(item)
    return resolved


def validate_audio_references(project, root=None):
    errors = []
    catalog = project.get("audio_references", [])
    if not isinstance(catalog, list) or any(not isinstance(a, dict) for a in catalog):
        return ["project audio_references must be a list of objects"]
    ids = [a.get("id") for a in catalog]
    if any(not i for i in ids) or len(set(ids)) != len(ids):
        errors.append("audio catalog IDs must be present and unique")
    def check_file(item):
        raw = item.get("file", "")
        if not isinstance(raw, str) or not raw.strip():
            raise ValueError("audio file must be a real package-relative path")
        path = PurePosixPath(raw.replace("\\", "/"))
        if path.is_absolute() or ".." in path.parts or ":" in raw:
            raise ValueError(f"unsafe audio path: {raw}")
        normalize_range(item.get("range", ZERO_RANGE))
        if root is not None:
            folder = Path(root).resolve()
            exact = folder.joinpath(*path.parts).resolve()
            if not exact.is_relative_to(folder):
                raise ValueError(f"audio path escapes package: {raw}")
            if not exact.is_file():
                matches = [p for p in folder.rglob("*") if p.is_file() and p.name.casefold() == path.name.casefold() and p.resolve().is_relative_to(folder)]
                if len(matches) != 1:
                    raise ValueError(f"missing or ambiguous audio file: {raw}")
    for item in catalog:
        try:
            check_file(item)
        except ValueError as error:
            errors.append(str(error))
    for shot in project.get("shots", []):
        try:
            refs = resolve_audio(shot, catalog)
            for item in refs:
                check_file(item)
            if project.get("prompt_model") == "seedance":
                # Seedance labels are checked by model_support, without H3 sections.
                continue
            for field in ("prompt_zh",):
                prompt = shot.get(field, "")
                used = {int(n) for n in re.findall(r"<Audio\s+(\d+)>", prompt)}
                if used != set(range(1, len(refs)+1)):
                    raise ValueError(f"{field}: Audio labels must match the per-shot ordered list")
                for n in range(1, len(refs)+1):
                    if f"<Audio {n}>" not in prompt.split("summary:", 1)[0]:
                        raise ValueError(f"{field}: Audio {n} missing from subject_definitions")
        except ValueError as error:
            errors.append(f"{shot.get('id', '?')}: {error}")
    return errors


def normalize_project_audio(project):
    catalog = project.get("audio_references", [])
    for shot in project.get("shots", []):
        shot["audio_references"] = resolve_audio(shot, catalog)
        for key in ("voice_reference", "audio_file", "audio_refs"):
            shot.pop(key, None)
