"""Explicit model selection and Seedance generic authoring checks; no API adapter."""
import math
import re

# 分镜提示词只写中文；两种生成端的引用记法在正文里的写法不同：
#   H3       — 官方槽位 <Picture n> / <Audio n> / <Video n>
#   Seedance — @图片n / @音频n / @视频n
# nl_prompt_zh（分镜列表页的自然语言提示词）一律用 Seedance 口径的 @图片n，不参与 H3 槽位检查。
SLOT_KINDS = (("图片", "references"), ("视频", "video_refs"), ("音频", "audio_references"))


def model_errors(project):
    model = project.get("prompt_model")
    if model not in ("h3", "seedance"):
        return ["prompt_model must explicitly select h3 or seedance"]
    if model == "h3":
        return [
            f"{shot.get('id', '?')}: prompt_zh 混入了 Seedance 记法的 @图片/@音频/@视频"
            for shot in project.get("shots", [])
            if re.search(r"@(图片|音频|视频)\s*\d+", shot.get("prompt_zh", ""))
        ]
    errors = []
    if project.get("seedance_profile") != "seedance-2.0-generic":
        errors.append("seedance_profile must be seedance-2.0-generic; other versions need a verified adapter")
    from audio_references import resolve_audio
    videos = {v.get("file") for v in project.get("video_references", []) if isinstance(v, dict)}
    for shot in project.get("shots", []):
        label = shot.get("id", "?")
        try:
            seconds = float(shot.get("seconds", 0))
            if not math.isfinite(seconds) or not 4 <= seconds <= 15:
                errors.append(f"{label}: Seedance 2.0 generic duration must be 4–15 seconds")
        except (TypeError, ValueError):
            errors.append(f"{label}: invalid duration")
        refs = shot.get("references", [])
        video_refs = shot.get("video_refs", [])
        if not isinstance(video_refs, list):
            errors.append(f"{label}: video_refs must be an ordered list of filenames")
            video_refs = []
        if len(refs) > 9 or len(video_refs) > 3:
            errors.append(f"{label}: Seedance 2.0 generic supports at most 9 images and 3 videos")
        if any(not isinstance(v, str) or v not in videos for v in video_refs):
            errors.append(f"{label}: unknown video filename")
        try:
            audios = resolve_audio(shot, project.get("audio_references", []))
        except ValueError as error:
            errors.append(f"{label}: {error}")
            continue
        if len(audios) > 3:
            errors.append(f"{label}: Seedance 2.0 generic supports at most 3 audio references")
        if audios and not refs and not video_refs:
            errors.append(f"{label}: generic profile requires an image or video with audio")
        prompt = shot.get("prompt_zh", "")
        if re.search(r"subject_definitions:|retention_analysis:|detailed_description:|overall_soundscape:|non_diegetic_music:|<Subject\s+\d+>|<Picture\s+\d+>|<Audio\s+\d+>|<Video\s+\d+>|<d>|<scenetrans>|\(S\d+\)", prompt):
            errors.append(f"{label}: prompt_zh contains H3-only prompt syntax")
        for kind, count in (("图片", len(refs)), ("视频", len(video_refs)), ("音频", len(audios))):
            actual = {int(n) for n in re.findall(r"@" + kind + r"\s*(\d+)", prompt)}
            if actual != set(range(1, count + 1)):
                errors.append(f"{label}: prompt_zh @{kind} labels do not match upload order")
    return errors


def adapt_template(text, project):
    """Change only template-owned labels BEFORE injecting any user JSON."""
    if project.get("prompt_model") != "seedance":
        return text
    replacements = {
        "MiniMax H3": "Seedance",
        "H3 分镜": "Seedance 分镜",
        "Ref2VA": "Seedance 2.0 · 通用提示词",
        "&lt;Picture N&gt;": "@图片 N",
        "&lt;Audio N&gt;": "@音频 N",
        "&lt;Video N&gt;": "@视频 N",
        'Audio ${index + 1} ←': '@音频 ${index + 1} ←',
    }
    for before, after in replacements.items():
        text = text.replace(before, after)
    return text
