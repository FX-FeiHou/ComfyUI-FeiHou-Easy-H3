import unittest

from continuation import continuation_errors


class ContinuationContractTests(unittest.TestCase):
    def shot(self, **overrides):
        value = {
            "id": "H3-001",
            "continuation_mode": "none",
            "continuation_frames": 0,
            "continuation_count": 0,
            "continuation_user_approved": False,
        }
        value.update(overrides)
        return value

    def test_default_no_continuation(self):
        self.assertEqual(continuation_errors(self.shot()), [])

    def test_up_to_four_needs_no_approval(self):
        for count in (1, 2, 3, 4):
            shot = self.shot(
                continuation_mode="tail_frame",
                continuation_frames=2,
                continuation_count=count,
            )
            self.assertEqual(continuation_errors(shot), [], f"count={count} 不应报错")

    def test_more_than_four_requires_explicit_approval(self):
        shot = self.shot(
            continuation_mode="tail_frame",
            continuation_frames=2,
            continuation_count=5,
        )
        errors = continuation_errors(shot)
        self.assertTrue(any("超过 4 次接续，画质将无法保证" in error for error in errors))
        shot["continuation_user_approved"] = True
        self.assertEqual(continuation_errors(shot), [])


if __name__ == "__main__":
    unittest.main()
