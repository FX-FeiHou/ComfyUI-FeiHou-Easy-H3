import copy
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import unittest
from model_support import model_errors, adapt_template
from build_pages import build
from audio_references import validate_audio_references

ROOT = Path(__file__).resolve().parents[1]


class ModelTests(unittest.TestCase):
    def project(self):
        prompt = '以 @图片 1 为讲者身份依据，@音频 1 只提供音色参考。说：“MiniMax H3”。'
        return {
            "prompt_model": "seedance", "seedance_profile": "seedance-2.0-generic",
            "package_mode": "digital_human", "title": "测试",
            "assets": [{"id": "P1", "kind": "generated", "reference_ids": [],
                        "prompt_en": "A presenter.", "prompt_zh": "人物。"}],
            "audio_references": [{"id": "A4", "file": "A4.wav"}],
            "video_references": [],
            "page_titles": {"asset": "资产", "h3": "Seedance 提示词", "list": "中文列表"},
            "shots": [{"id": "SD-001", "seconds": 12, "range": "00:00:000–00:00:000",
                       "references": ["P1"], "audio_references": ["A4"], "video_refs": [],
                       "speech": "MiniMax H3", "prompt_zh": prompt,
                       "nl_prompt_zh": "讲者 @图片 1 站在演播室里口播。",
                       "camera": "固定", "scene": "演播室", "action": "口播", "continuity": "保持",
                       "continuation_mode": "none", "continuation_frames": 0,
                       "continuation_count": 0, "continuation_user_approved": False}]}

    def test_selection_required_and_exclusive(self):
        for model in (None, "", "both", ["h3", "seedance"]):
            p = self.project()
            p["prompt_model"] = model
            self.assertTrue(model_errors(p))

    def test_seedance_and_mixed_syntax(self):
        p = self.project()
        self.assertEqual(model_errors(p), [])
        self.assertEqual(validate_audio_references(p), [])
        p["shots"][0]["prompt_zh"] += " subject_definitions:"
        self.assertTrue(model_errors(p))
        p = self.project()
        p["prompt_model"] = "h3"
        self.assertTrue(model_errors(p))

    def test_limits_and_order(self):
        for seconds in (3, 16, float("nan")):
            p = self.project()
            p["shots"][0]["seconds"] = seconds
            self.assertTrue(model_errors(p))
        p = self.project()
        p["shots"][0]["prompt_zh"] = "@图片 1 @音频 4"
        self.assertTrue(model_errors(p))
        p = self.project()
        p["shots"][0]["audio_references"] = ["A4"] * 4
        self.assertTrue(model_errors(p))
        p = self.project()
        p["seedance_profile"] = "seedance-2.5"
        self.assertTrue(model_errors(p))

    def test_templates_and_payload(self):
        p = self.project()
        with tempfile.TemporaryDirectory() as tmp:
            for template in (ROOT / "assets/templates").glob("*.html"):
                source = template.read_text(encoding="utf-8")
                self.assertEqual(adapt_template(source, {"prompt_model": "h3"}), source)
                output = Path(tmp) / template.name
                build(template, output, p)
                rendered = output.read_text(encoding="utf-8")
                match = re.search(r'<script id="dh-project-data" type="application/json">(.*?)</script>', rendered, re.S)
                self.assertEqual(json.loads(match[1]), p)
                without_payload = rendered.replace(match[1], "{}")
                self.assertNotIn("Official Ref2VA", without_payload)
                self.assertNotIn("&lt;Picture N&gt;", without_payload)
                # Parse all JavaScript, including adapted renderer, without executing a browser.
                for attrs, script in re.findall(r"<script([^>]*)>(.*?)</script>", rendered, re.S):
                    if "application/json" in attrs:
                        continue
                    result = subprocess.run(["node", "-e", "new (require('vm').Script)(require('fs').readFileSync(0,'utf8'))"],
                                            input=script, text=True, capture_output=True)
                    self.assertEqual(result.returncode, 0, result.stderr)

    def test_cli_build_and_validation(self):
        p = self.project()
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder / "A4.wav").touch()
            for script, args in (("validate_project_data.py", ["-", "--asset-root", tmp]),
                                 ("build_pages.py", ["-", tmp])):
                result = subprocess.run([sys.executable, "-B", str(ROOT/"scripts"/script), *args],
                                        input=json.dumps(p), text=True, encoding="utf-8", capture_output=True)
                self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertEqual(len(list(folder.glob("*.html"))), 3)
            self.assertTrue((folder/"03.测试_分镜提示词.html").is_file())
            self.assertTrue((folder/"01.测试_资产清单.html").is_file())
            self.assertTrue((folder/"02.测试_分镜列表.html").is_file())
            self.assertFalse(list(folder.glob("*.json")))


if __name__ == "__main__":
    unittest.main()
