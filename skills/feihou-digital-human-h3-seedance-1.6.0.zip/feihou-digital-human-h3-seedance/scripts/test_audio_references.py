import copy
from pathlib import Path
import tempfile
import unittest
from audio_references import normalize_range, resolve_audio, validate_audio_references, normalize_project_audio
from build_pages import build


class AudioContractTests(unittest.TestCase):
    def setUp(self):
        self.catalog = [{"id": f"A{i}", "file": f"A{i}.wav"} for i in range(1, 6)]
        prompt = "subject_definitions:\n" + "\n".join(f"<Audio {i}> is voice reference for <Subject {i}> (S{i})." for i in range(1, 5)) + "\nsummary: audio reference"
        self.shot = {"id":"H3-001", "seconds":12.6, "range":"00:00:000–00:00:000", "audio_references":[{"id": f"A{i}"} for i in (4, 2, 1, 3)], "prompt_zh":prompt,
                     "continuation_mode":"none", "continuation_frames":0, "continuation_count":0, "continuation_user_approved":False}
        self.project = {"prompt_model":"h3", "package_mode":"digital_human", "audio_references":self.catalog, "shots":[self.shot]}

    def test_order_more_than_three_and_unused_catalog(self):
        self.assertEqual([a['id'] for a in resolve_audio(self.shot, self.catalog)], ['A4','A2','A1','A3'])
        self.assertEqual(validate_audio_references(self.project), [])

    def test_empty_overrides_legacy_and_bad_label(self):
        self.shot.update(audio_references=[], voice_reference='A5.wav', prompt_zh='')
        self.assertEqual(resolve_audio(self.shot, self.catalog), [])
        self.assertEqual(validate_audio_references(self.project), [])
        self.shot['prompt_zh'] = '<Audio 1>'
        self.assertTrue(validate_audio_references(self.project))

    def test_ranges(self):
        self.assertEqual(normalize_range('00:20:940–00:00:000'), '00:20:900–00:00:000')
        self.assertEqual(normalize_range('00:20:950–00:25:050'), '00:21:000–00:25:100')
        with self.assertRaises(ValueError):
            normalize_range('00:02:000–00:01:000')

    def test_file_resolution_and_ambiguity(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            for item in self.catalog:
                (root / item['file']).touch()
            self.assertEqual(validate_audio_references(self.project, root), [])
            self.catalog[0]['file']='missing/A1.wav'
            self.assertEqual(validate_audio_references(self.project, root), [])
            (root/'duplicate').mkdir()
            (root/'duplicate/A1.wav').touch()
            self.assertTrue(validate_audio_references(self.project, root))
            self.catalog[0]['file']='../A1.wav'
            self.assertTrue(validate_audio_references(self.project, root))

    def test_rendered_json_is_ordered_and_escaped(self):
        import json
        import re
        project = copy.deepcopy(self.project)
        project['title']='test </script>'
        normalize_project_audio(project)
        with tempfile.TemporaryDirectory() as tmp:
            for template in (Path(__file__).resolve().parents[1]/'assets/templates').glob('*.html'):
                output = Path(tmp)/template.name
                build(template, output, project)
                text = output.read_text(encoding='utf-8')
                payload = re.search(r'<script id="dh-project-data" type="application/json">(.*?)</script>',text,re.S).group(1)
                data=json.loads(payload)
                self.assertEqual(data['shots'][0]['seconds'],12.6)
                self.assertEqual([a['id'] for a in data['shots'][0]['audio_references']],['A4','A2','A1','A3'])
                self.assertNotIn('</script>',payload)


if __name__ == '__main__':
    unittest.main()
