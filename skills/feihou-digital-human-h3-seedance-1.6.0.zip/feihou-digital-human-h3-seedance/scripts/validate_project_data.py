#!/usr/bin/env python3
"""Validate the in-memory project-data invariants that affect H3 pages.

Read JSON from standard input only. This deliberately prevents a persisted
project-manifest.json from becoming part of a project or delivery package.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import sys
from asset_references import validate_asset_references
from audio_references import validate_audio_references
from continuation import continuation_errors
from model_support import model_errors

RANGE = re.compile(r"^\d{2}:\d{2}:\d{3}–\d{2}:\d{2}:\d{3}$")
ZERO_RANGE = "00:00:000–00:00:000"
AUDIO_EXTENSIONS = {".mp3", ".wav", ".flac", ".ogg", ".m4a", ".aac"}
VIDEO_EXTENSIONS = {".mp4", ".mov", ".webm", ".mkv", ".avi"}


def validate_reference_files(errors: list[str], items: object, prefix: str, extensions: set[str]) -> None:
    if not isinstance(items, list):
        errors.append(f"{prefix.lower()}_references must be a list")
        return
    if len(items) > 3:
        errors.append(f"{prefix.lower()}_references supports at most 3 files")
    for index, item in enumerate(items, 1):
        if not isinstance(item, dict):
            errors.append(f"{prefix}{index}: reference must be an object")
            continue
        expected = f"{prefix}{index}"
        filename = str(item.get("file", ""))
        path = Path(filename)
        if item.get("id") != expected:
            errors.append(f"{prefix}{index}: id must be {expected}")
        if path.stem != expected or path.suffix.lower() not in extensions:
            allowed = ", ".join(sorted(extensions))
            errors.append(f"{prefix}{index}: file must be {expected} with a supported extension ({allowed})")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project_data", choices=["-"], help="Read project JSON from stdin")
    parser.add_argument("--asset-root", type=Path, help="Package directory for checking image files")
    args = parser.parse_args()
    raw = sys.stdin.read()
    if not raw.strip():
        print("Project-data validation failed:\n- no JSON received on stdin")
        sys.exit(1)
    data = json.loads(raw)
    errors: list[str] = validate_asset_references(data, args.asset_root)
    errors.extend(validate_audio_references(data, args.asset_root))
    errors.extend(model_errors(data))
    seen: set[str] = set()
    assets = {item.get("id") for item in data.get("assets", [])}
    audio_references = data.get("audio_references", [])
    video_references = data.get("video_references", [])
    digital_human = data.get("package_mode") == "digital_human"
    if digital_human and data.get("master_audio"):
        errors.append("digital-human packages must not declare master_audio")
    for audio in audio_references if isinstance(audio_references, list) else []:
        if isinstance(audio, dict) and digital_human and audio.get("role", "voice_timbre_reference") != "voice_timbre_reference":
            errors.append("digital-human audio_references only allow voice_timbre_reference")
    validate_reference_files(errors, video_references, "V", VIDEO_EXTENSIONS)
    for index, shot in enumerate(data.get("shots", []), 1):
        label = shot.get("id", f"shot {index}")
        errors.extend(continuation_errors(shot))
        if label in seen:
            errors.append(f"duplicate shot id: {label}")
        seen.add(label)
        if not RANGE.fullmatch(shot.get("range", "")):
            errors.append(f"{label}: range must use MM:SS:ddd–MM:SS:ddd")
        if digital_human:
            if shot.get("range") != ZERO_RANGE:
                errors.append(f"{label}: digital-human range must be {ZERO_RANGE}")
            try:
                seconds = float(shot["seconds"])
            except (KeyError, TypeError, ValueError):
                errors.append(f"{label}: digital-human shots require numeric seconds")
            else:
                if not 0.2 <= seconds <= 30:
                    errors.append(f"{label}: seconds must be within Easy H3's 0.2–30s range")
            if "audio_slice" in shot:
                errors.append(f"{label}: digital-human shots must not contain audio_slice")
        refs = shot.get("references", [])
        if len(refs) > 9:
            errors.append(f"{label}: {len(refs)} visual references exceed H3's 9-image cap")
        unknown = [ref for ref in refs if ref not in assets]
        if unknown:
            errors.append(f"{label}: unknown asset IDs: {', '.join(unknown)}")
        if not shot.get("speech"):
            errors.append(f"{label}: provide speech or the exact text 本段无口播")
        for field in ("prompt_zh", "camera", "scene", "action", "continuity"):
            if not shot.get(field):
                errors.append(f"{label}: missing {field}")
        # 提示词槽位门禁：H3 的 <Picture n> 必须落在本镜 references 范围内，越界会导致整包退回。
        for field in ("prompt_zh", "nl_prompt_zh"):
            body = shot.get(field, "")
            if isinstance(body, str) and body.strip():
                for value in re.findall(r"<Picture\s+(\d+)>", body):
                    if not 1 <= int(value) <= len(refs):
                        errors.append(
                            f"{label}: {field} 的 <Picture {int(value)}> 越界，本镜只有 {len(refs)} 项图片引用"
                        )
    if errors:
        print("Project-data validation failed:", *errors, sep="\n- ")
        sys.exit(1)
    print(f"Project data valid: {len(data.get('assets', []))} assets, {len(data.get('shots', []))} shots")


if __name__ == "__main__":
    main()
