"""Validation helpers for digital-human shot continuation settings."""
from __future__ import annotations

CONTINUATION_MODES = {
    "none",
    "tail_frame",
    "first_frame",
    "first_last_frame",
    "custom",
}

MAX_CONTINUATIONS = 4  # 单条链默认可连续接续的最大次数

QUALITY_WARNING = f"超过 {MAX_CONTINUATIONS} 次接续，画质将无法保证"


def _is_int(value: object) -> bool:
    return isinstance(value, int) and not isinstance(value, bool)


def continuation_errors(shot: dict) -> list[str]:
    """Return errors for the per-shot continuation contract."""
    label = shot.get("id", "shot")
    errors: list[str] = []
    mode = shot.get("continuation_mode")
    frames = shot.get("continuation_frames")
    count = shot.get("continuation_count")
    approved = shot.get("continuation_user_approved")

    if mode not in CONTINUATION_MODES:
        errors.append(
            f"{label}: continuation_mode must be one of "
            f"{', '.join(sorted(CONTINUATION_MODES))}"
        )
    if not _is_int(frames) or frames < 0:
        errors.append(f"{label}: continuation_frames must be a non-negative integer")
    if not _is_int(count) or count < 0:
        errors.append(f"{label}: continuation_count must be a non-negative integer")
    if not isinstance(approved, bool):
        errors.append(f"{label}: continuation_user_approved must be boolean")

    if _is_int(frames) and _is_int(count) and mode in CONTINUATION_MODES:
        if mode == "none":
            if frames != 0:
                errors.append(f"{label}: continuation_mode none requires continuation_frames 0")
            if count != 0:
                errors.append(f"{label}: continuation_mode none requires continuation_count 0")
        else:
            if frames < 1:
                errors.append(f"{label}: an active continuation mode requires continuation_frames >= 1")
            if count < 1:
                errors.append(f"{label}: an active continuation mode requires continuation_count >= 1")

        if count > MAX_CONTINUATIONS and approved is not True:
            errors.append(
                f"{label}: continuation_count > {MAX_CONTINUATIONS} requires explicit user approval after notice: {QUALITY_WARNING}"
            )

    return errors
