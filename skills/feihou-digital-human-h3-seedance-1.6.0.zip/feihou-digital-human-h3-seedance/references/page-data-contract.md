# 数字人口播生产页数据契约

双模型版补充契约优先见 [model-routing.md](model-routing.md)。项目必填 prompt_model（h3 或 seedance）；Seedance 必填 seedance_profile=seedance-2.0-generic。下方 JSON 是 H3 字段示例，使用前必须补齐模型选择，不能原样当成 Seedance 示例。**分镜提示词只写中文**，不再有英文栏：Seedance 的 `prompt_zh` 是自然语言，禁止六段式，references 顺序映射 `@图片 N`，每镜 audio_references/video_refs 分别映射 `@音频 N`/`@视频 N`；H3 的 `prompt_zh` 用官方六段式，references 顺序映射 `<Picture N>`，音频/视频分别是 `<Audio N>`/`<Video N>`。**02 分镜列表页另有 `nl_prompt_zh`（中文自然语言提示词，一律用 `@图片 N`/`@视频 N`/`@音频 N` 记法）**。本配置每镜 4–15 秒、最多 9 图/3 音频/3 视频；旧文中的无限音频与 Easy H3 时长仅属 H3 加载器。page_titles.h3 保留兼容键名但值改成 Seedance，输出页固定为 `03.####_分镜提示词.html`。调用本双模型技能目录内的脚本，不调用原版脚本。

三页由同一份**内存项目数据**生成。以 `assets/project-data.template.json` 作为字段参考，在内存或标准输入中填写项目数据，先运行 `scripts/validate_project_data.py -`，最后运行 `scripts/build_pages.py -`。**不得**在项目目录或交付物中创建 `project-manifest.json`；三张 HTML 内联的 `dh-project-data` 是唯一允许保留的项目数据副本。

```json
{
  "title": "项目名称",
  "subtitle": "可选页眉副标题",
  "page_titles": {
    "asset": "资产清单",
    "h3": "分镜提示词",
    "list": "分镜列表"
  },
  "package_mode": "digital_human",
  "audio_references": [
    {
      "id": "A1",
      "file": "A1.mp3",
      "role": "voice_timbre_reference",
      "h3_label": "<Audio 1>",
      "speaker": "<Subject 1> (S1)"
    }
  ],
  "video_references": [
    {
      "id": "V1",
      "file": "V1.mp4",
      "h3_label": "<Video 1>"
    }
  ],
  "source_documents": [
    {
      "path": "需求与台词.docx",
      "role": "production_requirements | locked_script | both",
      "status": "readable"
    }
  ],
  "production_requirements": [
    "从用户文档或对话确认后采用的制作要求摘要"
  ],
  "locked_script_source": {
    "kind": "document | conversation | ai_generated",
    "path": "需求与台词.docx；非文档来源时留空"
  },
  "total_duration_seconds": 96.5,
  "timing_note": "数字人分镜：时长由各镜 seconds 指定；range 固定为全零，仅供共用页面显示。",
  "aspect_ratio": "16:9",
  "resolution": "3840x2160",
  "language": "中文",
  "style_note": "写实演播室",
  "pacing_style": "normal 或 fast_cut（电商带货节奏风格，其他场景留空）",
  "assets": [
    {
      "id": "P1",
      "asset_id": "HOST-01",
      "name": "讲者或资产名称",
      "kind": "locked 或 generated",
      "reference_ids": [],
      "use": "它在 H3 中服务的镜头和用途",
      "prompt_en": "English GPT Image 2 自然语言提示词（正面陈述）",
      "prompt_zh": "中文自然语言工作版提示词"
    }
  ],
  "shots": [
    {
      "id": "H3-001",
      "range": "00:00:000–00:00:000",
      "seconds": 6.4,
      "section": "开场 / 引入",
      "title": "分镜名称",
      "mode": "speak | demo | broll | hold",
      "performer": "出镜讲者，或 画外音 / 插入画面",
      "audio_references": [{"id": "A1", "range": "00:00:000–00:00:000"}],
      "video_refs": ["V1.mp4"],
      "speech": "本镜锁定台词原文，或 本段无口播",
      "references": ["P1", "P2"],
      "continuation_mode": "none",
      "continuation_frames": 0,
      "continuation_count": 0,
      "continuation_user_approved": false,
      "camera": "全中文机位、构图、运镜与主动态",
      "scene": "全中文场景与用光",
      "action": "全中文完整动作叙事",
      "continuity": "硬切说明，或上一终帧到本首帧的连续关系和本镜终帧",
      "prompt_zh": "完整中文工作提示词（H3 六段式，或 Seedance 自然语言），引用用 <Picture N> / @图片 N",
      "nl_prompt_zh": "分镜列表页的完整中文自然语言提示词，引用一律写 @图片 N / @视频 N / @音频 N"
    }
  ]
}
```

## 硬性约束

- `page_titles` 必填。`asset`、`h3`、`list` 分别是资产页、H3 提示词页和中文分镜页的浏览器标题与页面主标题；模板的标题由这三个字段统一设定。
- 数字人项目必须写 `package_mode: "digital_human"`。不得写 `master_audio`，不提供分段试听或背景音轨。
- `source_documents`、`production_requirements` 与 `locked_script_source` 为可选的内存来源记录：扫描到并采用文档时，记录实际相对路径、用途与可读状态；制作要求是已经决定资产、分镜和提示词的约束摘要；`locked_script_source.kind` 为 `document`、`conversation` 或 `ai_generated`。这些字段可被三页内联数据保留，但不得另行写成 `project-manifest.json`。任何“稍后提供”的素材/文档不得记录为已读或已引用。
- 每个数字人镜头只有两个时间字段：`range` 固定为 `00:00:000–00:00:000`，只为与 MV 共用页面模板而显示；`seconds` 是 0.2–30 的数值，是页面时长与 H3 生成时长的唯一来源。不得写 `audio_slice`，也不得用 `range` 推导时长。
- `references` 是全局 `P#`（人物、场景、产品/道具合计）。每个镜头最多九项；H3 中的 `<Picture N>` 严格按该数组顺序换算。
- 项目级 `audio_references` 仅为可选音频资产目录，ID 唯一、file 为真实的制作包根目录相对路径。每镜必须显式写独立有序 `audio_references`，仅加载所列素材；空列表表示无音频。局部 `<Audio N>` 由该镜列表位置决定，不由全局 A# 决定。数量不设人为上限。
- 音频参考文件按输入顺序命名为 `A1`、`A2`、`A3`、`A4` 等，视频参考文件按输入顺序命名为 `V1`、`V2`、`V3`；复制到制作包时保留原文件扩展名，例如 `A1.mp3`、`A2.wav`、`V1.mp4`、`V2.mov`。不得另起任意文件主名。页面必须展示实际带扩展名的 `file` 值。
- `video_references` 中的 `V#` 是项目级视频资产 ID，`h3_label` 是当前 H3 单元的 `<Video N>` 标签；每镜的 `video_refs` 填写实际带扩展名的文件名，如 `V1.mp4`。每镜最多三个参考视频。
- 数字人音频仍只作音色参考，不作背景音；每镜 audio_references 条目默认 range 全零，用户明确指定片段时才填写独立素材范围。新列表覆盖旧 voice_reference/audio_file；新包不再生成旧字段。全部细节与校验流程见 [production-pack-audio.md](production-pack-audio.md)。
- 每个 `speech` 必填；无口播时填写精确文本 `本段无口播`。口播台词与锁定脚本逐字一致。
- `mode` 取值：`speak`（出镜口播）、`demo`（出镜演示/操作）、`broll`（画外音插入画面）、`hold`（静置/空镜）。
- 接续字段为每镜必填：`continuation_mode` 取 `none`、`tail_frame`、`first_frame`、`first_last_frame` 或 `custom`；`continuation_frames` 为每次接续使用的正整数帧数，不接续时为 `0`；`continuation_count` 为实际接续次数，不接续时为 `0`；`continuation_user_approved` 默认 `false`，仅当接续次数超过 `4` 且已向用户告知“超过 4 次接续，画质将无法保证”并取得明确同意时为 `true`。
- 接续次数默认最多 `2` 次。`continuation_count > 2` 时，正式提示词、HTML 页面和后续生成均必须暂停，先完成用户告知与同意；校验数据时必须提供 `continuation_user_approved: true`。`continuation_mode` 为 `none` 时，接续帧数和接续次数必须都是 `0`。
- **分镜提示词只写中文**：`prompt_zh` 是按 `prompt_model` 写出的完整提示词；H3 分支的字段名与结构标签（`subject_definitions:`、`<Picture N>`、`<Audio N>`、`<Video N>`、`[Shot N]`、`(Sx)`、`<d>`）保持英文原样，其余内容中文。`prompt_en` 已废弃：不再要求填写，页面也不再显示；旧包里的该字段会被忽略。
- `nl_prompt_zh` 是 02 分镜列表页的完整中文自然语言提示词（Seedance 兼容），引用一律写 `@图片 N` / `@视频 N` / `@音频 N`；`n` 是该镜对应引用列表内的 1-based 位置。未到该阶段允许留空，页面显示「待填写」。
- **引用槽位门禁**：`<Picture n>` 必须满足 `1 <= n <= len(shots[].references)`，越界会校验失败并报出镜号——这类错误在 H3 端会被判成 `prompt references an unavailable Picture slot` 导致整包退回。Seedance 分支下 `@图片 N`/`@视频 N`/`@音频 N` 的编号集合必须与上传顺序集合完全一致。
- 资产卡 `prompt_en` / `prompt_zh` 为自然语言段落式图像提示词，按官方顺序组织（场景→主体→细节→风格→构图→用光→色彩→文字→正面约束），全部为正面陈述；用途、类型、`P#` 等管理信息留在卡片展示层。
- `camera`、`scene`、`action`、`continuity` 同时服务分镜列表，页面之间共享同一套内容。
- `continuation_mode`、`continuation_frames`、`continuation_count` 和 `continuation_user_approved` 同时服务分镜提示词页与分镜列表；`continuity` 与 `prompt_zh` 必须用自然语言说明接续方式、帧数、次数和首尾状态。
- 时长估算依据记录在 `timing_note`；总时长记录在 `total_duration_seconds`；用途记录在项目说明或 `subtitle`，并体现在 `page_titles` 后缀中。
- `pacing_style` 仅电商带货项目必填：`normal`（每单元 1–2 个内部切镜）或 `fast_cut`（约 15 秒单元内 2–3 秒一次高密度切镜），由启动确认确定；其他场景留空。
- 四个项目定义项随启动确认一并核对：各镜时长与估算依据记录在 `seconds`、`total_duration_seconds` 与 `timing_note`（`timing_note` 同时记录语速档位，如：预估，稳档 160–200 字/分钟），画幅与分辨率记录在 `aspect_ratio` 与 `resolution`（写入 GPT Image 2 资产卡与分镜 meta），口播语言记录在 `language`（决定 `<d>[Language]` 标签），视觉风格基调记录在 `style_note`（决定 H3 提示词开头风格句与资产风格栏）。用户未提供时使用默认值——预估时长、3840×2160 16:9 横版、中文、写实演播室——并写进启动确认清单供用户调整。

## 生成命令

`<技能包目录>` 指本技能的安装位置（例如 Windows 下的 `%USERPROFILE%\.codex\skills\feihou-digital-human-h3-seedance`）；`<输出目录>` 为三张 HTML 的交付目录。以下演示以 PowerShell 内存字符串传递数据，**不创建项目 JSON 文件**。

```powershell
$projectData = @'
{ ...符合本页数据契约的 JSON... }
'@
$projectData | py -3.12 <技能包目录>\scripts\validate_project_data.py -
$projectData | py -3.12 <技能包目录>\scripts\build_pages.py - <输出目录>
```

生成器输出：

1. `01.####_资产清单.html`
2. `02.####_分镜列表.html`
3. `03.####_分镜提示词.html`

`####` 为任务或剧本名称（项目数据 `title`），编号与页名固定不可更改。

每页 `<head>` 内 `<meta charset="utf-8">` 之后、所有 `<style>`/`<script>` 之前，必须紧跟两行页面识别字段：`<meta name="feihou-pack-page" content="...">` 与 `<meta name="feihou-pack-schema" content="1">`。取值按页固定——资产清单 `assets`、分镜列表 `shotlist`、分镜提示词 `prompts`；制作包里必须有且只有一个 `shotlist` 页。两行已内置在 `assets/templates/` 三份模板内，构建器原样输出，不要改动或删除。

## 资产图片路径与依赖

按照 [asset-reference-contract.md](asset-reference-contract.md) 写入每项资产的 `reference_ids`、已有图片的 `file` 和正文 `@P#` 标记。默认 `file` 使用相对 HTML 的图片路径（如 `../P1.png`），不内嵌 Base64；构建前图片应已位于对应位置；执行 `validate_project_data.py - --asset-root <输出目录>` 可同时检查文件存在。H3 shots.references 不承担生图资产之间的连线含义。

## 资产正文质量

`assets[].prompt_en` 与 `prompt_zh` 均为完整提示词，不能把中文字段填成摘要。正式写作按 [asset-prompt-quality.md](asset-prompt-quality.md) 逐项核对参考分工、单一静态状态、构图与交互、资产类型适配及双语一致性。该语义检查由写作者执行，不由现有结构校验器代替。
