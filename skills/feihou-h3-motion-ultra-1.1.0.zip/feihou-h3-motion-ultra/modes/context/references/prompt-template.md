# Remake 六段式模板（英文）

尖括号里的 `<…>` 是要替换的内容。标签固定写法：`<Subject 1>`、`<Picture 1>`、`<Picture 2>`、`<Video 1>`、`[Shot 1]`。

Remake 的规则：原片就是画布、按像素对齐，模型只改你明写要改的东西；**没写进“不保留”清单的东西都会留下来**（原人物的发型、外套、项链、字幕……），所以清单要写全。

## 1. 单人替换（设定图 + 大头图）

```text
subject_definitions:
<Subject 1> is the <人物称呼> in <Picture 1> and <Picture 2>: <眼睛：大小、形状、颜色、双眼皮、睫毛>, <眉毛>, <鼻子>, <嘴和唇色>, <脸型和下巴>, <肤色>; <her/his> face is exactly the face in the close-up <Picture 2>. <She/He> has <发型、发色>, <发饰及位置>; <she/he> wears <上衣>, <配饰>, <下装>, <鞋>.
<Video 1> is the source video to edit: <一句话：拍摄方式、时间、地点>, in which <原人物外观：发型、衣服> <在做什么>. <Her/His> face in <Video 1> is blurred on purpose; only the position and movements of <her/his> head, eyes and mouth are taken from it.
<Picture 1> is a character sheet of <Subject 1> on a <背景色> background: <每一栏是什么角度>. <Picture 2> is a close-up of <her/his> head and face.

summary:
[video editing + character replacement] The <原人物称呼> in <Video 1> becomes <Subject 1>, with the face of <Picture 2> in every frame, most of all in the close shots. Everything else in <Video 1> is unchanged, and the subtitles and text laid over it are removed.

retention_analysis:
<Video 1> (source video editing): fully_preserved - <镜头和运镜>, <背景和场景>, light and colour, <其他人、手、道具>, and the <原人物称呼>'s position, <身体动作>, hand gestures, expressions, gaze, blinks and mouth movements, frame for frame. Not kept at any moment: the original <原人物称呼>'s face, eyes, eyebrows, nose, lips, face shape, makeup, <原人物发型>, <原人物每件衣服>, <原人物每件配饰>, the burned-in subtitles, the overlay text, and the blur on <her/his> face.
<Picture 1> (appears in [Shot 1]): reference - <her/his> hair, <发饰>, figure, <衣服和鞋> from the <角度> views. Its <背景色> background and standing poses are not used.
<Picture 2> (appears in [Shot 1]): reference - <her/his> face, eyes, eyebrows, nose, lips and face shape, in full detail. Its plain background is not used.
<Subject 1> (appears in [Shot 1]): fully_preserved - <her/his> face and look stay the same in every frame, from the wide shots to the face close-ups.

detailed_description:
The target video is a realistic <拍摄方式> <时间> <场景> shot.
[Shot 1] Every frame matches <Video 1>, with <Subject 1> in place of the original <原人物称呼>. In the <近景景别> shots <her/his> face fills much of the frame, and it is the face of <Picture 2>: <再写一遍五官要点>. It is not the original <原人物称呼>'s face: not <原人物最显眼的五官特征 1>, not <特征 2>, not <特征 3>. <She/He> <原片里的主要动作和表情> exactly when and how the original <原人物称呼> does, and <her/his> lips move exactly as in <Video 1>. Only the face doing it has changed. <Her/His> face is sharp and clear in every frame, with no blur, as sharp as the rest of the frame. <发饰> stays <位置> in every frame.
<She/He> is lit by the same <光线> as the rest of the frame, with no <参考图背景色> tint, and blends in as if filmed on the spot.
The video has no subtitles, captions, watermark or logo at any moment: <每种字幕：颜色、位置> are gone, and those areas show what lies behind them.

overall_soundscape:
The original sound of <Video 1>.

non_diegetic_music:
None.
```

要点：
- 五官细节写两遍（`subject_definitions` 一遍、`detailed_description` 近景那句一遍），并且都指向 `<Picture 2>`。
- 对比句只写原人物**最显眼**的 3–4 个五官特征，从原片近景里看。
- 没有大头图时：`@pictures 1`，`<Picture 2>` 的句子全删，“exactly the face in the close-up on the left of <Picture 1>”这类写法指向设定图里的头像栏。

## 2. 对话场景

在 `detailed_description` 的动作句后面加一句，告诉模型哪个声音是被替换的人的。**优先按男声 / 女声区分**（开工时用户已经说明换的是男人还是女人）：

```text
Tell the voices apart by their sound. The <male/female> voice belongs to <对方，如 the man filming behind the camera> and is never <hers/his>: whenever the <male/female> voice is heard, <Subject 1>'s lips stay closed and still and <she/he> only listens. <Subject 1> is a <woman/man> and speaks with a <female/male> voice: <her/his> lips move only with <her/his> own <female/male> voice.
```

- 换的是女人、对方是男声：男声响的时候她不动嘴，只有女声才是她在说；换的是男人则反过来。
- 画面里还有同性别的其他人也说话：在这句后面补一句 `and not with the lines of <那个人> either`，并改用下面的按时间写法。
- 对话双方性别相同、靠声音分不开：用旧写法加按时间的说明。

旧写法（分不出性别时用）：

```text
This is a conversation with <对方>: <her/his> mouth moves only when <she/he> is speaking; while <对方> is talking <she/he> listens with <her/his> mouth closed, exactly as in <Video 1>, and the other voice never moves <her/his> lips.
```

按时间的说明：行首写 `[起-止]`（和 `@range` 同一个时钟），每个窗口只读和自己时间重叠的行；标签会被去掉，所以每行都要带画面特征，让同一个窗口里的两行能分清先后。每块按原片里这个人的嘴实际在不在动来分段：

```text
[00:32.90-00:35.70] <画面特征，如 In the close chest-up shot>, <Subject 1> is the one speaking: <her/his> lips form <her/his> own words in time with <her/his> voice, exactly as in <Video 1>.
[00:35.70-00:48.27] <画面特征，如 After the camera swings away and back>, <Subject 1> does not say a single word. Every voice heard in this part belongs to <对方>. Whenever <Subject 1> is in the frame <her/his> lips rest together or barely parted and stay completely still, with no talking, no lip-sync and no mouthing of the words that are heard.
```

原因见 `field-lessons.md`：模型是跟着原声动嘴的，画面里只有被替换的人露脸时，画外的人说话也会安到这张嘴上。

## 3. 大动作场景

- 动作句写成“照原片”的通用写法：动作、节奏和时间点都跟 `<Video 1>` 一致；有音乐时加 “on the beat of the music”。
- 原片人物不说话时写 “<She/He> does not sing or talk; <her/his> mouth stays as in <Video 1>.”
- 写清楚头发和发饰在大动作里的表现：随动作摆动，发饰在每一帧都在原位。
- 镜头拉远、人物变小时补一句“仍然清楚是穿 <服装> 的 <Subject 1>”。
- 原片里特殊的光照写进受光段。

## 4. 多个场景

每个场景一块，每块都写完整六段；`subject_definitions` 第一句人物定义各块一样，`<Video 1>` 那句换成这一块的场景，下装/鞋在这一块画面里看不到就不写。

## 5. 表情（每块必写）

脸部模糊会把原片的表情一起糊掉，模型只拿得到头的位置和大致的嘴部开合，所以表情要按时间写出来。时间标签和 `@range` 同一个时钟，每个上下文窗口只读和自己重叠的行；标签会被去掉，所以每行都要带画面特征（她在做什么动作），让同一个窗口里的两行能分清先后。

写在 `detailed_description` 的动作段（“…Only the person doing it has changed. … sharp and clear …”）后面：

```text
<Her/His> face in <Video 1> is blurred, so <her/his> expressions are written out here; <she/he> shows them exactly when the original <原人物称呼> does:
[00:00.00-00:03.00] <这一段的动作>, <she/he> <表情：如 looks down into the lens with a cool, confident face, lips closed>.
[00:03.00-00:08.00] <这一段的动作>, <she/he> <表情：如 breaks into a big bright smile, then laughs with <her/his> mouth open>.
[00:08.00-00:12.00] ...
```

要点：
- 从原片逐秒看：每段 2–6 秒，表情一变就新起一行；整块首尾相接，最后一行到块尾。
- 写清楚嘴：闭嘴笑、张嘴大笑、说话分开写。原片里张嘴笑的地方，口型句要跟着改成 “closed, in a smile, or open only when <she/he> laughs”，不然“不说话”那句会把笑也压住。
- 转身、背对镜头的那几秒写 “<her/his> face is hidden”，不编表情。
- 脸大多看不到的片子（背影、远景跑步）不写时间行，只写一句：`<Her/His> face in <Video 1> is blurred and is seen only in short glimpses, so <her/his> expression is written out here: whenever it is seen <she/he> has <总体表情>.`
- 有对话的块，表情行和口型规则一起写，表情行里不写台词。
