# 实测经验

## 去字幕

Remake 会保留画布上没被要求改的一切，烧录字幕也一样。三处都要写：

1. `summary`：`…and the subtitles and text laid over it are removed.`
2. `retention_analysis` 的不保留清单：`the burned-in subtitles, the overlay text`（有彩色标题、括号心声字幕就单独点名）。
3. `detailed_description` 最后一段：`The video has no subtitles, captions, watermark or logo at any moment: <每种字幕的颜色和位置> are gone, and those areas show what lies behind them.` 写出字幕后面原本是什么。

画面里真实存在的文字要写“stay”，免得一起被抹掉。

## 别人说话时她也动嘴

原因：模型是跟着原声动嘴的。画面里只有被替换的人露脸、说话的人在画外时，这句话就会安到她嘴上。这和脸部模糊的强弱无关：实测模糊 1 档和 5 档都一样乱动。笼统地写“只在自己说话时动嘴”不够，模型分不清哪句是她说的。

对策按顺序用：

1. **按男声 / 女声区分（首选）**：开工时用户会说明换的是男人还是女人。换的是女人、对方是男声，就写明男声响的时候她闭嘴听、只有女声才是她在说；换的是男人反过来。写法见 `prompt-template.md` 第 2 节。
2. **按时间分段写**：对话双方性别相同，或画面里还有同性别的其他人也说话时，在 `detailed_description` 里用行首 `[起-止]` 的时间标签，逐段写她在说话还是只听，每行带画面特征。哪几秒她在说，以原片里这个人的嘴实际动不动为准（逐帧看，或用人脸关键点量嘴部开合），不要凭单张截图里嘴张着就当成在说话：张着嘴不动是在听。
3. 两种写法可以一起用。

改写或精简提示词时这几句最容易被删掉，交付前搜一下。

## 参考图背景渗色

彩色底的设定图，底色会渗进画面：在 `<Picture N>` 的 reference 行写 `Its <颜色> background … are not used`，受光段写 `with no <颜色> tint`。

## 原人物的东西留下来

Remake 只改明写的部分：原人物的每件衣服、配饰和发型都要一件件写进不保留清单，同时在 `subject_definitions` 写清楚换成的那件。

## 发饰

高出头顶的发饰在低头、转身、画面上边界附近时容易丢：写 `stays upright on <her/his> head in every frame`。

## 分段输出

上下文窗口每段上限 30 秒时，长块会分几次运行：每段一个 `_seg` 文件，外加整块合并后的视频；一块只有一段时不再单独存 `_seg`。

## Setup 卡住

1080p 以上的长视频按“原始”尺寸载入，整段解码会占几十 GB 内存，看起来卡在 Setup。视频卡片“媒体设置”的尺寸保持默认 720P（或手选 720P）就好；H3 的画布短边只有 768，720P 画质几乎没差。
