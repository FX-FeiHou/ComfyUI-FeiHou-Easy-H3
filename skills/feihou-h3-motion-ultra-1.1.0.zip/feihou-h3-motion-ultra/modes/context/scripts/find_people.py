"""Group the faces of a source video into people and write @blur_people lines.

Uses the same models as the H3动作迁移预处理 node, from ComfyUI's models folder
(nothing is downloaded): models/ultralytics/bbox/face_yolov8m.pt (detection) and
models/insightface/models/<pack>/2d106det.onnx + a recognition model (alignment, identity);
default buffalo_l/w600k_r50.onnx, the same default as the node's 人脸识别模型.
Run it with ComfyUI's Python (it has ultralytics and onnxruntime):

    python find_people.py 原视频.mp4 --models <ComfyUI>/models [--md 分镜.md] [--blur 1,3] [--out 人物.png]

Without --blur: prints every person found (人物1, 人物2 …, most frequent first) and
writes a sheet with their faces over time; show it to the user and ask whom to blur.
With --blur 1,3: prints one `@blur_people` line per md block (or one for the whole
video without --md), each person's clearest frontal moment inside that block.
"""
import argparse
import os
import re
import sys

import cv2
import numpy as np
from PIL import Image, ImageDraw

ARC = np.array([[38.2946, 51.6963], [73.5318, 51.5014], [56.0252, 71.7366], [41.5493, 92.3655], [70.7299, 92.2041]],
               dtype=np.float32)
FIVE = [38, 88, 86, 52, 61]
GROUP = 0.35   # same person when this similar to the group's mean
MATCH = 0.2    # the node's match threshold


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("video")
    ap.add_argument("--models", required=True, help="ComfyUI 的 models 目录")
    ap.add_argument("--md", help="分镜 md：按每块的 @range 给每块写一行 @blur_people")
    ap.add_argument("--blur", help="要模糊的人物编号，逗号分隔，例如 1,3")
    ap.add_argument("--rate", type=float, default=2.0, help="每秒取几帧（默认 2）")
    ap.add_argument("--recognizer", default="buffalo_l/w600k_r50.onnx",
                    help="人脸识别模型「包/文件」，和预处理节点的「人脸识别模型」选同一个（默认 buffalo_l/w600k_r50.onnx）")
    ap.add_argument("--out", default="人物.png", help="人物缩略图输出路径")
    return ap.parse_args()


def md_ranges(path):
    """(block number, start s, end s) of every block of a shot md."""
    def seconds(text):
        parts = [float(p) for p in text.strip().split(":")]
        value = 0.0
        for p in parts:
            value = value * 60 + p
        return value
    blocks, current = [], None
    for line in open(path, encoding="utf-8"):
        sentinel = re.match(r"=+\s*FEIHOU_SHOT\s+(\d+)\s*=+", line.strip())
        if sentinel:
            current = int(sentinel.group(1))
            continue
        found = re.match(r"@range\s+([0-9:.]+)\s*[-–—~]\s*([0-9:.]+)", line.strip())
        if found and current is not None:
            blocks.append((current, seconds(found.group(1)), seconds(found.group(2))))
    return blocks


def main():
    args = parse_args()
    import onnxruntime as ort
    from ultralytics import YOLO

    providers = [p for p in ("CUDAExecutionProvider", "CPUExecutionProvider") if p in ort.get_available_providers()]
    detector = YOLO(os.path.join(args.models, "ultralytics", "bbox", "face_yolov8m.pt"))
    pack, _, model = args.recognizer.replace("\\", "/").partition("/")
    folder = os.path.join(args.models, "insightface", "models", pack)
    lmk = ort.InferenceSession(os.path.join(folder, "2d106det.onnx"), providers=providers)
    rec = ort.InferenceSession(os.path.join(folder, model or "w600k_r50.onnx"), providers=providers)

    def embed(frame, box):
        x1, y1, x2, y2 = box
        cx, cy, size = (x1 + x2) / 2, (y1 + y2) / 2, max(x2 - x1, y2 - y1) * 1.5
        scale = 192 / size
        m = np.array([[scale, 0, 96 - cx * scale], [0, scale, 96 - cy * scale]], dtype=np.float32)
        blob = cv2.dnn.blobFromImage(cv2.warpAffine(frame, m, (192, 192)), 1.0, (192, 192), (0, 0, 0), swapRB=True)
        pts = (lmk.run(None, {lmk.get_inputs()[0].name: blob})[0].reshape(-1, 2) + 1) * 96
        inv = cv2.invertAffineTransform(m)
        pts = pts @ inv[:, :2].T + inv[:, 2]
        five = pts[FIVE].astype(np.float32)
        align, _ = cv2.estimateAffinePartial2D(five, ARC, method=cv2.LMEDS)
        if align is None:
            return None, None, 0.0
        face = cv2.warpAffine(frame, align, (112, 112), borderValue=0)
        blob = cv2.dnn.blobFromImage(face, 1.0 / 127.5, (112, 112), (127.5, 127.5, 127.5), swapRB=True)
        v = rec.run(None, {rec.get_inputs()[0].name: blob})[0][0]
        # Frontal score: the nose tip halfway between the eyes.
        eye_mid = (five[0] + five[1]) / 2
        eye_gap = max(1.0, float(np.linalg.norm(five[1] - five[0])))
        frontal = max(0.0, 1.0 - abs(float(five[2][0] - eye_mid[0])) / eye_gap * 2)
        return v / np.linalg.norm(v), face, frontal

    cap = cv2.VideoCapture(args.video)
    fps = cap.get(cv2.CAP_PROP_FPS) or 24.0
    width, height = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH)), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    step = max(1, round(fps / args.rate))
    faces, index = [], 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        if index % step == 0:
            result = detector.predict(frame, conf=0.3, verbose=False)[0]
            for box, conf in zip(result.boxes.xyxy.cpu().tolist(), result.boxes.conf.cpu().tolist()):
                vector, crop, frontal = embed(frame, box)
                if vector is not None:
                    faces.append({"t": index / fps, "box": box, "conf": conf, "v": vector, "crop": crop,
                                  "score": (box[2] - box[0]) * conf * (0.3 + frontal)})
        index += 1
    print(f"{args.video}: {index / fps:.1f} 秒，{width}x{height}，取样 {index // step} 帧，{len(faces)} 张脸")

    people = []
    for f in sorted(faces, key=lambda f: -f["score"]):
        sims = [float(f["v"] @ (p["sum"] / np.linalg.norm(p["sum"]))) for p in people]
        best = int(np.argmax(sims)) if sims else -1
        if best >= 0 and sims[best] >= GROUP:
            people[best]["faces"].append(f)
            people[best]["sum"] += f["v"]
        else:
            people.append({"faces": [f], "sum": f["v"].copy()})
    people = [p for p in people if len(p["faces"]) >= 3]
    people.sort(key=lambda p: -len(p["faces"]))
    for n, p in enumerate(people, 1):
        times = [f["t"] for f in p["faces"]]
        print(f"人物{n}：{len(p['faces'])} 张脸，{min(times):.1f}–{max(times):.1f} 秒")

    sheet = Image.new("RGB", (100 + 10 * 112, max(1, len(people)) * 112), "black")
    draw = ImageDraw.Draw(sheet)
    for r, p in enumerate(people):
        ordered = sorted(p["faces"], key=lambda f: f["t"])
        picks = [ordered[int(k * (len(ordered) - 1) / 9)] for k in range(min(10, len(ordered)))]
        draw.text((6, r * 112 + 40), f"#{r + 1}\n{len(ordered)} faces", fill="yellow")  # #N = 人物N
        for c, f in enumerate(picks):
            sheet.paste(Image.fromarray(cv2.cvtColor(f["crop"], cv2.COLOR_BGR2RGB)), (100 + c * 112, r * 112))
    sheet.save(args.out)
    print(f"人物缩略图：{os.path.abspath(args.out)}（每行一个人，左边 #N 就是人物N，脸按时间排）")

    if not args.blur:
        print("选好要模糊的人后加 --blur 编号 重跑，得到每块的 @blur_people。")
        return
    chosen = [int(n) for n in re.split(r"[,，\s]+", args.blur.strip()) if n]
    blocks = md_ranges(args.md) if args.md else [(0, 0.0, index / fps)]
    for block, start, end in blocks:
        anchors = []
        for n in chosen:
            if not 1 <= n <= len(people):
                sys.exit(f"没有人物{n}")
            center = people[n - 1]["sum"] / np.linalg.norm(people[n - 1]["sum"])
            inside = [f for f in people[n - 1]["faces"] if start <= f["t"] < end and float(f["v"] @ center) >= MATCH]
            if not inside:
                print(f"块 {block:02d}（{start:.2f}–{end:.2f} 秒）：人物{n} 在这一块里没有露脸，不用写")
                continue
            f = max(inside, key=lambda f: f["score"])
            x = (f["box"][0] + f["box"][2]) / 2 / width
            y = (f["box"][1] + f["box"][3]) / 2 / height
            anchors.append(f"{f['t']:.2f}@{x:.2f}:{y:.2f}")
        label = f"块 {block:02d}" if args.md else "整段"
        print(f"{label}：@blur_people {','.join(anchors)}" if anchors else f"{label}：这几个人都没露脸，这一块不写 @blur_people")


if __name__ == "__main__":
    main()
