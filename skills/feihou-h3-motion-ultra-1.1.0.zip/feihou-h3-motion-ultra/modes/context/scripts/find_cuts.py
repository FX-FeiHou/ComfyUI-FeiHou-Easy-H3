# -*- coding: utf-8 -*-
"""短视频切点粗查（只用 ffmpeg + Pillow + numpy，不需要 TransNetV2）。

用法：
    python find_cuts.py 视频.mp4 [--threshold 0.25] [--max-block 8] [--min-block 1]

做三件事：
1. ffmpeg scene 滤镜找候选切点；
2. 闪光过滤：比较候选点前一帧和后一帧，几乎一样的是闪光/闪白，不算切点；
3. 打印两种交付方案的建议：整段一个提示词，或按切点分块（短于 min-block 的并进相邻块，
   长于 max-block 的连续镜头平均拆开并标 @continue）。
结果只是建议，必须再看拼图人工核对（见 references/workflow-checks.md）。
"""
import argparse, json, re, subprocess, sys, tempfile, os

def probe(path):
    out = subprocess.run(["ffprobe", "-v", "error", "-show_entries",
                          "format=duration:stream=codec_type,width,height,r_frame_rate",
                          "-of", "json", path], capture_output=True, text=True, encoding="utf-8").stdout
    j = json.loads(out)
    dur = float(j["format"]["duration"])
    v = next(s for s in j["streams"] if s["codec_type"] == "video")
    a = any(s["codec_type"] == "audio" for s in j["streams"])
    n, d = v["r_frame_rate"].split("/")
    return dur, float(n) / float(d), v["width"], v["height"], a

def scene_cuts(path, th):
    p = subprocess.run(["ffmpeg", "-hide_banner", "-i", path, "-filter:v",
                        f"select='gt(scene,{th})',showinfo", "-f", "null", "-"],
                       capture_output=True, text=True, encoding="utf-8", errors="ignore")
    return [float(m) for m in re.findall(r"pts_time:([0-9.]+)", p.stderr)]

def grab(path, t, out):
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", f"{max(t,0):.3f}", "-i", path,
                    "-frames:v", "1", "-vf", "scale=160:-1", out])

def is_flash(path, t, fps, tmp):
    try:
        import numpy as np
        from PIL import Image
    except ImportError:
        return False
    a, b, c = (os.path.join(tmp, f"{k}.png") for k in "abc")
    grab(path, t - 1.5 / fps, a); grab(path, t + 1.5 / fps, b); grab(path, t - 0.5 / fps, c)
    try:
        A, B, C = (np.asarray(Image.open(x).convert("L"), dtype=float) for x in (a, b, c))
    except Exception:
        return False
    before_after = abs(A - B).mean()
    jump = max(abs(C - B).mean(), 1e-6)
    return before_after < 0.5 * jump

def plan(cuts, dur, min_b, max_b):
    edges = [0.0] + cuts + [dur]
    blocks = [[edges[i], edges[i + 1]] for i in range(len(edges) - 1)]
    while len(blocks) > 1:
        lens = [b[1] - b[0] for b in blocks]
        i = min(range(len(blocks)), key=lambda k: lens[k])
        if lens[i] >= min_b:
            break
        if i == 0: j = 1
        elif i == len(blocks) - 1: j = i - 1
        else: j = i - 1 if lens[i - 1] >= lens[i + 1] else i + 1
        lo, hi = sorted((i, j))
        blocks[lo:hi + 1] = [[blocks[lo][0], blocks[hi][1]]]
    out = []
    for s, e in blocks:
        n = max(1, int(-(-(e - s) // max_b)))
        step = (e - s) / n
        for k in range(n):
            out.append((s + k * step, s + (k + 1) * step, k > 0))
    return out

def ts(x):
    return f"{int(x // 60):02d}:{x % 60:05.2f}"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("video")
    ap.add_argument("--threshold", type=float, default=0.25)
    ap.add_argument("--min-block", type=float, default=1.0)
    ap.add_argument("--max-block", type=float, default=8.0)
    a = ap.parse_args()
    dur, fps, w, h, has_audio = probe(a.video)
    raw = scene_cuts(a.video, a.threshold)
    with tempfile.TemporaryDirectory() as tmp:
        cuts = [t for t in raw if 0.2 < t < dur - 0.2 and not is_flash(a.video, t, fps, tmp)]
    flashes = [t for t in raw if t not in cuts]
    print(f"视频：{w}x{h}，{fps:.3f} fps，{dur:.2f} 秒，音轨：{'有' if has_audio else '无'}")
    print(f"候选切点 {len(raw)} 个，过滤闪光/边缘后 {len(cuts)} 个：" + ", ".join(f"{t:.2f}" for t in cuts))
    if flashes:
        print("判为闪光或贴边、已忽略：" + ", ".join(f"{t:.2f}" for t in flashes))
    short = sum(1 for i, t in enumerate([0.0] + cuts) if (cuts + [dur])[i] - t < 1.0)
    busy = len(cuts) >= max(4, dur / 4) or short > (len(cuts) + 1) / 3
    print()
    print("建议：" + ("切镜多/快剪 → 分块写更稳" if busy else "切镜少 → 整段一个提示词就够；想更稳也可以分块"))
    print()
    print(f"分块方案（最短 {a.min_block} 秒，最长 {a.max_block} 秒，超长连续镜头平均拆、标 @continue）：")
    for i, (s, e, cont) in enumerate(plan(cuts, dur, a.min_block, a.max_block), 1):
        print(f"  {i:02d}  @range {ts(s)}-{ts(e)}  ({e - s:.2f}s){'  @continue' if cont else ''}")
    print()
    print(f"整段方案：@range 00:00.00-{ts(dur)}，在节点里按帧窗口分段，或自己手动切成几段跑。")

if __name__ == "__main__":
    main()
