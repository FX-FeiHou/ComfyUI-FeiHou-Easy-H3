"""Find hard cuts in a reference video and plan the shot blocks of the md.

Detectors, best first (``--method auto`` takes the first one that works):

1. TransNetV2 (PyTorch port, ``transnetv2_pytorch``): a network trained for shot
   boundaries; ignores flashes / camera shake, sees dissolves.
   Not installed -> run ``install_transnetv2.py`` (Chinese mirrors first).
2. PySceneDetect ``AdaptiveDetector``: classic, steadier than ffmpeg on motion.
3. ffmpeg ``scene`` score: always there, but flashes give false cuts and dark
   cuts are missed; its result must be checked frame by frame.

Run it with a Python that has torch (ComfyUI's), e.g.

    F:\\Ai\\ComfyUI-aki-v3.2\\python\\python.exe detect_cuts.py video.mp4
    ... detect_cuts.py video.mp4 --json cuts.json --min-block 1.0

Prints the detector used, every cut (seconds and frame), and the blocks after
the md rules: blocks under ``--min-block`` seconds merge into the longer
neighbour, a continuous shot over 15 s gets suggested ``@split`` points (even
split; move them to where the framing changes), over 45 s it is split into
blocks joined with ``@continue``, blocks holding 3+ original shots are flagged
as montage.
"""

from __future__ import annotations

import argparse
import json
import math
import re
import shutil
import subprocess
import sys

MAX_BLOCK = 45.0     # one continuous shot per block, at most 3 in-block segments
MAX_SEGMENT = 15.0   # in-block segment (块内分镜)


def video_info(path: str) -> tuple[float, float, int]:
    """(fps, duration seconds, frame count) from ffprobe."""
    out = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-count_packets",
                          "-show_entries", "stream=r_frame_rate,nb_read_packets:format=duration",
                          "-of", "json", path], capture_output=True, text=True, check=True).stdout
    data = json.loads(out)
    stream = data["streams"][0]
    num, den = (stream["r_frame_rate"].split("/") + ["1"])[:2]
    fps = float(num) / float(den or 1)
    frames = int(stream.get("nb_read_packets") or 0)
    duration = float(data["format"]["duration"])
    return fps, duration, frames or round(duration * fps)


def cuts_transnet(path: str, fps: float, threshold: float) -> list[int]:
    import torch
    from transnetv2_pytorch import TransNetV2

    model = TransNetV2(device="auto")
    model.eval()
    with torch.no_grad():
        scenes = model.detect_scenes(path, threshold=threshold)
    return [int(scene["start_frame"]) for scene in scenes[1:]]


def cuts_pyscenedetect(path: str, fps: float, threshold: float) -> list[int]:
    from scenedetect import AdaptiveDetector, detect

    scenes = detect(path, AdaptiveDetector())
    return [scene[0].get_frames() for scene in scenes[1:]]


def cuts_ffmpeg(path: str, fps: float, threshold: float) -> list[int]:
    if shutil.which("ffmpeg") is None:
        raise RuntimeError("PATH 里没有 ffmpeg")
    log = subprocess.run(["ffmpeg", "-hide_banner", "-i", path, "-filter:v",
                          f"select='gt(scene,{threshold})',showinfo", "-f", "null", "-"],
                         capture_output=True, text=True, encoding="utf-8", errors="replace").stderr
    return [round(float(t) * fps) for t in re.findall(r"pts_time:([0-9.]+)", log)]


DETECTORS = {
    "transnet": (cuts_transnet, 0.5, "TransNetV2"),
    "pyscenedetect": (cuts_pyscenedetect, 0.0, "PySceneDetect AdaptiveDetector"),
    "ffmpeg": (cuts_ffmpeg, 0.25, "ffmpeg scene"),
}


def plan_blocks(cuts: list[int], frames: int, fps: float, min_block: float) -> list[dict]:
    """Blocks after the md rules; each keeps the original shots it covers."""
    edges = [0] + sorted({c for c in cuts if 0 < c < frames}) + [frames]
    blocks = [{"start": a, "end": b, "shots": [(a, b)]} for a, b in zip(edges, edges[1:])]
    min_frames = round(min_block * fps)
    while len(blocks) > 1 and min(b["end"] - b["start"] for b in blocks) < min_frames:
        index = min(range(len(blocks)), key=lambda i: (blocks[i]["end"] - blocks[i]["start"], i))
        if index == 0:
            other = 1
        elif index == len(blocks) - 1:
            other = index - 1
        else:
            before, after = blocks[index - 1], blocks[index + 1]
            other = index - 1 if before["end"] - before["start"] >= after["end"] - after["start"] else index + 1
        first, second = sorted((index, other))
        merged = {"start": blocks[first]["start"], "end": blocks[second]["end"],
                  "shots": blocks[first]["shots"] + blocks[second]["shots"]}
        blocks[first:second + 1] = [merged]
    out = []
    for block in blocks:
        length = (block["end"] - block["start"]) / fps
        parts = max(1, math.ceil(length / MAX_BLOCK - 1e-9))
        step = (block["end"] - block["start"]) / parts
        for part in range(parts):
            start = block["start"] + round(part * step)
            end = block["end"] if part == parts - 1 else block["start"] + round((part + 1) * step)
            shots = len(block["shots"])
            count = max(1, math.ceil((end - start) / fps / MAX_SEGMENT - 1e-9))
            splits = [start + round(index * (end - start) / count) for index in range(1, count)]
            out.append({"start": start, "end": end, "continue": part > 0, "original_shots": shots,
                        "montage": shots - 1 >= 3, "splits": splits})
    return out


def stamp(seconds: float) -> str:
    return f"{int(seconds // 60):02d}:{seconds % 60:06.3f}"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("video")
    parser.add_argument("--method", choices=["auto", *DETECTORS], default="auto")
    parser.add_argument("--threshold", type=float, help="检测阈值（TransNetV2 默认 0.5，ffmpeg 默认 0.25）")
    parser.add_argument("--min-block", type=float, default=1.0, help="最短块秒数（默认 1 秒；剧情/口播可用 2）")
    parser.add_argument("--json", help="把结果另存为 JSON")
    args = parser.parse_args()

    fps, duration, frames = video_info(args.video)
    order = list(DETECTORS) if args.method == "auto" else [args.method]
    used, cuts, notes = None, [], []
    for key in order:
        function, default, label = DETECTORS[key]
        try:
            cuts = function(args.video, fps, args.threshold if args.threshold is not None else default)
            used = key
            break
        except ModuleNotFoundError as error:
            notes.append(f"{label} 未安装（{error.name}）")
        except Exception as error:  # a broken install falls through to the next detector
            notes.append(f"{label} 运行失败：{str(error)[:200]}")
    if used is None:
        sys.exit("所有检测方式都失败了：" + "；".join(notes))

    blocks = plan_blocks(cuts, frames, fps, args.min_block)
    label = DETECTORS[used][2]
    print(f"检测方式：{label}")
    for note in notes:
        print(f"  ↳ 退回原因：{note}")
    if used != "transnet" and any("TransNetV2 未安装" in note for note in notes):
        print("  ↳ 建议安装 TransNetV2（国内镜像）：python scripts/install_transnetv2.py")
    if used == "ffmpeg":
        print("  ↳ ffmpeg 会把闪光误报成切点、漏掉暗场切点：必须抽帧逐个核对，暗场片子再用 --threshold 0.12 跑一遍取并集")
    print(f"视频：{fps:g} fps，{duration:.3f} 秒，{frames} 帧；切点 {len(cuts)} 个")
    print("切点（秒 / 帧）：" + ", ".join(f"{c / fps:.3f}/{c}" for c in sorted(cuts)))
    print(f"\n分块（最短 {args.min_block:g} 秒；连续镜头最长 {MAX_BLOCK:g} 秒、块内分镜每段 ≤{MAX_SEGMENT:g} 秒）：{len(blocks)} 块")
    for number, block in enumerate(blocks, 1):
        start, end = block["start"] / fps, block["end"] / fps
        tags = []
        if block["continue"]:
            tags.append("@continue")
        if block["original_shots"] > 1:
            tags.append(f"含 {block['original_shots']} 个原镜头")
        if block["montage"]:
            tags.append("蒙太奇写法")
        if block["splits"]:
            tags.append("@split " + ", ".join(stamp(point / fps) for point in block["splits"])
                        + "（平均分；挪到构图变化处）")
        print(f"  {number:02d}  @range {stamp(start)}-{stamp(end)}  ({end - start:.2f}s)  {'  '.join(tags)}")
    if args.json:
        with open(args.json, "w", encoding="utf-8") as handle:
            json.dump({"method": used, "fallback_notes": notes, "fps": fps, "duration": duration, "frames": frames,
                       "cuts_frames": sorted(cuts), "cuts_seconds": [round(c / fps, 3) for c in sorted(cuts)],
                       "blocks": [{**b, "start_s": round(b["start"] / fps, 3), "end_s": round(b["end"] / fps, 3),
                                   "splits_s": [round(point / fps, 3) for point in b["splits"]]}
                                  for b in blocks]}, handle, ensure_ascii=False, indent=2)
        print(f"\n已保存：{args.json}")


if __name__ == "__main__":
    main()
