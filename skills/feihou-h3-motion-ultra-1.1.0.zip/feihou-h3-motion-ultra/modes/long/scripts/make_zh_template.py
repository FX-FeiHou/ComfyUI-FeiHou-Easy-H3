"""Build the Chinese motion-transfer template from the English one.

    python make_zh_template.py <English guide.md> <Chinese guide.md>

The English template (= references/motion-transfer-rules.md = the node's
「小肥猴H3动作迁移（英文）」) is the source of truth; this swaps only the
language rules and the English example structures. Each swap must match exactly
once, so a change to the English wording fails loudly instead of drifting.
"""

import sys

SWAPS = [
    ("只输出最终提示词。",
     "只输出最终提示词。正文用中文书写，H3 的固定标签和字段名保留英文（见第七部分）。"),
    ("summary 在前缀后以 “The target video is an edited version of <Video 1>.” 开头。",
     "summary 在前缀后以“目标视频是 <Video 1> 的编辑版本。”开头。"),
    ("用英文具体描述外貌", "用中文具体描述外貌"),
    ("全部用英文书写（画面中可见文字保留原语言）。不要输出 markdown、标题、解释或代码块。即使我的提示词是中文，正文也全部用英文，标签之间的连接词同样用英文（写 <Video 1> and <Audio 1>，不写“和”“与”），正文中不夹任何中文。",
     "正文全部用中文书写（画面中可见文字保留原语言）。不要输出 markdown、标题、解释或代码块。"
     "H3 的固定标签和字段名一律保留英文，一个都不能翻：<Subject N>、<Picture N>、<Video N>、<Audio N>、<d>…</d>；"
     "六个字段名 subject_definitions: / summary: / retention_analysis: / detailed_description: / overall_soundscape: / non_diegetic_music:；"
     "保留关系标记 fully_preserved / partially_preserved / weak_reference / attribute_transfer / partially_copy；"
     "任务类型 [video editing + audio reuse] / [reference generation + audio reuse]；以及 (appears in [Shot 1])、(scene, camera and motion of the current fragment) 这类括号说明。"
     "不得写成 <图片 1>、<视频 2>、[视频编辑 + 原声复用]。标签之间的连接词用中文（写 <Video 1> 和 <Audio 1>）。"),
    ("<Subject 1> is the [woman/man] whose identity, face, hairstyle and outfit come from <Picture 1>: [详细外貌、服装、鞋、配饰、画风]. <Picture 1> is used only for her identity and appearance; its pose, framing and background are not used.",
     "<Subject 1> 是 <Picture 1> 中的[女性/男性]，身份、脸、发型和服装来自 <Picture 1>：[详细外貌、服装、鞋、配饰、画风]。<Picture 1> 只用来认人，画面里的姿势、构图和背景来自 <Video 1>。"),
    ("<Video 1> is the source video for this edit, supplied as the current fragment. Its scene, background, lighting, props, camera movement, framing and the performer's complete motion are kept.",
     "<Video 1> 是本次编辑的源视频，即当前提供的参考片段；它的场景、背景、光线、道具、运镜、构图和表演者的完整动作都保留。"),
    ("<Subject 2> is the original performer's motion abstracted from <Video 1>, to be performed by <Subject 1>.",
     "<Subject 2> 是从 <Video 1> 抽象出的原表演者的动作，由 <Subject 1> 来完成。"),
    ("<Audio 1> is the synchronized source soundtrack of <Video 1>, reused as the final audio; any voice or vocals in it remain off-screen recorded audio and are not performed by <Subject 1>.",
     "<Audio 1> 是 <Video 1> 的同步原声，成片直接复用；其中的人声和歌声都是画外录音，由画面外发出。"),
    ("模式 B 把 <Video 1> 写成 the current dance-reference fragment，并增加场景 Subject",
     "模式 B 把 <Video 1> 写成“当前的舞蹈参考片段”，并增加场景 Subject"),
    ("（一个短英文段落。模式 A：以 [video editing + audio reuse] 开头，接 “The target video is an edited version of <Video 1>.”，",
     "（一个简短的中文段落。模式 A：以 [video editing + audio reuse] 开头，接“目标视频是 <Video 1> 的编辑版本。”，"),
    ("<Audio 1>: partially_copy - the final output uses the source soundtrack trimmed to the exported video duration, without adding generated ambience, speech or music.",
     "<Audio 1>: partially_copy - 成片使用按片段时长截取的原声，音效与人声全部来自 <Audio 1>。"),
    ("模式 B 中 <Video 1> 用 fully_preserved（motion order and temporal structure），",
     "模式 B 中 <Video 1> 用 fully_preserved（动作顺序和时序结构），"),
    ("- 模式 A：每个 [Shot N] 按这个顺序写：From the first frame of this shot, replace the <位置 + 外观> in <Video 1> with <Subject 1>. Keep her face, hair and clothing from <Picture 1>. His <3–5 件最显眼的外观> become her <3–5 件>. Follow the source performance's pose, gaze, expression and movement exactly: <一句话动作>. Preserve the scene, lighting and camera move.",
     "- 模式 A：每个 [Shot N] 按这个顺序写：从这个镜头的第一帧起，把 <Video 1> 里<位置 + 外观>的那个人换成 <Subject 1>，脸、发型和服装按 <Picture 1>。他的<3–5 件最显眼的外观>换成她的<3–5 件>。姿势、视线、表情和动作完全跟随原片：<一句话动作>。场景、光线和运镜保留原片。"),
    ("短而准：每个镜头 40–90 个英文词，整份六段合计约 150–250 词。", "短而准：每个镜头 80–150 个汉字，整份六段合计约 300–500 字。"),
    ("1. 六个字段齐全、顺序正确、各一次，全部英文，无 markdown，无任何 @ 引用和中文。",
     "1. 六个字段齐全、顺序正确、各一次；正文是中文，标签、字段名、保留关系标记和任务类型都是英文；无 markdown，无任何 @ 引用，没有 <图片 1>、<视频 2> 这类中文标签。"),
]


def main() -> None:
    source, target = sys.argv[1], sys.argv[2]
    text = open(source, encoding="utf-8").read()
    for old, new in SWAPS:
        count = text.count(old)
        if count != 1:
            sys.exit(f"英文模板里这段出现 {count} 次（应为 1）：{old[:50]}…")
        text = text.replace(old, new)
    text = text.replace("「小肥猴H3动作迁移」提示词反推助手", "「小肥猴H3动作迁移（中文）」提示词反推助手", 1)
    with open(target, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)
    print(f"已生成中文模板：{target}")


if __name__ == "__main__":
    main()
