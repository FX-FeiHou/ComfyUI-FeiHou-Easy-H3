"""Extract evenly spaced frames from a video for prompt reverse-engineering.

Usage: python extract_keyframes.py <video> <output_dir> [--count 8]
Requires ffmpeg and ffprobe on PATH.
"""
import argparse
import json
import pathlib
import subprocess


def main():
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("video")
    parser.add_argument("output_dir")
    parser.add_argument("--count", type=int, default=8)
    args = parser.parse_args()
    out = pathlib.Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)
    probe = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "json", args.video],
                           capture_output=True, text=True, check=True)
    duration = float(json.loads(probe.stdout)["format"]["duration"])
    count = max(1, args.count)
    for index in range(count):
        timestamp = duration * (index + 0.5) / count
        target = out / f"frame_{index + 1:02d}_{timestamp:07.2f}s.jpg"
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", f"{timestamp:.3f}", "-i", args.video,
                        "-frames:v", "1", "-q:v", "3", str(target)], check=True)
        print(target)


if __name__ == "__main__":
    main()
