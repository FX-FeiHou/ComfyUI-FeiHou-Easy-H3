"""Contact sheets for reviewing the cut points and blocks found by detect_cuts.py.

    python review_blocks.py video.mp4 cuts.json out_dir [--weak weak.json] [--per-second 4]

One PNG per block (block_01.png ...), frames sampled ``--per-second`` times a
second and labelled with their time.  A frame right after a detected cut gets
a red frame; right after a weak candidate (a cut found only by the lower
threshold run in ``--weak``) a yellow one.  The weak candidates are also
listed on the console with the block they fall in, so each can be looked at.

Make ``weak.json`` with the same detector at a lower threshold, for example:

    python detect_cuts.py video.mp4 --method transnet --threshold 0.25 --json weak.json
"""

import argparse
import json
import os

import av
from PIL import Image, ImageDraw

TILE_WIDTH = 240
COLUMNS = 8
RED, YELLOW = (230, 40, 40), (250, 200, 30)


def sample_block(container, stream, start_s, end_s, per_second):
    """(time, PIL image) pairs at ``per_second`` steps inside [start_s, end_s)."""
    targets = []
    t = start_s
    while t < end_s - 1e-6:
        targets.append(t)
        t += 1.0 / per_second
    origin = float(stream.start_time * stream.time_base) if stream.start_time is not None else 0.0
    container.seek(int(max(0.0, origin + start_s - 1.0) / stream.time_base), stream=stream, backward=True)
    out, index = [], 0
    for frame in container.decode(stream):
        if frame.pts is None:
            continue
        time = float(frame.pts * stream.time_base) - origin
        while index < len(targets) and time + 1e-3 >= targets[index]:
            height = round(TILE_WIDTH * frame.height / frame.width)
            out.append((targets[index], frame.to_image().resize((TILE_WIDTH, height))))
            index += 1
        if index >= len(targets):
            break
    return out


def sheet(samples, marks, title):
    height = samples[0][1].height
    rows = (len(samples) + COLUMNS - 1) // COLUMNS
    image = Image.new("RGB", (COLUMNS * TILE_WIDTH, 24 + rows * (height + 18)), (20, 20, 20))
    draw = ImageDraw.Draw(image)
    draw.text((6, 5), title, fill=(255, 255, 255))
    for position, (time, tile) in enumerate(samples):
        x = (position % COLUMNS) * TILE_WIDTH
        y = 24 + (position // COLUMNS) * (height + 18)
        image.paste(tile, (x, y))
        color = marks.get(position)
        if color:
            draw.rectangle([x, y, x + TILE_WIDTH - 1, y + height - 1], outline=color, width=4)
        draw.text((x + 4, y + height + 2), f"{int(time // 60):02d}:{time % 60:06.3f}", fill=color or (200, 200, 200))
    return image


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("video")
    parser.add_argument("cuts_json")
    parser.add_argument("out_dir")
    parser.add_argument("--weak", help="同一检测器用更低阈值跑出的 JSON，用来标出疑似漏切")
    parser.add_argument("--per-second", type=float, default=4.0)
    args = parser.parse_args()

    with open(args.cuts_json, encoding="utf-8") as handle:
        data = json.load(handle)
    cuts = set(data["cuts_seconds"])
    weak = []
    if args.weak:
        with open(args.weak, encoding="utf-8") as handle:
            weak = [s for s in json.load(handle)["cuts_seconds"] if all(abs(s - c) > 0.1 for c in cuts)]
    os.makedirs(args.out_dir, exist_ok=True)
    step = 1.0 / args.per_second
    with av.open(args.video) as container:
        stream = container.streams.video[0]
        stream.thread_type = "AUTO"
        for number, block in enumerate(data["blocks"], 1):
            start, end = block["start_s"], block["end_s"]
            samples = sample_block(container, stream, start, end, args.per_second)
            if not samples:
                continue
            marks = {}
            for seconds, color in [(c, RED) for c in cuts] + [(w, YELLOW) for w in weak]:
                if start < seconds < end:
                    marks[min(len(samples) - 1, int((seconds - start) / step + 0.999))] = color
            inside = [w for w in weak if start < w < end]
            title = (f"block {number:02d}  {start:.3f}-{end:.3f}s  ({end - start:.2f}s)  "
                     f"original shots {block.get('original_shots', 1)}  red = cut  yellow = weak candidate")
            path = os.path.join(args.out_dir, f"block_{number:02d}.png")
            sheet(samples, marks, title).save(path)
            note = f"  疑似漏切 {', '.join(f'{w:.3f}s' for w in inside)}" if inside else ""
            print(f"{path}{note}")
    if weak:
        print(f"\n低阈值多出的候选切点 {len(weak)} 个：" + ", ".join(f"{w:.3f}s" for w in weak))


if __name__ == "__main__":
    main()
