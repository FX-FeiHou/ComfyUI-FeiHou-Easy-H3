"""Install TransNetV2 (PyTorch port) for cut detection, through Chinese mirrors first.

Usage (run with the Python that should get the package, normally ComfyUI's):

    F:\\Ai\\ComfyUI-aki-v3.2\\python\\python.exe install_transnetv2.py
    python install_transnetv2.py --python D:\\other\\python.exe   # install into another interpreter
    python install_transnetv2.py --with-pyscenedetect              # also make sure the fallback exists

Safety:
* torch / torchvision / torchaudio / numpy are pinned to the versions already
  installed (pip constraints), so this never up- or downgrades them; if a
  dependency would need a different version the install fails instead of
  breaking ComfyUI.
* The transnetv2-pytorch wheel ships stray top-level ``tests/*`` files (with a
  4.8 MB test video) that land in site-packages and can overwrite other
  packages' tests (it overwrote ultralytics' tests/conftest.py on one machine).
  Existing files are backed up first and restored; the wheel's own test files
  are deleted afterwards.

The 30.5 MB model weights are bundled in the wheel, so nothing else is downloaded.
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile

PACKAGE = "transnetv2-pytorch==1.0.5"
# Tried in order; the official index comes last.
MIRRORS = [
    ("清华 TUNA", "https://pypi.tuna.tsinghua.edu.cn/simple"),
    ("阿里云", "https://mirrors.aliyun.com/pypi/simple/"),
    ("中科大 USTC", "https://pypi.mirrors.ustc.edu.cn/simple/"),
    ("腾讯云", "https://mirrors.cloud.tencent.com/pypi/simple"),
    ("华为云", "https://repo.huaweicloud.com/repository/pypi/simple"),
    ("上海交大 SJTU", "https://mirror.sjtu.edu.cn/pypi/web/simple"),
    ("PyPI 官方", "https://pypi.org/simple"),
]
PINNED = ["torch", "torchvision", "torchaudio", "numpy"]
# Top-level files the 1.0.5 wheel drops into site-packages/tests (see its RECORD).
WHEEL_TEST_FILES = ["conftest.py", "test_cli.py", "test_cli_parity.py", "test_consistency.py", "test_model.py",
                    "test_transnetv2_pytorch.py", "test_utils.py", "test.mp4"]
# import name -> pip name, needed by transnetv2_pytorch at run time
RUNTIME = {"ffmpeg": "ffmpeg-python", "past": "future", "pandas": "pandas", "PIL": "pillow", "tqdm": "tqdm"}


def run_python(python: str, code: str) -> subprocess.CompletedProcess:
    return subprocess.run([python, "-c", code], capture_output=True, text=True, encoding="utf-8", errors="replace")


def probe(python: str) -> dict:
    code = r"""
import importlib, importlib.metadata as md, json, os, sysconfig
out = {"site": sysconfig.get_paths()["purelib"], "versions": {}, "modules": {}}
for name in %r:
    try:
        out["versions"][name] = md.version(name)
    except md.PackageNotFoundError:
        pass
for module in %r + ["transnetv2_pytorch", "scenedetect", "cv2"]:
    try:
        importlib.import_module(module)
        out["modules"][module] = True
    except Exception:
        out["modules"][module] = False
print(json.dumps(out))
""" % (PINNED, list(RUNTIME))
    result = run_python(python, code)
    if result.returncode != 0:
        sys.exit(f"无法运行目标 Python：{python}\n{result.stderr[-800:]}")
    return json.loads(result.stdout.strip().splitlines()[-1])


def pip_install(python: str, packages: list[str], constraints: str) -> bool:
    for label, url in MIRRORS:
        host = url.split("/")[2]
        command = [python, "-m", "pip", "install", *packages, "-c", constraints, "-i", url,
                   "--trusted-host", host, "--timeout", "25", "--retries", "1", "--disable-pip-version-check"]
        print(f"→ 从 {label} 安装 {' '.join(packages)} …", flush=True)
        result = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", errors="replace")
        if result.returncode == 0:
            print(f"  成功（{label}）")
            return True
        tail = (result.stderr or result.stdout).strip().splitlines()[-3:]
        print(f"  失败：{' | '.join(tail)[:300]}")
        if "ResolutionImpossible" in result.stderr or "conflict" in result.stderr.lower():
            print("  依赖版本冲突（为了不改动 torch/numpy 已停止），换源也没用。")
            return False
    return False


def verify(python: str) -> tuple[bool, str]:
    result = run_python(python, "from transnetv2_pytorch import TransNetV2; m = TransNetV2(device='cpu'); "
                                "print('ok', sum(p.numel() for p in m.parameters()))")
    return result.returncode == 0 and result.stdout.startswith("ok"), (result.stdout + result.stderr)[-600:]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--python", default=sys.executable, help="要安装到哪个 Python（默认：运行本脚本的 Python）")
    parser.add_argument("--with-pyscenedetect", action="store_true", help="同时确保备用方案 PySceneDetect 可用")
    parser.add_argument("--reinstall", action="store_true", help="强制重装 transnetv2-pytorch（只重装它本身，不动依赖）")
    args = parser.parse_args()
    python = args.python

    if shutil.which("ffmpeg") is None:
        print("提示：PATH 里没有 ffmpeg 命令行。TransNetV2 读视频要用它，请先安装 ffmpeg 并加入 PATH。")
    info = probe(python)
    if "torch" not in info["versions"]:
        sys.exit("目标 Python 里没有 torch。TransNetV2 需要 PyTorch；请用 ComfyUI 自带的 Python 运行本脚本（例如 "
                 "F:\\Ai\\ComfyUI-aki-v3.2\\python\\python.exe），不要在这里装 torch。")
    print("目标 Python：", python)
    print("固定不动的版本：", ", ".join(f"{k}=={v}" for k, v in info["versions"].items()))

    with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False, encoding="utf-8") as handle:
        handle.write("\n".join(f"{name}=={version}" for name, version in info["versions"].items()) + "\n")
        constraints = handle.name
    tests_dir = os.path.join(info["site"], "tests")
    tests_existed = os.path.exists(tests_dir)
    saved = {name: open(os.path.join(tests_dir, name), "rb").read()
             for name in WHEEL_TEST_FILES if os.path.isfile(os.path.join(tests_dir, name))}
    try:
        ok = True
        missing = [pip for module, pip in RUNTIME.items() if not info["modules"].get(module)]
        if args.reinstall:
            ok = pip_install(python, [PACKAGE, "--force-reinstall", "--no-deps"], constraints)
            if ok and missing:
                ok = pip_install(python, missing, constraints)
        elif not info["modules"].get("transnetv2_pytorch"):
            ok = pip_install(python, [PACKAGE, *missing], constraints)
        else:
            print("transnetv2_pytorch 已安装。")
        if args.with_pyscenedetect and not info["modules"].get("scenedetect"):
            extra = [] if info["modules"].get("cv2") else ["opencv-python-headless"]
            pip_install(python, ["scenedetect", *extra], constraints)
    finally:
        os.unlink(constraints)
    if os.path.exists(os.path.join(tests_dir, "test_transnetv2_pytorch.py")):
        if not tests_existed:
            shutil.rmtree(tests_dir, ignore_errors=True)
        else:
            for name in WHEEL_TEST_FILES:
                path = os.path.join(tests_dir, name)
                if name in saved:
                    with open(path, "wb") as handle:
                        handle.write(saved[name])
                elif os.path.exists(path):
                    os.remove(path)
        print("已清理 transnetv2-pytorch 附带的多余测试文件（其它包原有的 tests 文件已还原）。")

    if not ok:
        print("\nTransNetV2 没装上。切点检测会自动退回 PySceneDetect，再退回 ffmpeg。")
        sys.exit(1)
    good, detail = verify(python)
    print("\n验证：", "TransNetV2 可以正常加载（权重已随包安装）。" if good else f"加载失败：{detail}")
    sys.exit(0 if good else 1)


if __name__ == "__main__":
    main()
