# 人物替换提示词示例

素材：<Picture 1> 目标人物（已去背景换成中性灰 #808080 底），<Video 1> 参考视频（RGB），<Audio 1> 参考视频原声。方括号里的内容按实际素材填写。

要点对照：
- 任务模式是人物替换：[video editing + audio reuse]，场景、机位、道具全部沿用 <Video 1>，并写清视频里的背景。
- <Picture 1> 只提供身份和服装，写明不使用它的灰色底和站姿，避免画面定格成参考图。人物图先去背景，是避免定格的关键。
- 从这个镜头的第一帧起人物就是 <Subject 1>；一块只写一个连续镜头，不写“视频 1 切镜时同步切镜”。
- 不写“首帧与 <Video 1> 第一帧相同”，否则开头镜头会被直接复制成原画面。
- 用一句对比把原人物最显眼的外观逐件换成目标人物的；全文用肯定句。

以下为完整提示词（只参考结构和颗粒度）：

subject_definitions:
<Subject 1> is the [woman/man] whose identity, face, hairstyle and outfit come from <Picture 1>: [hair, face, each clothing layer, shoes, accessories, art style]. <Picture 1> is used only for identity and appearance; its gray backdrop, standing pose and framing are not used.
<Video 1> is the source video for this edit, supplied as the current fragment: [location, main objects, light, weather or time]. Its scene, background, lighting, props, camera movement, framing and the performer's complete motion are kept.
<Subject 2> is the original performer's motion abstracted from <Video 1>, to be performed by <Subject 1>.
<Audio 1> is the synchronized source soundtrack of <Video 1>, reused as the final audio; any voice or vocals in it remain off-screen recorded audio and are not performed by <Subject 1>.

summary:
[video editing + audio reuse] The target video is an edited version of <Video 1>. In every frame of this continuous shot, the [position + appearance] person of <Video 1> is replaced by <Subject 1>, who performs <Subject 2>. The scene, props, lighting and camera work of <Video 1> stay unchanged, and the soundtrack is the matching portion of <Audio 1>.

retention_analysis:
<Subject 1> (appears in [Shot 1]): fully_preserved - face, hairstyle, clothing and accessories from <Picture 1> in every frame.
<Video 1> (scene, camera and motion of the current fragment): weak_reference - provides the background, lighting, props, camera movement, framing and motion timing; the performer's identity, hair and clothing come from <Picture 1>.
<Subject 2> (appears in [Shot 1]): attribute_transfer - the motion is performed by <Subject 1>.
<Audio 1>: partially_copy - the final output uses the source soundtrack trimmed to the exported video duration, without adding generated ambience, speech or music.

detailed_description:
[Shot 1] The background is [location, main objects, light] from <Video 1>. From the first frame of this shot, replace the [position + appearance] person in <Video 1> with <Subject 1>. Keep the face, hair and clothing from <Picture 1>. The original [3-5 most visible items] become [the matching 3-5 items of <Subject 1>]. Follow the source performance's pose, gaze, expression and movement exactly: [one sentence of motion]. Preserve the scene, lighting and camera move.

overall_soundscape:
Only the sounds already present in the reused source soundtrack are used; no new ambience, footsteps or dialogue is generated.

non_diegetic_music:
The original source audio is reused with its existing rhythm and timing. No new composition, rearrangement, restart or fade is applied. Any vocals in the source are background playback, and the on-screen character does not lip-sync.
