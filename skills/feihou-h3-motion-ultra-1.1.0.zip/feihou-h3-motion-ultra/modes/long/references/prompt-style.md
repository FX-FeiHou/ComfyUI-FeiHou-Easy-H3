# 写法标准：短而准（所有分镜块的默认写法）

依据：
- Character Swap LoRA（akatz-ai，Hugging Face）官方示例只有四句：换谁、换成谁、跟随原片动作、保留场景。
- 实测：提示词越长，H3 越会按文字重新编排画面，动作反而跟不准；短提示词让它紧跟 `<Video 1>` 的动作。

## 五条原则

1. **一块只写要换人的画面。** 这一块里没有要换的人的时间段，拆出去写成 `@passthrough` 块。一个连续运镜里，前半段是空镜、后半段才有人时，也按时间拆开。
2. **只写四件事：**
   - 换谁：位置和外观；
   - 换成谁：`<Picture N>` 加 3～6 个最显眼的特征；
   - 跟随原片动作：一句话概括；
   - 保留场景和镜头：一句话。
3. **全部用肯定句。** 要留下的写「保留 / Preserve」，要换掉的写「换成 / becomes」。
4. **一种语言写到底。** 标签统一写成 `<Picture N>`、`<Video N>`、`<Audio N>`、`<Subject N>`。
5. **篇幅：**
   - `detailed_description` 每个 `[Shot N]` 写 40～90 个英文词，中文 80～150 字；
   - 整份六段合计约 150～250 个英文词，中文 300～500 字。

## 三句保底（来自实测，短写时也保留）

- **从第一帧起**：每个有人的 `[Shot N]` 开头写 from the first frame of this shot / 从这个镜头的第一帧起。
- **一句对比**：用一句话把原人物最显眼的 3～5 件外观对应换成 `<Subject 1>` 的：「原人物的<A>、<B>、<C>，变成 <Subject 1> 的<A'>、<B'>、<C'>」。两人服装相近时，逐件写头发、上衣、下装、鞋。
- **每个镜头写全**：一块有几个镜头，就写几个 `[Shot N]`，每个都套完整模板。模板很短，重复写也不长。

## 模板（英文）

```
subject_definitions:
<Subject 1> is the <character> in <Picture 1>: <3-6 visible features: hair, outfit, signature accessory, shoes>.
<Subject 2> is the movement of the <original person> in <Video 1>, performed by <Subject 1>.
<Audio 1> is the synchronized soundtrack of <Video 1>.

summary:
[video editing + audio reuse] Replace the <who / where> in <Video 1> with <Subject 1>, following the source movement and keeping the scene and camera.

retention_analysis:
<Subject 1>: fully_preserved - face, hair and clothing from <Picture 1>.
<Video 1>: weak_reference - scene, lighting, camera move and timing.
<Subject 2>: attribute_transfer - the source movement performed by <Subject 1>.
<Audio 1>: partially_copy - the source soundtrack.

detailed_description:
[Shot 1] From the first frame of this shot, replace the <who / where> in <Video 1> with <Subject 1>. Keep her face, hair and clothing from <Picture 1>. His <3-5 items> become her <3-5 items>. Follow the source performance's pose, gaze, expression and movement exactly: <one line of action>. Preserve the scene, lighting and camera move.

overall_soundscape:
The source soundtrack of <Audio 1>.

non_diegetic_music:
The song from <Audio 1>, with its original timing.
```

## 模板（中文正文，标签保持英文）

```
detailed_description:
[Shot 1] 从这个镜头的第一帧起，把 <Video 1> 里<位置 + 外观>的那个人换成 <Subject 1>，脸、发型和服装按 <Picture 1>。他的<3～5 件>换成人物的<3～5 件>。姿势、视线、表情和动作完全跟随原片：<一句话动作>。场景、光线和运镜保留原片。
```

## 按需加一句（只在对应情况下加）

| 情况 | 加的一句 |
|---|---|
| 多人同框 | 用位置加外观指明换哪一位：「画面右边穿红色上衣、正在挥手的女人」 |
| 远景或逆光小人 | 补一个轮廓锚点：「轮廓是人物的长发和长裙」 |
| 被遮挡 | 「被遮挡的部分按 <Subject 1> 补全」 |
| 用了脸部特写图 | 在 `subject_definitions` 写「脸按 <Picture 2>，发型服装按 <Picture 1>」 |
| 参考图是拼图 | 在 `subject_definitions` 写明每栏是什么 |
| 唱歌或说话的片子（开工时选了跟原片嘴型） | 「嘴型跟随原片和 <Audio 1>」 |

## 交付前自查

- 每个 `[Shot N]` 都在 40～90 词以内，并且包含：第一帧起、换谁、换成谁、一句对比、动作、保留场景。
- 全文是一种语言，标签是 `<Picture N>` 这类英文标签。
- 句子都是肯定句。
- 这一块的画面里都有要换的人；没有人的部分已经拆成 `@passthrough`。
