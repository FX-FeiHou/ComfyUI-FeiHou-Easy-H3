# 动作迁移提示词示例

素材：<Picture 1> 目标人物，<Picture 2> 场景图，<Video 1> 舞蹈或表演参考视频（RGB），<Audio 1> 参考视频原声。方括号里的内容按实际素材填写。

要点对照：
- 动作单独定义为 <Subject 3>，用 attribute_transfer 迁移给 <Subject 1>；背景来自 <Picture 2>，构图和运镜来自 <Video 1>。
- <Video 1> 写成“当前参考片段”，全文没有具体时间点的动作，只有一个连续镜头，适用于块内每一段。
- 原声复用（[reference generation + audio reuse]，<Audio 1> partially_copy）；人物不对口型。

以下为完整提示词（只参考结构和颗粒度）：

subject_definitions:
<Subject 1> is the [woman/man] whose identity, face, hairstyle and outfit come from <Picture 1>: [hair, face, each clothing layer, shoes, accessories, art style].
<Subject 2> is the scene from <Picture 2>: [location and space, main objects with position, colour and material, ground and walls, light direction, colour tone, distance].
<Video 1> is the current motion-reference fragment; only its motion, timing, framing and camera movement are used.
<Subject 3> is the performer's motion abstracted from <Video 1>, performed by <Subject 1>.
<Audio 1> is the synchronized source soundtrack of <Video 1>, reused as the final audio; any voice or vocals in it remain off-screen recorded audio and are not performed by <Subject 1>.
<Picture 1> is a person reference that provides only appearance, hairstyle and clothing; its plain background stays out of the picture. The environment is always <Subject 2>.

summary:
[reference generation + audio reuse] <Subject 1> performs <Subject 3> inside <Subject 2>, following the motion, timing, framing and camera movement of <Video 1>. The soundtrack is the matching portion of <Audio 1>.

retention_analysis:
<Subject 1> (appears in [Shot 1]): fully_preserved - face, hairstyle, clothing and accessories from <Picture 1>.
<Subject 2> (appears in [Shot 1]): fully_preserved - the whole background is this scene from the first frame on.
<Video 1> (motion order, framing and camera movement): fully_preserved - motion order, timing, framing and camera movement; its background and original performer stay out of the picture.
<Subject 3> (appears in [Shot 1]): attribute_transfer - the motion is performed by <Subject 1>.
<Audio 1>: partially_copy - the final output uses the source soundtrack trimmed to the exported video duration, without adding generated ambience, speech or music.

detailed_description:
Realistic footage shot on a professional camera, with natural skin texture, clear hair and fabric detail, and light that fits the scene. [Shot 1] From the first frame the picture is <Subject 2>, [key scene details], and the background stays the same throughout; <Subject 1> stands [position in the scene] from the first frame. [Portrait or landscape, full body or waist-up, where the frame edges fall]; framing and camera movement follow <Video 1>. <Subject 1> performs following <Video 1>: every movement, body direction, left-right relationship and rhythm matches <Video 1> at the same moment. Her expression changes naturally with the music and movement, with a smile, a playful look and a confident gaze in turn.

overall_soundscape:
Only the sounds already present in the reused source soundtrack are used; no new ambience, footsteps or dialogue is generated.

non_diegetic_music:
The original source audio is reused with its existing rhythm and timing. No new composition, rearrangement, restart or fade is applied. Any vocals are background playback, and the on-screen character does not lip-sync.
