# H3 Ref2VA 六段式规则

本文件整理 MiniMax H3 官方全参考（Ref2VA）提示词格式。字段名、标签、关系标记都是固定英文值，必须原样使用。

## 1. 总体结构

完整提示词由六个字段组成，按以下顺序各出现一次，字段名后接冒号：

| 字段 | 作用 |
| --- | --- |
| `subject_definitions` | 定义参考内容及其标签 |
| `summary` | 概括任务类型、目标视频和主要参考关系 |
| `retention_analysis` | 说明每个参考内容如何保留、迁移或复用 |
| `detailed_description` | 按播放顺序描述画面、动作、镜头、声音和对白 |
| `overall_soundscape` | 概括环境声和物理声音 |
| `non_diegetic_music` | 描述只有观众听得到的配乐 |

六个字段都用英文书写；只有 `<d>` 内的对白和歌词、以及画面中可见的文字保留原语言。

## 2. 参考标签与 `subject_definitions`

| 标签 | 含义 |
| --- | --- |
| `<Subject N>` | 从参考素材中抽象出来、在目标视频中复用或修改的可见内容：人物、动物、物体、场景、服装、道具、特效、风格、动作、表情、姿势 |
| `<Picture N>` | 作为具体目标画面或分镜锚点的参考图（首帧、关键帧、尾帧、构图锚点） |
| `<Video N>` | 提供编辑源、接续起点或整片时间结构的参考视频 |
| `<Audio N>` | 被复制或参考的音频信号 |

规则：

- 一个标签一旦定义，在六个字段中含义不变。标签格式严格为 `<Subject 1>`、`<Picture 1>`、`<Video 1>`、`<Audio 1>`（首字母大写、一个空格、阿拉伯数字）。
- `subject_definitions` 每项一行，说明标签代表什么、参考作用、需要遵循的主要特征；需要说明来源时写出对应素材。
- 图片只用于定义人物、场景、服装、风格时，不单独建 `<Picture N>` 条目，而是在对应 `<Subject N>` 定义中引用它：`<Subject 1> is the young woman in <Picture 1>, with ...`。
- 同一主体来自多个素材时合并说明每个素材提供什么：`<Subject 1> is the woman whose appearance comes from <Picture 1> and whose walking motion comes from <Video 1>.`
- 参考视频里的人物、动作、场景被复用为可见内容时，仍然用 `<Subject N>`；`<Video N>` 只表示素材或结构来源。
- `<Video N>` 与 `<Audio N>` 各自独立编号；序号不代表配对。普通参考视频不会因为文件里有声音就产生 `<Audio N>`。需要消除歧义时写：`<Audio 2> is the synchronized audio track of <Video 1> and is reused in the target video.`
- `<Audio N>` 对应目标说话人时写 `<Audio 1> is the voice-timbre reference for <Subject 1> (S1).`

## 3. `summary`

一个简短英文段落，以方括号任务类型开头，例如 `[reference generation] ...`。

| 任务类型 | 何时使用 |
| --- | --- |
| `keyframe completion` | 图片作为目标视频的首帧、关键帧、尾帧或其他具体画面锚点 |
| `reference generation` | 图片、视频、音频为人物、场景、风格、动作、运镜、分镜等提供生成参考，但不是具体画面锚点，也不是被编辑或接续的源视频 |
| `video editing` | 直接修改已有源视频 |
| `video continuation` | 新内容接续、延长或过渡自已有源视频 |
| `audio reuse` | 全部或部分复用同一音频信号 |
| `audio reference` | 不直接复制信号，只参考音乐风格、音色、台词内容、音效质感、节拍或连续性 |

- 多个关系用 ` + ` 连接，不重复，例如 `[reference generation + audio reuse]`。
- 仅有视频或音频并不自动产生对应任务类型；参考视频只提供运镜、剪辑或节奏时，通常属于 `reference generation`。
- summary 只能使用已定义的标签，不引入新标签。视频编辑任务在前缀后写 `The target video is an edited version of <Video 1>.`

## 4. `retention_analysis`

每个标签一行，沿用 `subject_definitions` 中的含义。

可见内容（`<Subject N>`、`<Picture N>`、`<Video N>`）的关系标记：

| 标记 | 含义 |
| --- | --- |
| `fully_preserved` | 定义的作用完整保留 |
| `partially_preserved` | 仍然使用，但部分特征改变或只部分保留 |
| `attribute_transfer` | 参考特征迁移到另一个可识别的目标主体上（动作迁移使用它） |
| `weak_reference` | 只保留风格、类别、构图或氛围上的大致相似 |

写法：

```text
<Subject 1> (appears in [Shot 1], [Shot 3]): fully_preserved - ...
<Picture 2> ([Shot 1] first frame): fully_preserved - ...
<Video 1> (cut and pacing structure): weak_reference - ...
```

音频（`<Audio N>`）的关系标记：

| 标记 | 含义 |
| --- | --- |
| `fully_copy` | 完整源音频作为目标视频的完整最终音轨 |
| `partially_copy` | 只复制部分时间线或部分音频层，或复制后有增删替换 |
| `reference` | 不复制信号，只参考音色、节奏、音乐风格、台词内容或声音质感 |
| `weak_reference` | 只保留类别或氛围上的大致相似 |

只在标签既定作用范围内选择标记；目标视频新增的动作、背景、情节不算参考保真度损失。`retention_analysis` 中不写说话人编号 `(Sx)`。

## 5. `detailed_description`

- 正文用英文，按目标视频播放顺序逐镜头描述。
- 先用一两句英文确定画风，再写 `[Shot 1]`。`[Shot 1]` 不带时间戳；后续真实切镜写 `[Shot N] At MM:SS.mmm, ...`，切点递增且小于总时长。
- 每个镜头写清构图、主体外貌和位置、环境和光线、动作与状态变化、运镜（类型、幅度、速度）、当时的声音，以及参考内容出现或生效的位置。不要写成剧情梗概或参考关系清单。
- 重要 `<Subject N>` 第一次清楚出现时，描述其参考特征、在画面中的位置和当前动作；之后沿用同一标签，不重新定义。
- 具体画面锚点用自然说法：`the shot begins from <Picture 1>`、`the shot's keyframe corresponds to <Picture 2>`、`the shot ends on <Picture 3>`。
- 生成任务本字段通常 350–500 个英文词；对白密集时优先完整、能说完的时间线。单镜头不等于可以写短。

说话人和对白：

- 发声源按目标视频中实际发声顺序分配稳定编号 `(S1)`、`(S2)`，同一人物跨镜头沿用。
- 对白和歌词写成 `<d>[Language] ...</d>`，例如 `<Subject 2> (S1) says, <d>[English] He just likes cookies more than me.</d>`；标签外写说话人、动作和语气，标签内只写语言和实际说出的话。
- 画外说话写 `off-screen`；心理旁白写 `says in an off-screen voiceover`，并说明画中人物嘴唇闭合。
- 只在复用的 BGM 或完整原声里出现、没有具体人物发声的词句，用 `<Audio N>` 作为声源，不另分配 `(Sx)`。
- 直接复用参考音频的台词或歌词时保留原文和原语言，听不清写 `[unclear]`；只参考音色、节奏、情绪时，不把原台词带进目标视频。
- 跨切镜的同一句话用 `<scenetrans>` 并说明声音连续；只有明确要求截断时才用 `<cutoff>`。

## 6. `overall_soundscape` 与 `non_diegetic_music`

- `overall_soundscape` 概括全片的环境声和物理声音；与具体镜头同步的对白、演唱、声音事件留在 `detailed_description`。
- `non_diegetic_music` 描述角色听不到、只有观众听得到的配乐，写乐器、速度和动态变化；没有配乐写 `N/A`。
- 使用参考音频时，只在对应声音层的字段中说明复制或参考关系：环境声和音效写在 `overall_soundscape`，观众配乐写在 `non_diegetic_music`；同一音频两者都有时分别说明。
- 完整对白和歌词只写在 `detailed_description` 的 `<d>` 中，不在这两个字段重复。

## 7. 交付格式

- 只输出六个字段的正文：从 `subject_definitions:` 开始，到 `non_diegetic_music:` 的内容结束。
- 不输出问候、解释、markdown 代码块、注释或检查清单。
- 不保留占位符；不存在的素材不写对应标签。
