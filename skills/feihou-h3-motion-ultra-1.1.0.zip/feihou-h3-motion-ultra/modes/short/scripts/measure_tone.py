# -*- coding: utf-8 -*-
"""量原片每个时间点的环境色，给色调段落用（需要 ffmpeg、numpy、Pillow）。

用法：
    python measure_tone.py 视频.mp4 1.5 6 12.3 ...

每个时间点打印：中位亮度（0-255）、暗部 / 中间调 / 亮部的平均 RGB、色相（度）、饱和度。
读法见 references/tone-matching.md：色相 0-15 偏红、15-45 橙到黄、45-70 黄绿、
150-200 青、200-250 蓝、250-300 紫、300-360 品红；饱和度 <0.15 算发灰。
"""
import colorsys, os, subprocess, sys, tempfile
import numpy as np
from PIL import Image

def main():
    if len(sys.argv) < 3:
        print(__doc__); sys.exit(1)
    video, times = sys.argv[1], [float(x) for x in sys.argv[2:]]
    with tempfile.TemporaryDirectory() as tmp:
        for t in times:
            f = os.path.join(tmp, "f.png")
            subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", str(t), "-i", video,
                            "-frames:v", "1", "-vf", "scale=480:-1", f])
            a = np.asarray(Image.open(f).convert("RGB"), dtype=float) / 255
            L = a @ [0.299, 0.587, 0.114]
            parts = []
            for name, (lo, hi) in [("暗部", (0, 25)), ("中间调", (40, 60)), ("亮部", (92, 99.5))]:
                p0, p1 = np.percentile(L, [lo, hi])
                m = (L >= p0) & (L <= p1)
                r, g, b = a[m].mean(0)
                h, s, _ = colorsys.rgb_to_hsv(r, g, b)
                parts.append(f"{name} rgb({r*255:.0f},{g*255:.0f},{b*255:.0f}) 色相{h*360:.0f} 饱和{s:.2f}")
            print(f"{t:>7.2f}s  中位亮度 {np.median(L)*255:.0f} | " + " ; ".join(parts))

if __name__ == "__main__":
    main()
